import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;
import java.sql.*;

public class CompanionGUI extends JFrame
{
    static String name = null;
    static String username = null;
    static String password = null;
    static String email = null;
    static int phone;
    static int licenseNumber;
    static String address = null;
    public CompanionGUI() 
    {
        super("COMPANION");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        JPanel companionPanel = new JPanel();
        companionPanel.setLayout(new BoxLayout(companionPanel, BoxLayout.Y_AXIS));
        companionPanel.setBackground(Color.WHITE);
        add(companionPanel);
        
        
        JPanel logoPanel = new JPanel();
        logoPanel.setPreferredSize(new Dimension(Integer.MAX_VALUE, 20));
        logoPanel.setBackground(Color.WHITE);
        companionPanel.add(logoPanel);
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(321, 242, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoPanel.add(iconLabel);
        
        JPanel contentPanel = new JPanel();
        contentPanel.setBorder(new EmptyBorder(30, 0, 0, 0));
        contentPanel.setPreferredSize(new Dimension(Integer.MAX_VALUE, 410));
        contentPanel.setBackground(new Color(68,147,186,255));
        companionPanel.add(contentPanel);
        
        JPanel bigPanel = new JPanel();
        bigPanel.setBorder(new EmptyBorder(20, 0, 0, 0));
        bigPanel.setPreferredSize(new Dimension(700, 520));
        bigPanel.setLayout(new BoxLayout(bigPanel, BoxLayout.Y_AXIS));
        bigPanel.setBackground(Color.WHITE);
        contentPanel.add(bigPanel);
        
        JLabel role = new JLabel("Companion");
        role.setPreferredSize(new Dimension(100, 40));
        role.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 34));
        role.setForeground(Color.BLACK);
        role.setAlignmentX(Component.CENTER_ALIGNMENT);
        bigPanel.add(role);
        
        JPanel namePanel = new JPanel();
        namePanel.setBackground(Color.WHITE);
        bigPanel.add(namePanel);
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setPreferredSize(new Dimension(100, 40));
        nameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        namePanel.add(nameLabel);
        JTextField nameTextField = new JTextField();
        nameTextField.setColumns(20);
        nameTextField.setPreferredSize(new Dimension(40, 40));
        nameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border nameBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        nameTextField.setBorder(nameBottomBorder);
        namePanel.add(nameTextField);
        
        JPanel userNamePanel = new JPanel();
        userNamePanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        userNamePanel.setBackground(Color.WHITE);
        bigPanel.add(userNamePanel);
        JLabel userNameLabel = new JLabel("Username:");
        userNameLabel.setPreferredSize(new Dimension(160, 40));
        userNameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        userNamePanel.add(userNameLabel);
        JTextField userNameTextField = new JTextField();
        userNameTextField.setColumns(20);
        userNameTextField.setPreferredSize(new Dimension(40, 40));
        userNameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border userNameBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        userNameTextField.setBorder(userNameBottomBorder);
        userNamePanel.add(userNameTextField);
        
        JPanel passwordPanel = new JPanel();
        passwordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        passwordPanel.setBackground(Color.WHITE);
        bigPanel.add(passwordPanel);
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setPreferredSize(new Dimension(150, 40));
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        passwordPanel.add(passwordLabel);
        JTextField passwordTextField = new JTextField();
        passwordTextField.setColumns(20);
        passwordTextField.setPreferredSize(new Dimension(40, 40));
        passwordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border passwordBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        passwordTextField.setBorder(passwordBottomBorder);
        passwordPanel.add(passwordTextField);
        
        JPanel emailPanel = new JPanel();
        emailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        emailPanel.setBackground(Color.WHITE);
        bigPanel.add(emailPanel);
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setPreferredSize(new Dimension(100, 40));
        emailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        emailPanel.add(emailLabel);
        JTextField emailTextField = new JTextField();
        emailTextField.setColumns(20);
        emailTextField.setPreferredSize(new Dimension(40, 40));
        emailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border emailBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        emailTextField.setBorder(emailBottomBorder);
        emailPanel.add(emailTextField);
        
        JPanel phonePanel = new JPanel();
        phonePanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        phonePanel.setBackground(Color.WHITE);
        bigPanel.add(phonePanel);
        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setPreferredSize(new Dimension(110, 40));
        phoneLabel.setFont(new Font("Arial", Font.BOLD, 26));
        phonePanel.add(phoneLabel);
        JTextField phoneTextField = new JTextField();
        phoneTextField.setColumns(20);
        phoneTextField.setPreferredSize(new Dimension(40, 40));
        phoneTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border phoneBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        phoneTextField.setBorder(phoneBottomBorder);
        phonePanel.add(phoneTextField);
        
        JPanel licenseNumberPanel = new JPanel();
        licenseNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        licenseNumberPanel.setBackground(Color.WHITE);
        bigPanel.add(licenseNumberPanel);
        JLabel licenseNumberLabel = new JLabel("License Number:");
        licenseNumberLabel.setPreferredSize(new Dimension(230, 40));
        licenseNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        licenseNumberPanel.add(licenseNumberLabel);
        JTextField licenseNumberTextField = new JTextField();
        licenseNumberTextField.setColumns(20);
        licenseNumberTextField.setPreferredSize(new Dimension(40, 40));
        licenseNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border licenseNumberBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        licenseNumberTextField.setBorder(licenseNumberBottomBorder);
        licenseNumberPanel.add(licenseNumberTextField);
        
        JPanel addressPanel = new JPanel();
        addressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        addressPanel.setBackground(Color.WHITE);
        bigPanel.add(addressPanel);
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setPreferredSize(new Dimension(130, 40));
        addressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        addressPanel.add(addressLabel);
        JTextField addressTextField = new JTextField();
        addressTextField.setColumns(20);
        addressTextField.setPreferredSize(new Dimension(40, 40));
        addressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border addressBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        addressTextField.setBorder(addressBottomBorder);
        addressPanel.add(addressTextField);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        buttonPanel.setBackground(Color.WHITE);
        bigPanel.add(buttonPanel);
        JButton submit = new JButton("Submit");
        submit.setPreferredSize(new Dimension(140, 45));
        submit.setFont(new Font("Arial", Font.BOLD, 30));
        submit.setBackground(Color.WHITE);
        submit.setForeground(new Color(68,147,186,255));
        submit.setBorder(new LineBorder(new Color(68,147,186,255), 5));
        submit.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                JOptionPane.showMessageDialog(null, "Pending for approval...");
                name = nameTextField.getText();
                username = userNameTextField.getText();
                password = passwordTextField.getText();
                email = emailTextField.getText();
                phone = Integer.parseInt(phoneTextField.getText());
                licenseNumber = Integer.parseInt(licenseNumberTextField.getText());
                address = addressTextField.getText();
                
                addToPendingUserAcc();
                
                //new OtpAuthentication(CompanionGUI.this, "companion", "c00"+Integer.toString(MainLogic.userAccCount+1));
                new LoginGUI();
                dispose();
            }
        });
        buttonPanel.add(submit);
        
        
        
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    public static void createAcc()
    {
        User companionUser = new CompanionUser("c00"+Integer.toString(MainLogic.userAccCount+1), name, username, password, "companion", email, phone, licenseNumber, address);
        companionUser.setDatabaseInfo("c00"+Integer.toString(MainLogic.userAccCount+1), name, username, password, "companion", email, phone, licenseNumber, null, address);
        MainLogic.userAccCount++;
        MainLogic.userAccount.add(companionUser);
    }
    void addToPendingUserAcc()
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "INSERT INTO userapproval VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            statement.setString(1, "c00"+Integer.toString(MainLogic.userAccCount+1));
            statement.setString(2, name);
            statement.setString(3, username);
            statement.setString(4, password);
            statement.setString(5, "companion");
            statement.setString(6, email);
            statement.setInt(7, phone);
            statement.setInt(8, licenseNumber);
            statement.setNull(9, Types.VARCHAR);
            statement.setString(10, address);
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}