import java.util.*;

public class LoginLogic
{
    String role = null;
    String userID = null;
    public LoginLogic(String username, String password)
    {
        if(username.equals("sohai") && password.equals("0000"))
        {
            role = "admin";
        }
        else
        {
            for(User userAcc : MainLogic.userAccount)
            {
                if((userAcc.getUserInfo().get(2)).equals(username) && (userAcc.getUserInfo().get(3)).equals(password))
                {
                    role = (String)userAcc.getUserInfo().get(4);
                    userID = (String)userAcc.getUserInfo().get(0);
                    break;
                }
            }
        }
    }
    public String getRole(){return role;}
    public String getUserID(){return userID;}
}