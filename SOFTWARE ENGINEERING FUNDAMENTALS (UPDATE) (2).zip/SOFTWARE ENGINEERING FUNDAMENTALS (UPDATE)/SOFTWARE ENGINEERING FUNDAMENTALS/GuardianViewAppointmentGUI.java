import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;

public class GuardianViewAppointmentGUI extends JPanel implements DashboardContentParentGUI
{
    public GuardianViewAppointmentGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        
        JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        centerPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        add(bottomPanel, BorderLayout.SOUTH);
        
        ArrayList<JPanel> appointmentsArrayList = new ArrayList<>();
        
        
        
        
        
        ArrayList<ArrayList> UserAppointmentList = null;
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                UserAppointmentList = userAcc.getAppointmentList();
            }
        }
        
        
        
        for(ArrayList appointments : UserAppointmentList)
        {
            JPanel appointment = new JPanel();
            appointment.setPreferredSize(new Dimension(300, 250));
            appointment.setLayout(new BoxLayout(appointment, BoxLayout.Y_AXIS));
            appointment.setBorder(new LineBorder(Color.BLACK, 7));
            appointment.setBackground(new Color(68,147,186,255));
        
            JPanel appointmentPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            appointmentPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
            appointmentPanel.setBackground(new Color(68,147,186,255));
            appointment.add(appointmentPanel);
            JLabel serviceLabel = new JLabel("Service:");
            serviceLabel.setPreferredSize(new Dimension(110, 40));
            serviceLabel.setFont(new Font("Arial", Font.BOLD, 24));
            appointmentPanel.add(serviceLabel);
            JTextField serviceTextField = new JTextField((appointments.get(6) != null) ? "Companion" : "Therapist");
            serviceTextField.setColumns(6);
            serviceTextField.setPreferredSize(new Dimension(40, 40));
            serviceTextField.setFont(new Font("Arial", Font.PLAIN, 20));
            serviceTextField.setBorder(new LineBorder(Color.BLACK, 5));
            serviceTextField.setEditable(false);
            appointmentPanel.add(serviceTextField);
            JLabel dateLabel = new JLabel("Date:");
            dateLabel.setPreferredSize(new Dimension(80, 40));
            dateLabel.setFont(new Font("Arial", Font.BOLD, 24));
            appointmentPanel.add(dateLabel);
            JTextField dateTextField = new JTextField((String)appointments.get(2));
            dateTextField.setColumns(7);
            dateTextField.setPreferredSize(new Dimension(40, 40));
            dateTextField.setFont(new Font("Arial", Font.PLAIN, 20));
            dateTextField.setBorder(new LineBorder(Color.BLACK, 5));
            dateTextField.setEditable(false);
            appointmentPanel.add(dateTextField);
            JLabel timeLabel = new JLabel("Time:");
            timeLabel.setPreferredSize(new Dimension(80, 40));
            timeLabel.setFont(new Font("Arial", Font.BOLD, 24));
            appointmentPanel.add(timeLabel);
            JTextField timeTextField = new JTextField((String)appointments.get(3));
            timeTextField.setColumns(6);
            timeTextField.setPreferredSize(new Dimension(40, 40));
            timeTextField.setFont(new Font("Arial", Font.PLAIN, 20));
            timeTextField.setBorder(new LineBorder(Color.BLACK, 5));
            timeTextField.setEditable(false);
            appointmentPanel.add(timeTextField);
            JLabel therapyServiceLabel = new JLabel("<html>Therapy<br>Service:</html>");
            therapyServiceLabel.setPreferredSize(new Dimension(110, 80));
            therapyServiceLabel.setFont(new Font("Arial", Font.BOLD, 24));
            appointmentPanel.add(therapyServiceLabel);
            JTextField therapyServiceTextField = new JTextField((appointments.get(5) != null) ? (String)appointments.get(5) : "None");
            therapyServiceTextField.setColumns(8);
            therapyServiceTextField.setPreferredSize(new Dimension(40, 40));
            therapyServiceTextField.setFont(new Font("Arial", Font.PLAIN, 20));
            therapyServiceTextField.setBorder(new LineBorder(Color.BLACK, 5));
            therapyServiceTextField.setEditable(false);
            appointmentPanel.add(therapyServiceTextField);
        
            appointmentsArrayList.add(appointment);
        }
        
        
        
        
        
        
        JPanel backButtonPanel = new JPanel();
        backButtonPanel.setBorder(new EmptyBorder(0, 0, 30, 0));
        backButtonPanel.setBackground(Color.WHITE);
        bottomPanel.add(backButtonPanel);
        JButton back = new JButton("Back");
        back.setMaximumSize(new Dimension(170, 55));
        back.setAlignmentX(Component.CENTER_ALIGNMENT);
        back.setFont(new Font("Arial", Font.BOLD, 40));
        back.setBackground(Color.WHITE);
        back.setForeground(Color.BLACK);
        back.setBorder(new LineBorder(Color.BLACK, 7));
        back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                GuardianAppointmentGUI guardianAppointmentGUI = new GuardianAppointmentGUI(dashboard, userID);
                dashboard.remove(GuardianViewAppointmentGUI.this);
                dashboard.add(guardianAppointmentGUI.getPanel(), BorderLayout.CENTER);

                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        backButtonPanel.add(back);
        
        
        
        
        
        
        
        for(JPanel appointmentPanel : appointmentsArrayList)
        {
            centerPanel.add(appointmentPanel);
        }
        
        
        
    }
    public JPanel getPanel() {return GuardianViewAppointmentGUI.this;}
}