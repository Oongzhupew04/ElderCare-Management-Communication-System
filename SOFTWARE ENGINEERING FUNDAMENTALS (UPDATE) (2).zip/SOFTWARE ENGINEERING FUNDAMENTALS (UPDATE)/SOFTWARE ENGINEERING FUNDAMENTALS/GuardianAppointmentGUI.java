import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;
import java.util.*;

import javax.swing.plaf.metal.MetalCheckBoxIcon;

public class GuardianAppointmentGUI extends JPanel implements DashboardContentParentGUI
{
    boolean companionService = false;
    boolean therapyService = false;
    String serviceType = null;
    public GuardianAppointmentGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        
        
        JPanel centrePanel = new JPanel();
        centrePanel.setBackground(Color.WHITE);
        centrePanel.setLayout(new BoxLayout(centrePanel, BoxLayout.Y_AXIS));
        add(centrePanel, BorderLayout.CENTER);
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        add(bottomPanel, BorderLayout.SOUTH);
        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.WHITE);
        add(rightPanel, BorderLayout.EAST);
        
        
        
        
        JPanel firstPanel = new JPanel();
        firstPanel.setBorder(new EmptyBorder(30, 0, 0, 0));
        firstPanel.setBackground(Color.WHITE);
        centrePanel.add(firstPanel);
        JPanel secondPanel = new JPanel();
        secondPanel.setLayout(new BoxLayout(secondPanel, BoxLayout.Y_AXIS));
        secondPanel.setBackground(Color.WHITE);
        centrePanel.add(secondPanel);
        JPanel thirdPanel = new JPanel();
        thirdPanel.setBackground(Color.WHITE);
        
        
        
        
        JLabel serviceLabel = new JLabel("Service: ");
        serviceLabel.setFont(new Font("Arial", Font.BOLD, 40));
        firstPanel.add(serviceLabel);
        JPanel checkboxFirstPanel = new JPanel();
        checkboxFirstPanel.setLayout(new BoxLayout(checkboxFirstPanel, BoxLayout.Y_AXIS));
        checkboxFirstPanel.setBackground(Color.WHITE);
        firstPanel.add(checkboxFirstPanel);
        JCheckBox companionServiceCheckBox = new JCheckBox("Companion");
        companionServiceCheckBox.setFont(new Font("Arial", Font.BOLD, 40));
        companionServiceCheckBox.setBackground(Color.WHITE);
        companionServiceCheckBox.setIcon (new MetalCheckBoxIcon () 
        {
            protected int getControlSize() { return 20; }
        });
        companionServiceCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (companionServiceCheckBox.isSelected()) 
                {
                    companionService = true;
                }
                else
                {
                    companionService = false;
                }
            }
        });
        JCheckBox therapistServiceCheckBox = new JCheckBox("Therapist");
        therapistServiceCheckBox.setFont(new Font("Arial", Font.BOLD, 40));
        therapistServiceCheckBox.setBackground(Color.WHITE);
        therapistServiceCheckBox.setIcon (new MetalCheckBoxIcon () 
        {
            protected int getControlSize() { return 20; }
        });
        therapistServiceCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (therapistServiceCheckBox.isSelected()) 
                {
                    therapyService = true;
                    centrePanel.add(thirdPanel);
                    
                    
                    centrePanel.revalidate();
                    centrePanel.repaint();
                }
                else
                {
                    therapyService = false;
                    centrePanel.remove(thirdPanel);
                    
                    
                    centrePanel.revalidate();
                    centrePanel.repaint();
                }
            }
        });
        JPanel scheduleButtonPanel = new JPanel();
        scheduleButtonPanel.setBorder(new EmptyBorder(50, 0, 0, 50));
        scheduleButtonPanel.setBackground(Color.WHITE);
        rightPanel.add(scheduleButtonPanel);
        JButton schedule = new JButton("<html>View<br>Schedule</html>");
        schedule.setMaximumSize(new Dimension(170, 55));
        schedule.setAlignmentX(Component.CENTER_ALIGNMENT);
        schedule.setFont(new Font("Arial", Font.BOLD, 40));
        schedule.setBackground(Color.WHITE);
        schedule.setForeground(Color.BLACK);
        schedule.setBorder(new LineBorder(Color.BLACK, 7));
        schedule.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                GuardianViewAppointmentGUI guardianViewAppointmentGUI = new GuardianViewAppointmentGUI(dashboard, userID);
                dashboard.remove(GuardianAppointmentGUI.this);
                dashboard.add(guardianViewAppointmentGUI.getPanel(), BorderLayout.CENTER);
                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        scheduleButtonPanel.add(schedule);
        
        
        
        
        JPanel datePanel = new JPanel();
        datePanel.setBackground(Color.WHITE);
        secondPanel.add(datePanel);
        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setPreferredSize(new Dimension(110, 40));
        dateLabel.setFont(new Font("Arial", Font.BOLD, 40));
        datePanel.add(dateLabel);
        JTextField dateTextField = new JTextField();
        dateTextField.setColumns(7);
        dateTextField.setPreferredSize(new Dimension(40, 40));
        dateTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        dateTextField.setBorder(new LineBorder(Color.BLACK, 5));
        datePanel.add(dateTextField);
        
        JPanel timePanel = new JPanel();
        timePanel.setBackground(Color.WHITE);
        secondPanel.add(timePanel);
        JLabel timeLabel = new JLabel("Time:");
        timeLabel.setPreferredSize(new Dimension(115, 40));
        timeLabel.setFont(new Font("Arial", Font.BOLD, 40));
        timePanel.add(timeLabel);
        JTextField timeTextField = new JTextField();
        timeTextField.setColumns(7);
        timeTextField.setPreferredSize(new Dimension(40, 40));
        timeTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        timeTextField.setBorder(new LineBorder(Color.BLACK, 5));
        timePanel.add(timeTextField);
        
        
        
        
        
        
        
        
        JLabel therapyServiceLabel = new JLabel("Therapy Service: ");
        therapyServiceLabel.setFont(new Font("Arial", Font.BOLD, 40));
        thirdPanel.add(therapyServiceLabel);
        JPanel checkboxThirdPanel = new JPanel();
        checkboxThirdPanel.setLayout(new BoxLayout(checkboxThirdPanel, BoxLayout.Y_AXIS));
        checkboxThirdPanel.setBackground(Color.WHITE);
        thirdPanel.add(checkboxThirdPanel);
        JCheckBox physiotherapyTherapyCheckBox = new JCheckBox("Physiotherapy");
        JCheckBox physcotherapyTherapyCheckBox = new JCheckBox("Physcotherapy");
        JCheckBox occupationalTherapyCheckBox = new JCheckBox("Occupational");
        physiotherapyTherapyCheckBox.setFont(new Font("Arial", Font.BOLD, 40));
        physcotherapyTherapyCheckBox.setFont(new Font("Arial", Font.BOLD, 40));
        occupationalTherapyCheckBox.setFont(new Font("Arial", Font.BOLD, 40));
        physiotherapyTherapyCheckBox.setBackground(Color.WHITE);
        physcotherapyTherapyCheckBox.setBackground(Color.WHITE);
        occupationalTherapyCheckBox.setBackground(Color.WHITE);
        physiotherapyTherapyCheckBox.setIcon (new MetalCheckBoxIcon () 
        {
            protected int getControlSize() { return 20; }
        });
        physiotherapyTherapyCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (physiotherapyTherapyCheckBox.isSelected()) 
                {
                    serviceType = "physiotherapy";
                }
                else
                {
                    serviceType = null;
                }
            }
        });
        physcotherapyTherapyCheckBox.setIcon (new MetalCheckBoxIcon () 
        {
            protected int getControlSize() { return 20; }
        });
        physcotherapyTherapyCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (physcotherapyTherapyCheckBox.isSelected()) 
                {
                    serviceType = "physcotherapy";
                }
                else
                {
                    serviceType = null;
                }
            }
        });
        occupationalTherapyCheckBox.setIcon (new MetalCheckBoxIcon () 
        {
            protected int getControlSize() { return 20; }
        });
        occupationalTherapyCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (occupationalTherapyCheckBox.isSelected()) 
                {
                    serviceType = "occupational";
                }
                else
                {
                    serviceType = null;
                }
            }
        });
        checkboxThirdPanel.add(physiotherapyTherapyCheckBox);
        checkboxThirdPanel.add(physcotherapyTherapyCheckBox);
        checkboxThirdPanel.add(occupationalTherapyCheckBox);
        checkboxFirstPanel.add(companionServiceCheckBox);
        checkboxFirstPanel.add(therapistServiceCheckBox);
        
        
        JPanel confirmButtonPanel = new JPanel();
        confirmButtonPanel.setBorder(new EmptyBorder(0, 0, 30, 0));
        confirmButtonPanel.setBackground(Color.WHITE);
        bottomPanel.add(confirmButtonPanel);
        JButton confirm = new JButton("Confirm");
        confirm.setMaximumSize(new Dimension(170, 55));
        confirm.setAlignmentX(Component.CENTER_ALIGNMENT);
        confirm.setFont(new Font("Arial", Font.BOLD, 40));
        confirm.setBackground(Color.WHITE);
        confirm.setForeground(Color.BLACK);
        confirm.setBorder(new LineBorder(Color.BLACK, 7));
        confirm.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                for(User userAcc : MainLogic.userAccount)
                {
                    if((userAcc.getUserInfo().get(0)).equals(userID))
                    {
                        GuardianUser guardian = (GuardianUser) userAcc;
                        String companionID = null;
                        String therapistID = null;
                        if(companionService)
                        {
                            if(guardian.getAppointmentList().isEmpty())
                            {
                                for(User userAcc2 : MainLogic.userAccount)
                                {
                                    if(((String)userAcc2.getUserInfo().get(4)).equals("companion") && userAcc2.getAppointmentList().isEmpty())
                                    {
                                        companionID = (String)userAcc2.getUserInfo().get(0);
                                        break;
                                    }
                                }
                                
                                
                                String elderID = (String)userAcc.getElderInfo().get(0);
                                String appointmentID = elderID.replace("e", "a");
                                guardian.bookAppointmentDatabase(appointmentID, (String)userAcc.getElderInfo().get(1), dateTextField.getText(), timeTextField.getText(), (String)userAcc.getElderInfo().get(5), serviceType, companionID, therapistID);
                                JOptionPane.showMessageDialog(null, "Appointment Booked!");
                                break;
                            }
                            else if (!guardian.getAppointmentList().isEmpty())
                            {
                                Boolean found = false;
                                for(ArrayList appointment : guardian.getAppointmentList())
                                {
                                    if(appointment.get(6) != null)
                                    {
                                        companionID = (String)guardian.getAppointmentList().get(0).get(6);
                                
                                        String elderID = (String)userAcc.getElderInfo().get(0);
                                        String appointmentID = elderID.replace("e", "a");
                                        guardian.bookAppointmentDatabase(appointmentID, (String)userAcc.getElderInfo().get(1), dateTextField.getText(), timeTextField.getText(), (String)userAcc.getElderInfo().get(5), serviceType, companionID, therapistID);
                                        JOptionPane.showMessageDialog(null, "Appointment Booked!");
                                        found = true;
                                        break;
                                    }
                                }
                                if(!found)
                                {
                                    for(User userAcc2 : MainLogic.userAccount)
                                    {
                                        if(((String)userAcc2.getUserInfo().get(4)).equals("companion") && userAcc2.getAppointmentList().isEmpty())
                                        {
                                            companionID = (String)userAcc2.getUserInfo().get(0);
                                            break;
                                        }
                                    }
                                
                                
                                    String elderID = (String)userAcc.getElderInfo().get(0);
                                    String appointmentID = elderID.replace("e", "a");
                                    guardian.bookAppointmentDatabase(appointmentID, (String)userAcc.getElderInfo().get(1), dateTextField.getText(), timeTextField.getText(), (String)userAcc.getElderInfo().get(5), serviceType, companionID, therapistID);
                                    JOptionPane.showMessageDialog(null, "Appointment Booked!");
                                }
                                break;
                            }
                            else
                            {
                                JOptionPane.showMessageDialog(null, "No companion available.");
                            }
                        }
                        else if(therapyService)
                        {
                            if(serviceType.equals(null))
                            {
                                JOptionPane.showMessageDialog(null, "Please choose a therapy service.");
                            }
                            if(guardian.getAppointmentList().isEmpty())
                            {
                                for(User userAcc2 : MainLogic.userAccount)
                                {
                                    if(((String)userAcc2.getUserInfo().get(4)).equals("therapist") && userAcc2.getAppointmentList().isEmpty())
                                    {
                                        therapistID = (String)userAcc2.getUserInfo().get(0);
                                        break;
                                    }
                                }
                                
                                String elderID = (String)userAcc.getElderInfo().get(0);
                                String appointmentID = elderID.replace("e", "a");
                                guardian.bookAppointmentDatabase(appointmentID, (String)userAcc.getElderInfo().get(1), dateTextField.getText(), timeTextField.getText(), (String)userAcc.getElderInfo().get(5), serviceType, companionID, therapistID);
                                JOptionPane.showMessageDialog(null, "Appointment Booked!");
                                break;
                            }
                            else if (!guardian.getAppointmentList().isEmpty())
                            {
                                Boolean found = false;
                                for(ArrayList appointment : guardian.getAppointmentList())
                                {
                                    if(appointment.get(7) != null)
                                    {
                                        therapistID = (String)guardian.getAppointmentList().get(0).get(7);
                                
                                        String elderID = (String)userAcc.getElderInfo().get(0);
                                        String appointmentID = elderID.replace("e", "a");
                                        guardian.bookAppointmentDatabase(appointmentID, (String)userAcc.getElderInfo().get(1), dateTextField.getText(), timeTextField.getText(), (String)userAcc.getElderInfo().get(5), serviceType, companionID, therapistID);
                                        JOptionPane.showMessageDialog(null, "Appointment Booked!");
                                        found = true;
                                        break;
                                    }
                                }
                                if(!found)
                                {
                                    for(User userAcc2 : MainLogic.userAccount)
                                    {
                                        if(((String)userAcc2.getUserInfo().get(4)).equals("therapist") && userAcc2.getAppointmentList().isEmpty())
                                        {
                                            therapistID = (String)userAcc2.getUserInfo().get(0);
                                            break;
                                        }
                                    }
                                
                                    String elderID = (String)userAcc.getElderInfo().get(0);
                                    String appointmentID = elderID.replace("e", "a");
                                    guardian.bookAppointmentDatabase(appointmentID, (String)userAcc.getElderInfo().get(1), dateTextField.getText(), timeTextField.getText(), (String)userAcc.getElderInfo().get(5), serviceType, companionID, therapistID);
                                    JOptionPane.showMessageDialog(null, "Appointment Booked!");
                                }
                                break;
                            }
                            else
                            {
                                JOptionPane.showMessageDialog(null, "No medical therapist available.");
                            }
                        }
                        break;
                    }
                }
            }
        });
        confirmButtonPanel.add(confirm);
        
        
        
        
        
        
    }
    public JPanel getPanel() {return GuardianAppointmentGUI.this;}
}