import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class AboutUsGUI extends JPanel
{
    private JPanel panel = this;
    public AboutUsGUI()
    {
        setBackground(Color.WHITE);
        setLayout(new BoxLayout(AboutUsGUI.this, BoxLayout.Y_AXIS));
        
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(256, 193, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(iconLabel);
        
        JPanel descriptionPanel = new JPanel();
        descriptionPanel.setBackground(Color.WHITE);
        add(descriptionPanel);
        JLabel descriptionLabel = new JLabel("<html><font size='22'><b>About Us</b></font><br>At ElderCare, we are dedicated to providing compassionate and reliable care for your loved<br>ones in the comfort of their own home. Our mission is to ensure that seniors live with dignity, respect, and<br>the support they deserve. We understand the unique challenges that come with aging, and we are<br>committed to enhancing the quality of life for older adults through personalized, professional care services.<br><br>Our team of experienced caregivers is trained to offer a wide range of services, including assistance with<br>daily activities, companionship, medication management, and more. With a focus on creating a safe,<br>supportive, and nurturing environment, we work closely with families to tailor care plans that meet the<br>specific needs and preferences of each individual.<br><br>At ElderCare, we treat your family like our own. We are here to support you every step of the<br>way, offering peace of mind knowing that your loved one is in capable, caring hands.</html>");
        descriptionLabel.setFont(new Font("Serif", Font.PLAIN, 22));
        descriptionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        descriptionLabel.setBorder(new EmptyBorder(0, 0, 30, 0));
        descriptionPanel.add(descriptionLabel);
        
        JPanel contactPanel = new JPanel();
        contactPanel.setBackground(Color.WHITE);
        add(contactPanel);
        ImageIcon whatsappIcon = new ImageIcon("whatsapp.png");
        JLabel contactWhatsappLabel = new JLabel(" :  +6012 3456-789", whatsappIcon, JLabel.LEFT);
        contactWhatsappLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 30));
        contactPanel.add(contactWhatsappLabel);
        ImageIcon instagramIcon = new ImageIcon("instagram.png");
        JLabel contactInstagramLabel = new JLabel(" :  ElderCare", instagramIcon, JLabel.LEFT);
        contactInstagramLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 30));
        contactInstagramLabel.setBorder(new EmptyBorder(0, 50, 0, 0));
        contactPanel.add(contactInstagramLabel);
        ImageIcon emailIcon = new ImageIcon("email.png");
        JLabel contactEmailLabel = new JLabel(" :  ElderCare@gmail.com", emailIcon, JLabel.LEFT);
        contactEmailLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 30));
        contactEmailLabel.setBorder(new EmptyBorder(0, 50, 0, 0));
        contactPanel.add(contactEmailLabel);
        
        
        
    }
    public JPanel getAboutUsPanel() {return panel;}
}