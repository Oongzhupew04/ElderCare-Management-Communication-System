import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;

public class CompanionElderInformationGUI extends JPanel implements DashboardContentParentGUI
{
    public CompanionElderInformationGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        

        JPanel elderInfoPanel = new JPanel();
        elderInfoPanel.setBackground(Color.WHITE);
        elderInfoPanel.setLayout(new BoxLayout(elderInfoPanel, BoxLayout.Y_AXIS));
        elderInfoPanel.setBorder(new EmptyBorder(50, 100, 0, 0));
        add(elderInfoPanel);
        
        
        ArrayList<Object> elderInfo = null;
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                CompanionUser companion = (CompanionUser) userAcc;
                elderInfo = companion.getElderInfo();
            }
        }
        
        
        
        JPanel elderRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderRolePanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderRolePanel);
        JLabel elderRole = new JLabel("Elder");
        elderRole.setPreferredSize(new Dimension(125, 40));
        elderRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        elderRole.setForeground(Color.BLACK);
        Border eroleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        elderRole.setBorder(eroleBottomBorder);
        elderRolePanel.add(elderRole);
        
        JPanel elderNamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderNamePanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderNamePanel);
        JLabel elderNameLabel = new JLabel("Name:");
        elderNameLabel.setPreferredSize(new Dimension(85, 40));
        elderNameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderNamePanel.add(elderNameLabel);
        JTextField elderNameTextField = new JTextField((String)elderInfo.get(1));
        elderNameTextField.setColumns(20);
        elderNameTextField.setPreferredSize(new Dimension(40, 40));
        elderNameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderNameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderNameTextField.setEditable(false);
        elderNamePanel.add(elderNameTextField);
        
        JPanel elderAgePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderAgePanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderAgePanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderAgePanel);
        JLabel elderAgeLabel = new JLabel("Age:");
        elderAgeLabel.setPreferredSize(new Dimension(65, 40));
        elderAgeLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderAgePanel.add(elderAgeLabel);
        JTextField elderAgeTextField = new JTextField(String.valueOf(elderInfo.get(2)));
        elderAgeTextField.setColumns(20);
        elderAgeTextField.setPreferredSize(new Dimension(40, 40));
        elderAgeTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderAgeTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderAgeTextField.setEditable(false);
        elderAgePanel.add(elderAgeTextField);
        
        JPanel elderGenderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderGenderPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderGenderPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderGenderPanel);
        JLabel elderGenderLabel = new JLabel("Gender:");
        elderGenderLabel.setPreferredSize(new Dimension(110, 40));
        elderGenderLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderGenderPanel.add(elderGenderLabel);
        JTextField elderGenderTextField = new JTextField((String)elderInfo.get(3));
        elderGenderTextField.setColumns(20);
        elderGenderTextField.setPreferredSize(new Dimension(40, 40));
        elderGenderTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderGenderTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderGenderTextField.setEditable(false);
        elderGenderPanel.add(elderGenderTextField);
        
        JPanel elderMedicalRecordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderMedicalRecordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderMedicalRecordPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderMedicalRecordPanel);
        JLabel elderMedicalRecordLabel = new JLabel("Medical Record:");
        elderMedicalRecordLabel.setPreferredSize(new Dimension(210, 40));
        elderMedicalRecordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderMedicalRecordPanel.add(elderMedicalRecordLabel);
        JTextField elderMedicalRecordTextField = new JTextField((String)elderInfo.get(4));
        elderMedicalRecordTextField.setColumns(20);
        elderMedicalRecordTextField.setPreferredSize(new Dimension(40, 40));
        elderMedicalRecordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderMedicalRecordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderMedicalRecordTextField.setEditable(false);
        elderMedicalRecordPanel.add(elderMedicalRecordTextField);
        
        JPanel elderAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderAddressPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderAddressPanel);
        JLabel elderAddressLabel = new JLabel("Address:");
        elderAddressLabel.setPreferredSize(new Dimension(120, 40));
        elderAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderAddressPanel.add(elderAddressLabel);
        JTextField elderAddressTextField = new JTextField((String)elderInfo.get(5));
        elderAddressTextField.setColumns(20);
        elderAddressTextField.setPreferredSize(new Dimension(40, 40));
        elderAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderAddressTextField.setEditable(false);
        elderAddressPanel.add(elderAddressTextField);
    }
    public JPanel getPanel() {return CompanionElderInformationGUI.this;}
}