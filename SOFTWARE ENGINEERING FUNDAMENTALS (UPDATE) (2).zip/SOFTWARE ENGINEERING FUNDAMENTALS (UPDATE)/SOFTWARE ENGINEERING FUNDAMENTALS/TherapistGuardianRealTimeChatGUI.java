import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;
import java.sql.*;
import java.util.Timer;
import java.util.TimerTask;

public class TherapistGuardianRealTimeChatGUI extends JPanel implements DashboardContentParentGUI
{
    public TherapistGuardianRealTimeChatGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        
        
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(new EmptyBorder(20, 20, 0, 20));
        add(leftPanel, BorderLayout.WEST);
        
        JPanel centerTopPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        centerTopPanel.setBackground(Color.WHITE);
        Border centerTopPanelBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        centerTopPanel.setBorder(centerTopPanelBorder);
        centerPanel.add(centerTopPanel, BorderLayout.NORTH);
        JPanel centerCenterPanel = new JPanel();
        centerCenterPanel.setLayout(new BoxLayout(centerCenterPanel, BoxLayout.Y_AXIS));
        centerCenterPanel.setBackground(Color.WHITE);
        centerPanel.add(centerCenterPanel);
        JPanel centerBottomPanel = new JPanel(new BorderLayout());
        centerBottomPanel.setBackground(Color.WHITE);
        Border centerBottomPanelBorder = BorderFactory.createMatteBorder(4, 0, 0, 0, Color.BLACK);
        centerBottomPanel.setBorder(centerBottomPanelBorder);
        centerPanel.add(centerBottomPanel, BorderLayout.SOUTH);
        
        
        JLabel companion = new JLabel("Guardian");
        companion.setFont(new Font("Arial", Font.BOLD, 40));
        companion.setBorder(new EmptyBorder(0, 60, 30, 0));
        ImageIcon icon = new ImageIcon("user.png");
        companion.setIcon(icon);
        centerTopPanel.add(companion);
        
        
        
        JScrollPane scrollPane = new JScrollPane(centerCenterPanel);
        centerPanel.add(scrollPane);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        SwingUtilities.invokeLater(() -> {
            JScrollBar verticalScrollBar = scrollPane.getVerticalScrollBar();
            verticalScrollBar.setValue(verticalScrollBar.getMaximum());
        });
        
        
        JPanel messagePanel = new JPanel();
        messagePanel.setBorder(new EmptyBorder(10, 0, 0, 0));
        messagePanel.setBackground(Color.WHITE);
        centerBottomPanel.add(messagePanel);
        JTextField messageTextField = new JTextField();
        messageTextField.setColumns(30);
        String hint = "Message....";
        messageTextField.setText(hint);
        messageTextField.setForeground(Color.GRAY);
        messageTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        messageTextField.setBorder(new LineBorder(Color.BLACK, 5));
        messagePanel.add(messageTextField);
        messageTextField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (messageTextField.getText().equals(hint)) {
                    messageTextField.setText("");  // Clear the hint when focus is gained
                    messageTextField.setForeground(Color.BLACK);  // Change text color to black
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (messageTextField.getText().isEmpty()) {
                    messageTextField.setText(hint);  // Restore the hint when focus is lost
                    messageTextField.setForeground(Color.GRAY);  // Set the hint color back to gray
                }
            }
        });
        
        
        JPanel sentButtonPanel = new JPanel();
        sentButtonPanel.setBorder(new EmptyBorder(10, 0, 0, 20));
        sentButtonPanel.setBackground(Color.WHITE);
        centerBottomPanel.add(sentButtonPanel, BorderLayout.EAST);
        ImageIcon sentIcon = new ImageIcon("send.png");
        JButton sent = new JButton(sentIcon);
        sent.setMaximumSize(new Dimension(100, 200));
        sent.setBackground(Color.WHITE);
        sent.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                String modifiedString = messageTextField.getText();
                if (messageTextField.getText().length() > 59) 
                {
                    // Split the string after 10 characters and insert a newline
                    modifiedString = "<html>" + messageTextField.getText().substring(0, 59) + "<br>" + messageTextField.getText().substring(59) + "</html>";
                }
                JPanel panel = new JPanel(new BorderLayout());
                panel.setBorder(new EmptyBorder(0, 0, 20, 0));
                panel.setBackground(Color.WHITE);
                centerCenterPanel.add(panel);
                JLabel userChat = new JLabel(modifiedString);
                userChat.setFont(new Font("Arial", Font.PLAIN, 38));
                
                
                String chatID = getGuardianID(userID);
                chatID = chatID.replaceAll("g0", "gt");
                saveChat(chatID, "therapist", messageTextField.getText(), userID);
                
                
                centerCenterPanel.revalidate();
                centerCenterPanel.repaint();
            }
        });
        sentButtonPanel.add(sent);
        
        
        refreshChat(userID, dashboard, centerCenterPanel);
        
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                refreshChat(userID, dashboard, centerCenterPanel);
            }
        };
        timer.scheduleAtFixedRate(task, 0, 500);

        //userArrayList.add("user");
        //messageHistoryArrayList.add("Hi, Tao Hong. Wenkee did well today but had trouble with balance exercises. Try gentle walking and stretching at home.");
        //userArrayList.add("guardian");
        //messageHistoryArrayList.add("Thanks! Any discomfort?");
        //userArrayList.add("user");
        //messageHistoryArrayList.add("No pain, just tired. Balance was tough, but practice will help. I’ll send a handout for exercises.");
        //userArrayList.add("guardian");
        //messageHistoryArrayList.add("I’ll help. Anything else?");
        //userArrayList.add("user");
        //messageHistoryArrayList.add("Watch for overexertion and rest between exercises. I’ll check in later this week.");
        //userArrayList.add("guardian");
        //messageHistoryArrayList.add("Thanks, I’ll follow up.");
        //userArrayList.add("user");
        //messageHistoryArrayList.add("You’re welcome! Feel free to reach out anytime.");
        
        
        
        
        
        
        JButton dailyReport = new JButton("Guardian");
        dailyReport.setMaximumSize(new Dimension(250, 110));
        dailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        dailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        dailyReport.setBackground(Color.WHITE);
        dailyReport.setForeground(Color.BLACK);
        dailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        dailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                
            }
        });
        leftPanel.add(dailyReport);
        
        
        
        
    }
    public JPanel getPanel() {return TherapistGuardianRealTimeChatGUI.this;}
    public ArrayList getChat(String userid)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        ArrayList<ArrayList> chat = new ArrayList<ArrayList>();

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.chat"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String chatID = getGuardianID(userid);
                chatID = chatID.replaceAll("g0", "gt");
                if(resultSet.getString(1).equals(chatID) && (resultSet.getString(2).equals("therapist") || resultSet.getString(2).equals("guardian")))
                {
                    String converId = resultSet.getString(1);
                    String role = resultSet.getString(2);
                    String message = resultSet.getString(3);
                    String userID = resultSet.getString(4);
                    
                    
                    
                    ArrayList<Object> chatline = new ArrayList<Object>();
                    chatline.add(converId);
                    chatline.add(role);
                    chatline.add(message);
                    chatline.add(userID);
                    chat.add(chatline);
                }
            }
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return chat;
    }
    public void saveChat(String converid, String username, String message, String userid)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "INSERT INTO chat VALUES(?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            
            
            statement.setString(1, converid);
            statement.setString(2, username);
            statement.setString(3, message);
            statement.setString(4, userid);
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    void refreshChat(String userID, JFrame dashboard, JPanel centerCenterPanel)
    {
        ArrayList<ArrayList> chat = getChat(userID);
        ArrayList<String> userArrayList = new ArrayList<>();
        ArrayList<String> messageHistoryArrayList = new ArrayList<>();
        for(ArrayList chatline : chat)
        {
            userArrayList.add((String)chatline.get(1));
            messageHistoryArrayList.add((String)chatline.get(2));
        }
        
        centerCenterPanel.removeAll();
        
        for (int i = 0; i < userArrayList.size(); i++) 
        {
            String modifiedString = messageHistoryArrayList.get(i);
            if (messageHistoryArrayList.get(i).length() > 59) 
            {
                // Split the string after 10 characters and insert a newline
                modifiedString = "<html>" + messageHistoryArrayList.get(i).substring(0, 59) + "<br>" + messageHistoryArrayList.get(i).substring(59) + "</html>";
            }
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(new EmptyBorder(0, 0, 20, 0));
            panel.setBackground(Color.WHITE);
            centerCenterPanel.add(panel);
            JLabel userChat = new JLabel(modifiedString);
            userChat.setFont(new Font("Arial", Font.PLAIN, 38));
            if(userArrayList.get(i).equals("guardian"))
            {
                userChat.setIcon(new ImageIcon("user.png"));
                panel.add(userChat);
            }
            else
            {
                userChat.setHorizontalAlignment(SwingConstants.RIGHT);
                JLabel iconLabel = new JLabel(new ImageIcon("user(1).png"));
                panel.add(userChat);
                panel.add(iconLabel, BorderLayout.EAST);
            }
        }
        dashboard.revalidate();
        dashboard.repaint();
    }
    String getGuardianID(String userID)
    {
        String guardianID = null;
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                MedicalTherapistUser therapist = (MedicalTherapistUser) userAcc;
                guardianID = (String)(therapist.getAppointmentList().get(0).get(0));
                guardianID = guardianID.replaceAll("a", "g");
                guardianID = guardianID.replaceAll("e", "g");
                break;
            }
        }
        return guardianID;
    }
}