import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;
import java.util.*;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.web.WebView;

import java.util.Properties;
import java.util.Random;
import javax.mail.*;
import javax.mail.internet.*;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.web.WebView;

import javax.swing.plaf.metal.MetalCheckBoxIcon;

public class CompanionEmergencyAlertGUI extends JPanel implements DashboardContentParentGUI
{
    private final JFXPanel jfxPanel;
    private WebView webView;
    private static final String FROM_EMAIL = "vincentoong12345@gmail.com"; // Replace with your email
    private static final String EMAIL_PASSWORD = "lmlp suwp mhdi mxlu";  // Replace with your app password
    //String otp = null;
    public CompanionEmergencyAlertGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        JLabel  Location = new JLabel("Pendant Location");
        Location.setFont(new Font("Arial", Font.BOLD, 40));
        Location.setBorder(new EmptyBorder(13, 40, 0, 0));
        add(Location, BorderLayout.NORTH);
        
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        add(mainPanel);
        
        
        jfxPanel = new JFXPanel();
        
        JPanel controlPanel = new JPanel();
        JTextField searchField = new JTextField(getEmergencyContactAddress(userID));
        JButton searchButton = new JButton("Search");
        JButton zoomInButton = new JButton("+");
        JButton zoomOutButton = new JButton("-");

        controlPanel.add(new JLabel("Location:"));
        controlPanel.add(searchField);
        controlPanel.add(searchButton);
        controlPanel.add(zoomInButton);
        controlPanel.add(zoomOutButton);
        
        mainPanel.add(controlPanel, BorderLayout.NORTH);
        mainPanel.add(jfxPanel, BorderLayout.CENTER);

        // Initialize JavaFX
        Platform.runLater(this::initFX);

        // Add button listeners
        searchButton.addActionListener(e -> {
            String location = searchField.getText();
            Platform.runLater(() -> {
                webView.getEngine().executeScript(
                    "searchLocation('" + location.replace("'", "\\'") + "');"
                );
            });
        });

        zoomInButton.addActionListener(e -> 
            Platform.runLater(() -> webView.getEngine().executeScript("map.zoomIn();"))
        );

        zoomOutButton.addActionListener(e -> 
            Platform.runLater(() -> webView.getEngine().executeScript("map.zoomOut();"))
        );
        
        
        
        JPanel triggerAlertButtonPanel = new JPanel();
        triggerAlertButtonPanel.setBorder(new EmptyBorder(3, 0, 15, 0));
        triggerAlertButtonPanel.setBackground(Color.WHITE);
        add(triggerAlertButtonPanel, BorderLayout.SOUTH);
        JButton triggerAlert = new JButton("Trigger Alert");
        triggerAlert.setMaximumSize(new Dimension(170, 55));
        triggerAlert.setAlignmentX(Component.CENTER_ALIGNMENT);
        triggerAlert.setFont(new Font("Arial", Font.BOLD, 40));
        triggerAlert.setBackground(Color.WHITE);
        triggerAlert.setForeground(Color.BLACK);
        triggerAlert.setBorder(new LineBorder(Color.BLACK, 7));
        triggerAlert.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                int response = JOptionPane.showConfirmDialog(
                null,
                "Do you want to trigger an emergency alert?",
                "Confirmation",
                JOptionPane.YES_NO_CANCEL_OPTION
                );
                if (response == JOptionPane.YES_OPTION)
                {
                    JOptionPane.showMessageDialog(null, "Alert triggered!!!");
                    try {
                        String recipientEmail = getEmergencyContactEmail(userID); // Replace with recipient's email
                        //otp = generateOTP();
            
                        sendOTP(recipientEmail);
                        System.out.println("Alert sent successfully to " + recipientEmail);
                        //System.out.println("Generated OTP: " + otp);
            
                    } catch (MessagingException e) {
                        System.out.println("Error sending email: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        });
        triggerAlertButtonPanel.add(triggerAlert);
        
        
    }
    public JPanel getPanel() {return CompanionEmergencyAlertGUI.this;}
    
    
    
    //Use this to get all emails
    public String getEmergencyContactEmail(String userID)
    {
        String email = null;
        ArrayList<ArrayList> emergencyContactList = new ArrayList<ArrayList>();
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                CompanionUser companion = (CompanionUser) userAcc;
                emergencyContactList = companion.getEmergencyContactList();
                email = (String)emergencyContactList.get(0).get(3);
            }
        }
        return email;
    }
    
    public String getEmergencyContactAddress(String userID)
    {
        String address = null;
        ArrayList<ArrayList> emergencyContactList = new ArrayList<ArrayList>();
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                CompanionUser companion = (CompanionUser) userAcc;
                emergencyContactList = companion.getEmergencyContactList();
                address = (String)emergencyContactList.get(0).get(4);
            }
        }
        return address;
    }
    
    private void initFX() {
        webView = new WebView();
        jfxPanel.setScene(new Scene(webView));

        String mapContent = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>OpenStreetMap Example</title>
                <meta charset="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
                <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
                <style>
                    #map { height: 100vh; width: 100%; }
                    body { margin: 0; padding: 0; }
                </style>
            </head>
            <body>
                <div id="map"></div>
                <script>
                    // Initialize the map
                    var map = L.map('map').setView([0, 0], 2);
                    
                    // Add OpenStreetMap tiles
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        maxZoom: 19,
                        attribution: '© OpenStreetMap contributors'
                    }).addTo(map);
                    
                    var currentMarker = null;
                    
                    // Function to search location using Nominatim
                    function searchLocation(query) {
                        fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
                            .then(response => response.json())
                            .then(data => {
                                if (data.length > 0) {
                                    const lat = parseFloat(data[0].lat);
                                    const lon = parseFloat(data[0].lon);
                                    
                                    // Remove existing marker
                                    if (currentMarker) {
                                        map.removeLayer(currentMarker);
                                    }
                                    
                                    // Add new marker
                                    currentMarker = L.marker([lat, lon]).addTo(map);
                                    
                                    // Center map on location
                                    map.setView([lat, lon], 13);
                                }
                            })
                            .catch(error => console.error('Error:', error));
                    }
                    
                    // Add click handler to map
                    map.on('click', function(e) {
                        if (currentMarker) {
                            map.removeLayer(currentMarker);
                        }
                        currentMarker = L.marker(e.latlng).addTo(map);
                    });
                </script>
            </body>
            </html>
        """;

        webView.getEngine().loadContent(mapContent);
    }
    
    // Send OTP via email
    public static void sendOTP(String toEmail) throws MessagingException {
        // Configure email properties
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        
        // Create session with authentication
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, EMAIL_PASSWORD);
            }
        });
        
        // Create message
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(FROM_EMAIL));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
        message.setSubject("Elderly Care Alert");
        message.setText("Your elder needs immediate attention!!!");
        
        // Send message
        Transport.send(message);
    }
}