import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;
import java.sql.*;

public class GuardianNextGUI extends JFrame
{
    static String Name = null;
    static String Username = null;
    static String Password = null;
    static String Email = null;
    static Integer Phone = null;
    static String Address = null;
    static Integer elderAge = null;
    static String elderName = null;
    static String elderGender = null;
    static String MedicalRecord = null;
    static String elderAddress = null;
    public GuardianNextGUI(String name, String username, String password, String email, int phoneNumber, String address)
    {
        super("GUARDIAN");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        Name = name;
        Username = username;
        Password = password;
        Email = email;
        Phone = phoneNumber;
        Address = address;
        
        JPanel guardianNextPanel = new JPanel();
        guardianNextPanel.setLayout(new BoxLayout(guardianNextPanel, BoxLayout.Y_AXIS));
        guardianNextPanel.setBackground(Color.WHITE);
        add(guardianNextPanel);
        
        
        JPanel logoPanel = new JPanel();
        logoPanel.setPreferredSize(new Dimension(Integer.MAX_VALUE, 20));
        logoPanel.setBackground(Color.WHITE);
        guardianNextPanel.add(logoPanel);
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(321, 242, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoPanel.add(iconLabel);
        
        JPanel contentPanel = new JPanel();
        contentPanel.setBorder(new EmptyBorder(30, 0, 0, 0));
        contentPanel.setPreferredSize(new Dimension(Integer.MAX_VALUE, 410));
        contentPanel.setBackground(new Color(68,147,186,255));
        guardianNextPanel.add(contentPanel);
        
        JPanel bigPanel = new JPanel();
        bigPanel.setBorder(new EmptyBorder(20, 0, 0, 0));
        bigPanel.setPreferredSize(new Dimension(700, 520));
        bigPanel.setLayout(new BoxLayout(bigPanel, BoxLayout.Y_AXIS));
        bigPanel.setBackground(Color.WHITE);
        contentPanel.add(bigPanel);
        
        JLabel role = new JLabel("Guardian");
        role.setPreferredSize(new Dimension(100, 40));
        role.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 34));
        role.setForeground(Color.BLACK);
        role.setAlignmentX(Component.CENTER_ALIGNMENT);
        bigPanel.add(role);
        
        JPanel elderNamePanel = new JPanel();
        elderNamePanel.setBackground(Color.WHITE);
        bigPanel.add(elderNamePanel);
        JLabel elderNameLabel = new JLabel("Elder's Name:");
        elderNameLabel.setPreferredSize(new Dimension(190, 40));
        elderNameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderNamePanel.add(elderNameLabel);
        JTextField elderNameTextField = new JTextField();
        elderNameTextField.setColumns(20);
        elderNameTextField.setPreferredSize(new Dimension(40, 40));
        elderNameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border nameBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        elderNameTextField.setBorder(nameBottomBorder);
        elderNamePanel.add(elderNameTextField);
        
        JPanel elderAgePanel = new JPanel();
        elderAgePanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderAgePanel.setBackground(Color.WHITE);
        bigPanel.add(elderAgePanel);
        JLabel elderAgeLabel = new JLabel("Elder's Age:");
        elderAgeLabel.setPreferredSize(new Dimension(170, 40));
        elderAgeLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderAgePanel.add(elderAgeLabel);
        JTextField elderAgeTextField = new JTextField();
        elderAgeTextField.setColumns(20);
        elderAgeTextField.setPreferredSize(new Dimension(40, 40));
        elderAgeTextField.setFont(new Font("Arial", Font.PLAIN, 23));
        Border userNameBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        elderAgeTextField.setBorder(userNameBottomBorder);
        elderAgePanel.add(elderAgeTextField);
        
        JPanel elderGenderPanel = new JPanel();
        elderGenderPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderGenderPanel.setBackground(Color.WHITE);
        bigPanel.add(elderGenderPanel);
        JLabel elderGenderLabel = new JLabel("Elder's Gender:");
        elderGenderLabel.setPreferredSize(new Dimension(210, 40));
        elderGenderLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderGenderPanel.add(elderGenderLabel);
        JTextField elderGenderTextField = new JTextField();
        elderGenderTextField.setColumns(20);
        elderGenderTextField.setPreferredSize(new Dimension(40, 40));
        elderGenderTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border phoneBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        elderGenderTextField.setBorder(phoneBottomBorder);
        elderGenderPanel.add(elderGenderTextField);
        
        JPanel medicalRecord = new JPanel();
        medicalRecord.setBorder(new EmptyBorder(5, 0, 0, 0));
        medicalRecord.setBackground(Color.WHITE);
        bigPanel.add(medicalRecord);
        JLabel medicalRecordLabel = new JLabel("Medical Record:");
        medicalRecordLabel.setPreferredSize(new Dimension(220, 40));
        medicalRecordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        medicalRecord.add(medicalRecordLabel);
        JTextArea medicalRecordTextArea = new JTextArea(5, 20);
        medicalRecordTextArea.setPreferredSize(new Dimension(70, 160));
        medicalRecordTextArea.setFont(new Font("Arial", Font.PLAIN, 23));
        medicalRecordTextArea.setBorder(new LineBorder(new Color(68,147,186,255), 4));
        medicalRecord.add(medicalRecordTextArea);
        
        JPanel addressPanel = new JPanel();
        addressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        addressPanel.setBackground(Color.WHITE);
        bigPanel.add(addressPanel);
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setPreferredSize(new Dimension(130, 40));
        addressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        addressPanel.add(addressLabel);
        JTextField addressTextField = new JTextField();
        addressTextField.setColumns(20);
        addressTextField.setPreferredSize(new Dimension(40, 40));
        addressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border addressBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        addressTextField.setBorder(addressBottomBorder);
        addressPanel.add(addressTextField);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        buttonPanel.setBackground(Color.WHITE);
        bigPanel.add(buttonPanel);
        JButton submit = new JButton("Submit");
        submit.setPreferredSize(new Dimension(140, 45));
        submit.setFont(new Font("Arial", Font.BOLD, 30));
        submit.setBackground(Color.WHITE);
        submit.setForeground(new Color(68,147,186,255));
        submit.setBorder(new LineBorder(new Color(68,147,186,255), 5));
        submit.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                JOptionPane.showMessageDialog(null, "Pending for approval...");
                elderAge = Integer.parseInt(elderAgeTextField.getText());
                elderName = elderNameTextField.getText();
                elderGender = elderGenderTextField.getText();
                MedicalRecord = medicalRecordTextArea.getText();
                elderAddress = addressTextField.getText();
                
                addToPendingUserAcc();
                
                //new OtpAuthentication(GuardianNextGUI.this, "guardian", "g00"+Integer.toString(MainLogic.userAccCount+1));
                new LoginGUI();
                dispose();
            }
        });
        buttonPanel.add(submit);
        
        
        
        
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    public static void createAcc()
    {
        User guardianUser = new GuardianUser("g00"+Integer.toString(MainLogic.userAccCount+1), Name, Username, Password, "therapist", Email, Phone, Address, "e00"+Integer.toString(MainLogic.userAccCount+1), elderName, elderAge, elderGender, MedicalRecord, elderAddress);
        guardianUser.setDatabaseInfo("g00"+Integer.toString(MainLogic.userAccCount+1), Name, Username, Password, "therapist", Email, Phone, null, null, Address);
        MainLogic.userAccCount++;
        MainLogic.userAccount.add(guardianUser);
    }
    void addToPendingUserAcc()
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "INSERT INTO userapproval VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            statement.setString(1, "g00"+Integer.toString(MainLogic.userAccCount+1));
            statement.setString(2, Name);
            statement.setString(3, Username);
            statement.setString(4, Password);
            statement.setString(5, "guardian");
            statement.setString(6, Email);
            statement.setInt(7, Phone);
            statement.setNull(8, Types.INTEGER);
            statement.setNull(9, Types.VARCHAR);
            statement.setString(10, Address);
            
            statement.executeUpdate();
            
            query = "INSERT INTO elderinfo VALUES(?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            statement.setString(1, "e00"+Integer.toString(MainLogic.userAccCount+1));
            statement.setString(2, elderName);
            statement.setInt(3, elderAge);
            statement.setString(4, elderGender);
            statement.setString(5, MedicalRecord);
            statement.setString(6, elderAddress);
            statement.setString(7, "g00"+Integer.toString(MainLogic.userAccCount+1));
            
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}