import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class GuardianProfileGUI extends JPanel implements DashboardContentParentGUI
{
    public GuardianProfileGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        JPanel guardianInfoPanel = new JPanel();
        guardianInfoPanel.setBackground(Color.WHITE);
        guardianInfoPanel.setLayout(new BoxLayout(guardianInfoPanel, BoxLayout.Y_AXIS));
        guardianInfoPanel.setBorder(new EmptyBorder(50, 100, 0, 0));
        add(guardianInfoPanel, BorderLayout.WEST);
        
        JPanel guardianRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianRolePanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianRolePanel);
        JLabel guardianRole = new JLabel("Guardian");
        guardianRole.setPreferredSize(new Dimension(210, 40));
        guardianRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        guardianRole.setForeground(Color.BLACK);
        Border groleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        guardianRole.setBorder(groleBottomBorder);
        guardianRolePanel.add(guardianRole);
        
        JPanel guardianUsernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianUsernamePanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianUsernamePanel);
        JLabel guardianUsernameLabel = new JLabel("Username:");
        guardianUsernameLabel.setPreferredSize(new Dimension(140, 40));
        guardianUsernameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianUsernamePanel.add(guardianUsernameLabel);
        JTextField guardianUsernameTextField = new JTextField(getUserData(userID, 2));
        guardianUsernameTextField.setColumns(20);
        guardianUsernameTextField.setPreferredSize(new Dimension(40, 40));
        guardianUsernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianUsernameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianUsernameTextField.setEditable(false);
        guardianUsernamePanel.add(guardianUsernameTextField);
        
        JPanel guardianPhoneNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianPhoneNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianPhoneNumberPanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianPhoneNumberPanel);
        JLabel guardianPhoneNumberLabel = new JLabel("Phone Number:");
        guardianPhoneNumberLabel.setPreferredSize(new Dimension(200, 40));
        guardianPhoneNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianPhoneNumberPanel.add(guardianPhoneNumberLabel);
        JTextField guardianPhoneNumberTextField = new JTextField(getUserData(userID, 6));
        guardianPhoneNumberTextField.setColumns(20);
        guardianPhoneNumberTextField.setPreferredSize(new Dimension(40, 40));
        guardianPhoneNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianPhoneNumberTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianPhoneNumberTextField.setEditable(false);
        guardianPhoneNumberPanel.add(guardianPhoneNumberTextField);
        
        JPanel guardianEmailPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianEmailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianEmailPanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianEmailPanel);
        JLabel guardianEmailLabel = new JLabel("Email:");
        guardianEmailLabel.setPreferredSize(new Dimension(90, 40));
        guardianEmailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianEmailPanel.add(guardianEmailLabel);
        JTextField guardianEmailTextField = new JTextField(getUserData(userID, 5));
        guardianEmailTextField.setColumns(20);
        guardianEmailTextField.setPreferredSize(new Dimension(40, 40));
        guardianEmailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianEmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianEmailTextField.setEditable(false);
        guardianEmailPanel.add(guardianEmailTextField);
        
        JPanel guardianAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianAddressPanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianAddressPanel);
        JLabel guardianAddressLabel = new JLabel("Address:");
        guardianAddressLabel.setPreferredSize(new Dimension(120, 40));
        guardianAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianAddressPanel.add(guardianAddressLabel);
        JTextField guardianAddressTextField = new JTextField(getUserData(userID, 7));
        guardianAddressTextField.setColumns(20);
        guardianAddressTextField.setPreferredSize(new Dimension(40, 40));
        guardianAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianAddressTextField.setEditable(false);
        guardianAddressPanel.add(guardianAddressTextField);
        
        JPanel guardianPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianPasswordPanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianPasswordPanel);
        JLabel guardianPasswordLabel = new JLabel("Password:");
        guardianPasswordLabel.setPreferredSize(new Dimension(140, 40));
        guardianPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianPasswordPanel.add(guardianPasswordLabel);
        JTextField guardianPasswordTextField = new JTextField(getUserData(userID, 3));
        guardianPasswordTextField.setColumns(20);
        guardianPasswordTextField.setPreferredSize(new Dimension(40, 40));
        guardianPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianPasswordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianPasswordTextField.setEditable(false);
        guardianPasswordPanel.add(guardianPasswordTextField);
        
        
        JPanel elderInfoPanel = new JPanel();
        elderInfoPanel.setBackground(Color.WHITE);
        elderInfoPanel.setLayout(new BoxLayout(elderInfoPanel, BoxLayout.Y_AXIS));
        elderInfoPanel.setBorder(new EmptyBorder(50, 100, 0, 0));
        add(elderInfoPanel);
        
        JPanel elderRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderRolePanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderRolePanel);
        JLabel elderRole = new JLabel("Elder");
        elderRole.setPreferredSize(new Dimension(125, 40));
        elderRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        elderRole.setForeground(Color.BLACK);
        Border eroleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        elderRole.setBorder(eroleBottomBorder);
        elderRolePanel.add(elderRole);
        
        JPanel elderNamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderNamePanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderNamePanel);
        JLabel elderNameLabel = new JLabel("Name:");
        elderNameLabel.setPreferredSize(new Dimension(85, 40));
        elderNameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderNamePanel.add(elderNameLabel);
        JTextField elderNameTextField = new JTextField(getElderData(userID, 1));
        elderNameTextField.setColumns(20);
        elderNameTextField.setPreferredSize(new Dimension(40, 40));
        elderNameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderNameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderNameTextField.setEditable(false);
        elderNamePanel.add(elderNameTextField);
        
        JPanel elderAgePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderAgePanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderAgePanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderAgePanel);
        JLabel elderAgeLabel = new JLabel("Age:");
        elderAgeLabel.setPreferredSize(new Dimension(65, 40));
        elderAgeLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderAgePanel.add(elderAgeLabel);
        JTextField elderAgeTextField = new JTextField(getElderData(userID, 2));
        elderAgeTextField.setColumns(20);
        elderAgeTextField.setPreferredSize(new Dimension(40, 40));
        elderAgeTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderAgeTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderAgeTextField.setEditable(false);
        elderAgePanel.add(elderAgeTextField);
        
        JPanel elderGenderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderGenderPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderGenderPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderGenderPanel);
        JLabel elderGenderLabel = new JLabel("Gender:");
        elderGenderLabel.setPreferredSize(new Dimension(110, 40));
        elderGenderLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderGenderPanel.add(elderGenderLabel);
        JTextField elderGenderTextField = new JTextField(getElderData(userID, 3));
        elderGenderTextField.setColumns(20);
        elderGenderTextField.setPreferredSize(new Dimension(40, 40));
        elderGenderTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderGenderTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderGenderTextField.setEditable(false);
        elderGenderPanel.add(elderGenderTextField);
        
        JPanel elderMedicalRecordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderMedicalRecordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderMedicalRecordPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderMedicalRecordPanel);
        JLabel elderMedicalRecordLabel = new JLabel("Medical Record:");
        elderMedicalRecordLabel.setPreferredSize(new Dimension(210, 40));
        elderMedicalRecordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderMedicalRecordPanel.add(elderMedicalRecordLabel);
        JTextField elderMedicalRecordTextField = new JTextField(getElderData(userID, 4));
        elderMedicalRecordTextField.setColumns(20);
        elderMedicalRecordTextField.setPreferredSize(new Dimension(40, 40));
        elderMedicalRecordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderMedicalRecordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderMedicalRecordTextField.setEditable(false);
        elderMedicalRecordPanel.add(elderMedicalRecordTextField);
        
        JPanel elderAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderAddressPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderAddressPanel);
        JLabel elderAddressLabel = new JLabel("Address:");
        elderAddressLabel.setPreferredSize(new Dimension(120, 40));
        elderAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderAddressPanel.add(elderAddressLabel);
        JTextField elderAddressTextField = new JTextField(getElderData(userID, 5));
        elderAddressTextField.setColumns(20);
        elderAddressTextField.setPreferredSize(new Dimension(40, 40));
        elderAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderAddressTextField.setEditable(false);
        elderAddressPanel.add(elderAddressTextField);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBorder(new EmptyBorder(0, 0, 0, 50));
        buttonPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(buttonPanel);
        JButton update = new JButton("Update Profile");
        update.setPreferredSize(new Dimension(230, 70));
        update.setFont(new Font("Serif", Font.BOLD, 30));
        update.setBackground(new Color(68,147,186,255));
        update.setForeground(Color.BLACK);
        update.setBorder(new LineBorder(Color.BLACK, 7));
        update.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                GuardianEditProfileGUI guardianEditProfilePanel = new GuardianEditProfileGUI(dashboard, userID);
                dashboard.remove(GuardianProfileGUI.this);
                dashboard.add(guardianEditProfilePanel.getPanel(), BorderLayout.CENTER);
                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        buttonPanel.add(update);
    }
    public JPanel getPanel() {return GuardianProfileGUI.this;}
    public String getUserData(String userID, int index)
    {
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                String data = String.valueOf(userAcc.getUserInfo().get(index));
                return data;
            }
        }
        return null;
    }
    public String getElderData(String userID, int index)
    {
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                String data = String.valueOf(userAcc.getElderInfo().get(index));
                return data;
            }
        }
        return null;
    }
}