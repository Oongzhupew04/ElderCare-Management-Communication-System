import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;

public class GuardianDailyReportGUI extends JPanel implements DashboardContentParentGUI
{
    public GuardianDailyReportGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(new EmptyBorder(20, 20, 0, 20));
        add(leftPanel, BorderLayout.WEST);
        
        JPanel centerTopPanel = new JPanel();
        centerTopPanel.setBackground(Color.WHITE);
        centerPanel.add(centerTopPanel, BorderLayout.NORTH);
        JPanel centerRightPanel = new JPanel();
        centerRightPanel.setBackground(Color.WHITE);
        centerPanel.add(centerRightPanel, BorderLayout.EAST);
        JPanel centerCenterPanel = new JPanel();
        centerCenterPanel.setLayout(new BoxLayout(centerCenterPanel, BoxLayout.Y_AXIS));
        centerCenterPanel.setBackground(Color.WHITE);
        centerPanel.add(centerCenterPanel);
        
        
        
        JPanel datePanel = new JPanel();
        datePanel.setBackground(Color.WHITE);
        centerTopPanel.add(datePanel);
        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setPreferredSize(new Dimension(120, 40));
        dateLabel.setFont(new Font("Arial", Font.BOLD, 40));
        datePanel.add(dateLabel);
        JTextField dateTextField = new JTextField();
        dateTextField.setColumns(7);
        dateTextField.setPreferredSize(new Dimension(40, 40));
        dateTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        dateTextField.setBorder(new LineBorder(Color.BLACK, 5));
        datePanel.add(dateTextField);
        
        
        JPanel guardianRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianRolePanel.setBackground(Color.WHITE);
        centerCenterPanel.add(guardianRolePanel);
        JLabel guardianRole = new JLabel("Daily Report");
        guardianRole.setPreferredSize(new Dimension(290, 50));
        guardianRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        guardianRole.setForeground(Color.BLACK);
        Border groleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        guardianRole.setBorder(groleBottomBorder);
        guardianRolePanel.add(guardianRole);
        
        JPanel guardianUsernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianUsernamePanel.setBackground(Color.WHITE);
        centerCenterPanel.add(guardianUsernamePanel);
        JLabel guardianUsernameLabel = new JLabel("Amount of meal:");
        guardianUsernameLabel.setPreferredSize(new Dimension(220, 40));
        guardianUsernameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianUsernamePanel.add(guardianUsernameLabel);
        JTextField guardianUsernameTextField = new JTextField();
        guardianUsernameTextField.setColumns(5);
        guardianUsernameTextField.setPreferredSize(new Dimension(40, 40));
        guardianUsernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianUsernameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianUsernameTextField.setEditable(false);
        guardianUsernamePanel.add(guardianUsernameTextField);
        
        JPanel guardianPhoneNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianPhoneNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianPhoneNumberPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(guardianPhoneNumberPanel);
        JLabel guardianPhoneNumberLabel = new JLabel("Blood pressure:");
        guardianPhoneNumberLabel.setPreferredSize(new Dimension(215, 40));
        guardianPhoneNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianPhoneNumberPanel.add(guardianPhoneNumberLabel);
        JTextField guardianPhoneNumberTextField = new JTextField();
        guardianPhoneNumberTextField.setColumns(10);
        guardianPhoneNumberTextField.setPreferredSize(new Dimension(40, 40));
        guardianPhoneNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianPhoneNumberTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianPhoneNumberTextField.setEditable(false);
        guardianPhoneNumberPanel.add(guardianPhoneNumberTextField);
        
        JPanel guardianEmailPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianEmailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianEmailPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(guardianEmailPanel);
        JLabel guardianEmailLabel = new JLabel("Exercise/Activity:");
        guardianEmailLabel.setPreferredSize(new Dimension(230, 40));
        guardianEmailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianEmailPanel.add(guardianEmailLabel);
        JTextField guardianEmailTextField = new JTextField();
        guardianEmailTextField.setColumns(20);
        guardianEmailTextField.setPreferredSize(new Dimension(40, 40));
        guardianEmailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianEmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianEmailTextField.setEditable(false);
        guardianEmailPanel.add(guardianEmailTextField);
        
        JPanel guardianAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianAddressPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(guardianAddressPanel);
        JLabel guardianAddressLabel = new JLabel("Medicine:");
        guardianAddressLabel.setPreferredSize(new Dimension(160, 40));
        guardianAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianAddressPanel.add(guardianAddressLabel);
        JTextField guardianAddressTextField = new JTextField();
        guardianAddressTextField.setColumns(23);
        guardianAddressTextField.setPreferredSize(new Dimension(40, 40));
        guardianAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianAddressTextField.setEditable(false);
        guardianAddressPanel.add(guardianAddressTextField);
        
        JPanel guardianPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianPasswordPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(guardianPasswordPanel);
        JLabel guardianPasswordLabel = new JLabel("Note:");
        guardianPasswordLabel.setPreferredSize(new Dimension(80, 40));
        guardianPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianPasswordPanel.add(guardianPasswordLabel);
        JTextArea medicalRecordTextArea = new JTextArea(6, 40);
        medicalRecordTextArea.setText("");
        medicalRecordTextArea.setPreferredSize(new Dimension(70, 160));
        medicalRecordTextArea.setFont(new Font("Arial", Font.PLAIN, 20));
        medicalRecordTextArea.setBorder(new LineBorder(Color.BLACK, 5));
        medicalRecordTextArea.setEditable(false);
        guardianPasswordPanel.add(medicalRecordTextArea);
        
        
        JButton view = new JButton("View");
        view.setMaximumSize(new Dimension(170, 55));
        view.setAlignmentX(Component.CENTER_ALIGNMENT);
        view.setFont(new Font("Arial", Font.BOLD, 40));
        view.setBackground(Color.WHITE);
        view.setForeground(Color.BLACK);
        view.setBorder(new LineBorder(Color.BLACK, 7));
        view.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                ArrayList<ArrayList> dailyReportList = null;
                Boolean found = false;
                for(User userAcc : MainLogic.userAccount)
                {
                    if((userAcc.getUserInfo().get(0)).equals(userID))
                    {
                        GuardianUser guardian = (GuardianUser) userAcc;
                        dailyReportList = guardian.getDailyReportList();
                        break;
                    }
                }
                for (ArrayList report : dailyReportList)
                {
                    if(((String)report.get(0)).equals(dateTextField.getText()))
                    {
                        guardianUsernameTextField.setText(Integer.toString((Integer)report.get(1)));
                        guardianPhoneNumberTextField.setText((String)report.get(2));
                        guardianEmailTextField.setText((String)report.get(3));
                        guardianAddressTextField.setText((String)report.get(4));
                        medicalRecordTextArea.setText((String)report.get(5));
                        found = true;
                                
                        dashboard.revalidate();
                        dashboard.repaint();
                        break;
                    }
                }
                if(!found)
                {
                    JOptionPane.showMessageDialog(null, "No daily report found for this date.");
                }
            }
        });
        datePanel.add(view);
        

        
        
        JButton dailyReport = new JButton("<html>Daily<br>Report</html>");
        dailyReport.setMaximumSize(new Dimension(150, 110));
        dailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        dailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        dailyReport.setBackground(Color.WHITE);
        dailyReport.setForeground(Color.BLACK);
        dailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        dailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                
            }
        });
        leftPanel.add(dailyReport);
        
        
        JPanel medicalReportButtonPanel = new JPanel();
        medicalReportButtonPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        medicalReportButtonPanel.setBackground(new Color(238,238,238,255));
        leftPanel.add(medicalReportButtonPanel);
        JButton medicalReport = new JButton("<html>Medical<br>Report</html>");
        medicalReport.setMaximumSize(new Dimension(150, 110));
        medicalReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        medicalReport.setFont(new Font("Arial", Font.BOLD, 40));
        medicalReport.setBackground(Color.WHITE);
        medicalReport.setForeground(Color.BLACK);
        medicalReport.setBorder(new LineBorder(Color.BLACK, 7));
        medicalReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                GuardianMedicalReportGUI guardianMedicalReportGUI = new GuardianMedicalReportGUI(dashboard, userID);
                dashboard.remove(GuardianDailyReportGUI.this);
                dashboard.add(guardianMedicalReportGUI.getPanel(), BorderLayout.CENTER);
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        medicalReportButtonPanel.add(medicalReport);
        
    }
    public JPanel getPanel() {return GuardianDailyReportGUI.this;}
}