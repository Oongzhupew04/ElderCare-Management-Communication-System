import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class ForgotPasswordGUI extends JFrame
{
    public ForgotPasswordGUI(String role, String userID)
    {
        super("FORGOT PASSWORD");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        JPanel fogotPassowrdPanel = new JPanel();
        fogotPassowrdPanel.setLayout(new BoxLayout(fogotPassowrdPanel, BoxLayout.Y_AXIS));
        fogotPassowrdPanel.setBackground(Color.WHITE);
        add(fogotPassowrdPanel);
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(513, 387, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        fogotPassowrdPanel.add(iconLabel);
        
        
        JLabel forgotPassword = new JLabel("Reset password");
        forgotPassword.setFont(new Font("Arial", Font.BOLD, 54));
        forgotPassword.setBorder(new EmptyBorder(0, 0, 50, 0));
        forgotPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
        fogotPassowrdPanel.add(forgotPassword);
        
        JLabel enterGmailAuthentication = new JLabel("Please enter your Gmail account");
        enterGmailAuthentication.setFont(new Font("Arial", Font.BOLD, 24));
        enterGmailAuthentication.setBorder(new EmptyBorder(0, 0, 10, 0));
        enterGmailAuthentication.setAlignmentX(Component.CENTER_ALIGNMENT);
        fogotPassowrdPanel.add(enterGmailAuthentication);
        JTextField enterGmailTextField = new JTextField();
        enterGmailTextField.setColumns(10);
        enterGmailTextField.setMaximumSize(new Dimension(400, 50));
        enterGmailTextField.setFont(new Font("Arial", Font.PLAIN, 24));
        enterGmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        fogotPassowrdPanel.add(enterGmailTextField);
        
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        fogotPassowrdPanel.add(buttonPanel);
        JButton confirm = new JButton("Confirm");
        confirm.setMaximumSize(new Dimension(110, 45));
        confirm.setAlignmentX(Component.CENTER_ALIGNMENT);
        confirm.setFont(new Font("Arial", Font.BOLD, 24));
        confirm.setBackground(Color.BLACK);
        confirm.setForeground(Color.WHITE);
        confirm.setBorder(new LineBorder(Color.BLACK, 5));
        confirm.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new OtpAuthentication(ForgotPasswordGUI.this, role, userID);
                dispose();
            }
        });
        buttonPanel.add(confirm);
        
        
        
                
        
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}