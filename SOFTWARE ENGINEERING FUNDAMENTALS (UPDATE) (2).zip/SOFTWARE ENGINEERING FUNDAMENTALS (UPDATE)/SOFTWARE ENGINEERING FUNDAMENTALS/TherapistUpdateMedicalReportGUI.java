import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;

public class TherapistUpdateMedicalReportGUI extends JPanel implements DashboardContentParentGUI
{
    public TherapistUpdateMedicalReportGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(new EmptyBorder(20, 20, 0, 20));
        add(leftPanel, BorderLayout.WEST);
        
        JPanel centerTopPanel = new JPanel();
        centerTopPanel.setBackground(Color.WHITE);
        centerPanel.add(centerTopPanel, BorderLayout.NORTH);
        JPanel centerRightPanel = new JPanel(new BorderLayout());
        centerRightPanel.setBackground(Color.WHITE);
        centerPanel.add(centerRightPanel, BorderLayout.EAST);
        JPanel centerCenterPanel = new JPanel();
        centerCenterPanel.setLayout(new BoxLayout(centerCenterPanel, BoxLayout.Y_AXIS));
        centerCenterPanel.setBackground(Color.WHITE);
        centerPanel.add(centerCenterPanel);
        
        
        
        JPanel datePanel = new JPanel();
        datePanel.setBackground(Color.WHITE);
        centerTopPanel.add(datePanel);
        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setPreferredSize(new Dimension(120, 40));
        dateLabel.setFont(new Font("Arial", Font.BOLD, 40));
        datePanel.add(dateLabel);
        JTextField dateTextField = new JTextField();
        dateTextField.setColumns(7);
        dateTextField.setPreferredSize(new Dimension(40, 40));
        dateTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        dateTextField.setBorder(new LineBorder(Color.BLACK, 5));
        datePanel.add(dateTextField);
        
        
        JPanel therapistRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistRolePanel.setBackground(Color.WHITE);
        centerCenterPanel.add(therapistRolePanel);
        JLabel therapistRole = new JLabel("Medical Report");
        therapistRole.setPreferredSize(new Dimension(360, 50));
        therapistRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        therapistRole.setForeground(Color.BLACK);
        Border groleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        therapistRole.setBorder(groleBottomBorder);
        therapistRolePanel.add(therapistRole);
        
        JPanel therapistUsernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistUsernamePanel.setBackground(Color.WHITE);
        centerCenterPanel.add(therapistUsernamePanel);
        JLabel therapistUsernameLabel = new JLabel("Therapist Service:");
        therapistUsernameLabel.setPreferredSize(new Dimension(240, 40));
        therapistUsernameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistUsernamePanel.add(therapistUsernameLabel);
        JTextField therapistUsernameTextField = new JTextField("");
        therapistUsernameTextField.setColumns(9);
        therapistUsernameTextField.setPreferredSize(new Dimension(40, 40));
        therapistUsernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistUsernameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistUsernamePanel.add(therapistUsernameTextField);
        
        JPanel therapistPhoneNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistPhoneNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistPhoneNumberPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(therapistPhoneNumberPanel);
        JLabel therapistPhoneNumberLabel = new JLabel("Medical History:");
        therapistPhoneNumberLabel.setPreferredSize(new Dimension(215, 40));
        therapistPhoneNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistPhoneNumberPanel.add(therapistPhoneNumberLabel);
        JTextField therapistPhoneNumberTextField = new JTextField("");
        therapistPhoneNumberTextField.setColumns(30);
        therapistPhoneNumberTextField.setPreferredSize(new Dimension(40, 40));
        therapistPhoneNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistPhoneNumberTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistPhoneNumberPanel.add(therapistPhoneNumberTextField);
        
        JPanel therapistEmailPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistEmailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistEmailPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(therapistEmailPanel);
        JLabel therapistEmailLabel = new JLabel("Medication:");
        therapistEmailLabel.setPreferredSize(new Dimension(160, 40));
        therapistEmailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistEmailPanel.add(therapistEmailLabel);
        JTextField therapistEmailTextField = new JTextField("");
        therapistEmailTextField.setColumns(30);
        therapistEmailTextField.setPreferredSize(new Dimension(40, 40));
        therapistEmailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistEmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistEmailPanel.add(therapistEmailTextField);
        
        JPanel therapistAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistAddressPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(therapistAddressPanel);
        JLabel therapistAddressLabel = new JLabel("Dosage:");
        therapistAddressLabel.setPreferredSize(new Dimension(110, 40));
        therapistAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistAddressPanel.add(therapistAddressLabel);
        JTextField therapistAddressTextField = new JTextField("");
        therapistAddressTextField.setColumns(45);
        therapistAddressTextField.setPreferredSize(new Dimension(40, 40));
        therapistAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistAddressPanel.add(therapistAddressTextField);
        
        JPanel therapistPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistPasswordPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(therapistPasswordPanel);
        JLabel therapistPasswordLabel = new JLabel("Note:");
        therapistPasswordLabel.setPreferredSize(new Dimension(80, 40));
        therapistPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistPasswordPanel.add(therapistPasswordLabel);
        JTextArea medicalRecordTextArea = new JTextArea(6, 40);
        medicalRecordTextArea.setText("");
        medicalRecordTextArea.setPreferredSize(new Dimension(70, 160));
        medicalRecordTextArea.setFont(new Font("Arial", Font.PLAIN, 20));
        medicalRecordTextArea.setBorder(new LineBorder(Color.BLACK, 5));
        therapistPasswordPanel.add(medicalRecordTextArea);
        
        JButton saveUpdateDailyReport = new JButton("Save");
        saveUpdateDailyReport.setMaximumSize(new Dimension(150, 110));
        saveUpdateDailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        saveUpdateDailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        saveUpdateDailyReport.setBackground(Color.WHITE);
        saveUpdateDailyReport.setForeground(Color.BLACK);
        saveUpdateDailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        saveUpdateDailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                for(User userAcc : MainLogic.userAccount)
                {
                    if((userAcc.getUserInfo().get(0)).equals(userID))
                    {
                        MedicalTherapistUser therapist = (MedicalTherapistUser) userAcc;
                        ArrayList<Object> appointment = null;
                        for(ArrayList appointments : therapist.getAppointmentList())
                        {
                            if(appointments.get(7).equals((String)therapist.getUserInfo().get(0)))
                            {
                                appointment = appointments;
                            }
                        }
                        String elderID = (String)appointment.get(0);
                        elderID = elderID.replace('a', 'e');
                        therapist.saveMedicalReportDatabase(dateTextField.getText(), therapistUsernameTextField.getText(), therapistPhoneNumberTextField.getText(), therapistEmailTextField.getText(), therapistAddressTextField.getText(), medicalRecordTextArea.getText(), elderID, (String)userAcc.getUserInfo().get(0));
                        JOptionPane.showMessageDialog(null, "Saved");
                        break;
                    }
                }
            }
        });
        centerRightPanel.add(saveUpdateDailyReport, BorderLayout.NORTH);
        
        JButton backUpdateDailyReport = new JButton("Back");
        backUpdateDailyReport.setMaximumSize(new Dimension(150, 110));
        backUpdateDailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        backUpdateDailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        backUpdateDailyReport.setBackground(Color.WHITE);
        backUpdateDailyReport.setForeground(Color.BLACK);
        backUpdateDailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        backUpdateDailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                TherapistMedicalReportGUI therapistMedicalReportGUI = new TherapistMedicalReportGUI(dashboard, userID);
                dashboard.remove(TherapistUpdateMedicalReportGUI.this);
                dashboard.add(therapistMedicalReportGUI.getPanel(), BorderLayout.CENTER);
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        centerRightPanel.add(backUpdateDailyReport, BorderLayout.SOUTH);
        
        
        

        
        
        JButton dailyReport = new JButton("<html>Daily<br>Report</html>");
        dailyReport.setMaximumSize(new Dimension(150, 110));
        dailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        dailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        dailyReport.setBackground(Color.WHITE);
        dailyReport.setForeground(Color.BLACK);
        dailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        dailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                TherapistDailyReportGUI therapistDailyReportGUI = new TherapistDailyReportGUI(dashboard, userID);
                dashboard.remove(TherapistUpdateMedicalReportGUI.this);
                dashboard.add(therapistDailyReportGUI.getPanel(), BorderLayout.CENTER);
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        leftPanel.add(dailyReport);
        
        
        JPanel medicalReportButtonPanel = new JPanel();
        medicalReportButtonPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        medicalReportButtonPanel.setBackground(new Color(238,238,238,255));
        leftPanel.add(medicalReportButtonPanel);
        JButton medicalReport = new JButton("<html>Medical<br>Report</html>");
        medicalReport.setMaximumSize(new Dimension(150, 110));
        medicalReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        medicalReport.setFont(new Font("Arial", Font.BOLD, 40));
        medicalReport.setBackground(Color.WHITE);
        medicalReport.setForeground(Color.BLACK);
        medicalReport.setBorder(new LineBorder(Color.BLACK, 7));
        medicalReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                
            }
        });
        medicalReportButtonPanel.add(medicalReport);
        
    }
    public JPanel getPanel() {return TherapistUpdateMedicalReportGUI.this;}
}