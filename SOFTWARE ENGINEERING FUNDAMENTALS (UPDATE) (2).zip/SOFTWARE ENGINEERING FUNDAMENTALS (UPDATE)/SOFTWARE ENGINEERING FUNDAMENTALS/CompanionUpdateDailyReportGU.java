import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;

public class CompanionUpdateDailyReportGU extends JPanel implements DashboardContentParentGUI
{
    public CompanionUpdateDailyReportGU(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(new EmptyBorder(20, 20, 0, 20));
        add(leftPanel, BorderLayout.WEST);
        
        JPanel centerTopPanel = new JPanel();
        centerTopPanel.setBackground(Color.WHITE);
        centerPanel.add(centerTopPanel, BorderLayout.NORTH);
        JPanel centerRightPanel = new JPanel(new BorderLayout());
        centerRightPanel.setBackground(Color.WHITE);
        centerPanel.add(centerRightPanel, BorderLayout.EAST);
        JPanel centerCenterPanel = new JPanel();
        centerCenterPanel.setLayout(new BoxLayout(centerCenterPanel, BoxLayout.Y_AXIS));
        centerCenterPanel.setBackground(Color.WHITE);
        centerPanel.add(centerCenterPanel);
        
        
        
        JPanel datePanel = new JPanel();
        datePanel.setBackground(Color.WHITE);
        centerTopPanel.add(datePanel);
        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setPreferredSize(new Dimension(120, 40));
        dateLabel.setFont(new Font("Arial", Font.BOLD, 40));
        datePanel.add(dateLabel);
        JTextField dateTextField = new JTextField("");
        dateTextField.setColumns(7);
        dateTextField.setPreferredSize(new Dimension(40, 40));
        dateTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        dateTextField.setBorder(new LineBorder(Color.BLACK, 5));
        datePanel.add(dateTextField);
        
        
        JPanel companionRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionRolePanel.setBackground(Color.WHITE);
        centerCenterPanel.add(companionRolePanel);
        JLabel companionRole = new JLabel("Update Daily Report");
        companionRole.setPreferredSize(new Dimension(470, 50));
        companionRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        companionRole.setForeground(Color.BLACK);
        Border groleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        companionRole.setBorder(groleBottomBorder);
        companionRolePanel.add(companionRole);
        
        JPanel companionUsernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionUsernamePanel.setBackground(Color.WHITE);
        centerCenterPanel.add(companionUsernamePanel);
        JLabel companionUsernameLabel = new JLabel("Amount of meal:");
        companionUsernameLabel.setPreferredSize(new Dimension(220, 40));
        companionUsernameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionUsernamePanel.add(companionUsernameLabel);
        JTextField companionUsernameTextField = new JTextField("");
        companionUsernameTextField.setColumns(5);
        companionUsernameTextField.setPreferredSize(new Dimension(40, 40));
        companionUsernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionUsernameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionUsernamePanel.add(companionUsernameTextField);
        
        JPanel companionPhoneNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionPhoneNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionPhoneNumberPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(companionPhoneNumberPanel);
        JLabel companionPhoneNumberLabel = new JLabel("Blood pressure:");
        companionPhoneNumberLabel.setPreferredSize(new Dimension(215, 40));
        companionPhoneNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionPhoneNumberPanel.add(companionPhoneNumberLabel);
        JTextField companionPhoneNumberTextField = new JTextField("");
        companionPhoneNumberTextField.setColumns(10);
        companionPhoneNumberTextField.setPreferredSize(new Dimension(40, 40));
        companionPhoneNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionPhoneNumberTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionPhoneNumberPanel.add(companionPhoneNumberTextField);
        
        JPanel companionEmailPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionEmailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionEmailPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(companionEmailPanel);
        JLabel companionEmailLabel = new JLabel("Exercise/Activity:");
        companionEmailLabel.setPreferredSize(new Dimension(230, 40));
        companionEmailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionEmailPanel.add(companionEmailLabel);
        JTextField companionEmailTextField = new JTextField("");
        companionEmailTextField.setColumns(20);
        companionEmailTextField.setPreferredSize(new Dimension(40, 40));
        companionEmailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionEmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionEmailPanel.add(companionEmailTextField);
        
        JPanel companionAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionAddressPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(companionAddressPanel);
        JLabel companionAddressLabel = new JLabel("Medicine:");
        companionAddressLabel.setPreferredSize(new Dimension(160, 40));
        companionAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionAddressPanel.add(companionAddressLabel);
        JTextField companionAddressTextField = new JTextField("");
        companionAddressTextField.setColumns(20);
        companionAddressTextField.setPreferredSize(new Dimension(40, 40));
        companionAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionAddressPanel.add(companionAddressTextField);
        
        JPanel companionPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionPasswordPanel.setBackground(Color.WHITE);
        centerCenterPanel.add(companionPasswordPanel);
        JLabel companionPasswordLabel = new JLabel("Note:");
        companionPasswordLabel.setPreferredSize(new Dimension(80, 40));
        companionPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionPasswordPanel.add(companionPasswordLabel);
        JTextArea medicalRecordTextArea = new JTextArea(6, 40);
        medicalRecordTextArea.setText("");
        medicalRecordTextArea.setPreferredSize(new Dimension(70, 160));
        medicalRecordTextArea.setFont(new Font("Arial", Font.PLAIN, 20));
        medicalRecordTextArea.setBorder(new LineBorder(Color.BLACK, 5));
        companionPasswordPanel.add(medicalRecordTextArea);
        
        JButton saveUpdateDailyReport = new JButton("Save");
        saveUpdateDailyReport.setMaximumSize(new Dimension(150, 110));
        saveUpdateDailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        saveUpdateDailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        saveUpdateDailyReport.setBackground(Color.WHITE);
        saveUpdateDailyReport.setForeground(Color.BLACK);
        saveUpdateDailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        saveUpdateDailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                for(User userAcc : MainLogic.userAccount)
                {
                    if((userAcc.getUserInfo().get(0)).equals(userID))
                    {
                        CompanionUser companion = (CompanionUser) userAcc;
                        ArrayList<Object> appointment = null;
                        for(ArrayList appointments : companion.getAppointmentList())
                        {
                            if(appointments.get(6).equals((String)companion.getUserInfo().get(0)))
                            {
                                appointment = appointments;
                            }
                        }
                        String elderID = (String)appointment.get(0);
                        elderID = elderID.replace('a', 'e');
                        companion.saveDailyReportDatabase(dateTextField.getText(), companionUsernameTextField.getText(), companionPhoneNumberTextField.getText(), companionEmailTextField.getText(), companionAddressTextField.getText(), medicalRecordTextArea.getText(), (String)userAcc.getUserInfo().get(0), elderID);
                        JOptionPane.showMessageDialog(null, "Saved");
                        break;
                    }
                }
            }
        });
        centerRightPanel.add(saveUpdateDailyReport, BorderLayout.NORTH);
        
        JButton backUpdateDailyReport = new JButton("Back");
        backUpdateDailyReport.setMaximumSize(new Dimension(150, 110));
        backUpdateDailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        backUpdateDailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        backUpdateDailyReport.setBackground(Color.WHITE);
        backUpdateDailyReport.setForeground(Color.BLACK);
        backUpdateDailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        backUpdateDailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                CompanionDailyReportGU companionDailyReportGUI = new CompanionDailyReportGU(dashboard, userID);
                dashboard.remove(CompanionUpdateDailyReportGU.this);
                dashboard.add(companionDailyReportGUI.getPanel(), BorderLayout.CENTER);
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        centerRightPanel.add(backUpdateDailyReport, BorderLayout.SOUTH);
        
        
        

        
        
        JButton dailyReport = new JButton("<html>Daily<br>Report</html>");
        dailyReport.setMaximumSize(new Dimension(150, 110));
        dailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        dailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        dailyReport.setBackground(Color.WHITE);
        dailyReport.setForeground(Color.BLACK);
        dailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        dailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                
            }
        });
        leftPanel.add(dailyReport);
        
        
        JPanel medicalReportButtonPanel = new JPanel();
        medicalReportButtonPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        medicalReportButtonPanel.setBackground(new Color(238,238,238,255));
        leftPanel.add(medicalReportButtonPanel);
        JButton medicalReport = new JButton("<html>Medical<br>Report</html>");
        medicalReport.setMaximumSize(new Dimension(150, 110));
        medicalReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        medicalReport.setFont(new Font("Arial", Font.BOLD, 40));
        medicalReport.setBackground(Color.WHITE);
        medicalReport.setForeground(Color.BLACK);
        medicalReport.setBorder(new LineBorder(Color.BLACK, 7));
        medicalReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                CompanionMedicalReportGUI companionMedicalReportGUI = new CompanionMedicalReportGUI(dashboard, userID);
                dashboard.remove(CompanionUpdateDailyReportGU.this);
                dashboard.add(companionMedicalReportGUI.getPanel(), BorderLayout.CENTER);
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        medicalReportButtonPanel.add(medicalReport);
        
    }
    public JPanel getPanel() {return CompanionUpdateDailyReportGU.this;}
}