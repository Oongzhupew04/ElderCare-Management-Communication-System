import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;

public class GuardianTherapistInformationGUI extends JPanel implements DashboardContentParentGUI
{
    public GuardianTherapistInformationGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        
        ArrayList<JPanel> infosArrayList = new ArrayList<>();
        
        JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        centerPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(new EmptyBorder(20, 20, 0, 20));
        add(leftPanel, BorderLayout.WEST);
        
        
        
        ArrayList<Object> therapistInformation = null;
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                GuardianUser guardian = (GuardianUser) userAcc;
                therapistInformation = guardian.getTherapistInformationList();
                if(therapistInformation.isEmpty())
                {
                    //JOptionPane.showMessageDialog(null, "No appointed therapist found.");
                }
                else
                {
                    JPanel info0 = new JPanel();
                    info0.setPreferredSize(new Dimension(360, 340));
                    info0.setLayout(new BoxLayout(info0, BoxLayout.Y_AXIS));
                    info0.setBorder(new LineBorder(Color.BLACK, 7));
                    info0.setBackground(new Color(68,147,186,255));
        
                    JPanel info0Panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                    info0Panel.setBorder(new EmptyBorder(5, 0, 0, 0));
                    info0Panel.setBackground(new Color(68,147,186,255));
                    info0.add(info0Panel);
                    JLabel service0Label = new JLabel("Name:");
                    service0Label.setPreferredSize(new Dimension(80, 40));
                    service0Label.setFont(new Font("Arial", Font.BOLD, 26));
                    info0Panel.add(service0Label);
                    JTextField service0TextField = new JTextField((String)therapistInformation.get(1));
                    service0TextField.setColumns(9);
                    service0TextField.setPreferredSize(new Dimension(40, 40));
                    service0TextField.setFont(new Font("Arial", Font.PLAIN, 20));
                    service0TextField.setBorder(new LineBorder(Color.BLACK, 5));
                    service0TextField.setEditable(false);
                    info0Panel.add(service0TextField);
                    JLabel date0Label = new JLabel("Email:");
                    date0Label.setPreferredSize(new Dimension(80, 40));
                    date0Label.setFont(new Font("Arial", Font.BOLD, 26));
                    info0Panel.add(date0Label);
                    JTextField date0TextField = new JTextField((String)therapistInformation.get(5));
                    date0TextField.setColumns(13);
                    date0TextField.setPreferredSize(new Dimension(40, 40));
                    date0TextField.setFont(new Font("Arial", Font.PLAIN, 20));
                    date0TextField.setBorder(new LineBorder(Color.BLACK, 5));
                    date0TextField.setEditable(false);
                    info0Panel.add(date0TextField);
                    JLabel time0Label = new JLabel("Phone:");
                    time0Label.setPreferredSize(new Dimension(90, 40));
                    time0Label.setFont(new Font("Arial", Font.BOLD, 26));
                    info0Panel.add(time0Label);
                    JTextField time0TextField = new JTextField(Integer.toString((Integer)therapistInformation.get(6)));
                    time0TextField.setColumns(8);
                    time0TextField.setPreferredSize(new Dimension(40, 40));
                    time0TextField.setFont(new Font("Arial", Font.PLAIN, 20));
                    time0TextField.setBorder(new LineBorder(Color.BLACK, 5));
                    time0TextField.setEditable(false);
                    info0Panel.add(time0TextField);
                    JLabel licenseNumber0Label = new JLabel("<html>License<br>Number:</html>");
                    licenseNumber0Label.setPreferredSize(new Dimension(110, 80));
                    licenseNumber0Label.setFont(new Font("Arial", Font.BOLD, 26));
                    info0Panel.add(licenseNumber0Label);
                    JTextField licenseNumber0TextField = new JTextField((String)therapistInformation.get(7));
                    licenseNumber0TextField.setColumns(10);
                    licenseNumber0TextField.setPreferredSize(new Dimension(40, 40));
                    licenseNumber0TextField.setFont(new Font("Arial", Font.PLAIN, 20));
                    licenseNumber0TextField.setBorder(new LineBorder(Color.BLACK, 5));
                    licenseNumber0TextField.setEditable(false);
                    info0Panel.add(licenseNumber0TextField);
                    JLabel therapyService0Label = new JLabel("<html>Therapy<br>Service:</html>");
                    therapyService0Label.setPreferredSize(new Dimension(110, 80));
                    therapyService0Label.setFont(new Font("Arial", Font.BOLD, 26));
                    info0Panel.add(therapyService0Label);
                    JTextField therapyService0TextField = new JTextField((String)therapistInformation.get(8));
                    therapyService0TextField.setColumns(10);
                    therapyService0TextField.setPreferredSize(new Dimension(40, 40));
                    therapyService0TextField.setFont(new Font("Arial", Font.PLAIN, 20));
                    therapyService0TextField.setBorder(new LineBorder(Color.BLACK, 5));
                    therapyService0TextField.setEditable(false);
                    info0Panel.add(therapyService0TextField);
        
                    infosArrayList.add(info0);
        
        
        
        
        
                    centerPanel.add(infosArrayList.get(0));
                }
                break;
            }
        }

        
        
        
        
        
        JButton dailyReport = new JButton("Companion");
        dailyReport.setMaximumSize(new Dimension(250, 110));
        dailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        dailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        dailyReport.setBackground(Color.WHITE);
        dailyReport.setForeground(Color.BLACK);
        dailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        dailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                GuardianCompanionInformationGUI guardianCompanionInformationGUI = new GuardianCompanionInformationGUI(dashboard, userID);
                dashboard.remove(GuardianTherapistInformationGUI.this);
                dashboard.add(guardianCompanionInformationGUI.getPanel(), BorderLayout.CENTER);
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        leftPanel.add(dailyReport);
        
        
        JPanel medicalReportButtonPanel = new JPanel();
        medicalReportButtonPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        medicalReportButtonPanel.setBackground(new Color(238,238,238,255));
        leftPanel.add(medicalReportButtonPanel);
        JButton medicalReport = new JButton("Therapist");
        medicalReport.setMaximumSize(new Dimension(150, 110));
        medicalReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        medicalReport.setFont(new Font("Arial", Font.BOLD, 40));
        medicalReport.setBackground(Color.WHITE);
        medicalReport.setForeground(Color.BLACK);
        medicalReport.setBorder(new LineBorder(Color.BLACK, 7));
        medicalReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                
            }
        });
        medicalReportButtonPanel.add(medicalReport);
        
    }
    public JPanel getPanel() {return GuardianTherapistInformationGUI.this;}
}