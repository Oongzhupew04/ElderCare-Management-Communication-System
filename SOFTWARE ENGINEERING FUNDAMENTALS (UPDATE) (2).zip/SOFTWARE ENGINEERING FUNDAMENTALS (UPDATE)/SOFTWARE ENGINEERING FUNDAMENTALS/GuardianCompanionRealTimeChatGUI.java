import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;
import java.sql.*;
import java.util.Timer;
import java.util.TimerTask;

public class GuardianCompanionRealTimeChatGUI extends JPanel implements DashboardContentParentGUI
{
    //ArrayList<String> userArrayList = new ArrayList<>();
    //ArrayList<String> messageHistoryArrayList = new ArrayList<>();
    public GuardianCompanionRealTimeChatGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        
        
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(new EmptyBorder(20, 20, 0, 20));
        add(leftPanel, BorderLayout.WEST);
        
        JPanel centerTopPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        centerTopPanel.setBackground(Color.WHITE);
        Border centerTopPanelBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        centerTopPanel.setBorder(centerTopPanelBorder);
        centerPanel.add(centerTopPanel, BorderLayout.NORTH);
        JPanel centerCenterPanel = new JPanel();
        centerCenterPanel.setLayout(new BoxLayout(centerCenterPanel, BoxLayout.Y_AXIS));
        centerCenterPanel.setBackground(Color.WHITE);
        centerPanel.add(centerCenterPanel);
        JPanel centerBottomPanel = new JPanel(new BorderLayout());
        centerBottomPanel.setBackground(Color.WHITE);
        Border centerBottomPanelBorder = BorderFactory.createMatteBorder(4, 0, 0, 0, Color.BLACK);
        centerBottomPanel.setBorder(centerBottomPanelBorder);
        centerPanel.add(centerBottomPanel, BorderLayout.SOUTH);
        
        
        JLabel companion = new JLabel("Companion");
        companion.setFont(new Font("Arial", Font.BOLD, 40));
        companion.setBorder(new EmptyBorder(0, 60, 30, 0));
        ImageIcon icon = new ImageIcon("user.png");
        companion.setIcon(icon);
        centerTopPanel.add(companion);
        
        
        
        JScrollPane scrollPane = new JScrollPane(centerCenterPanel);
        centerPanel.add(scrollPane);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        SwingUtilities.invokeLater(() -> {
            JScrollBar verticalScrollBar = scrollPane.getVerticalScrollBar();
            verticalScrollBar.setValue(verticalScrollBar.getMaximum());
        });
        
        
        JPanel messagePanel = new JPanel();
        messagePanel.setBorder(new EmptyBorder(10, 0, 0, 0));
        messagePanel.setBackground(Color.WHITE);
        centerBottomPanel.add(messagePanel);
        JTextField messageTextField = new JTextField();
        messageTextField.setColumns(30);
        String hint = "Message....";
        messageTextField.setText(hint);
        messageTextField.setForeground(Color.GRAY);
        messageTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        messageTextField.setBorder(new LineBorder(Color.BLACK, 5));
        messagePanel.add(messageTextField);
        messageTextField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (messageTextField.getText().equals(hint)) {
                    messageTextField.setText("");  // Clear the hint when focus is gained
                    messageTextField.setForeground(Color.BLACK);  // Change text color to black
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (messageTextField.getText().isEmpty()) {
                    messageTextField.setText(hint);  // Restore the hint when focus is lost
                    messageTextField.setForeground(Color.GRAY);  // Set the hint color back to gray
                }
            }
        });
        
        
        JPanel sentButtonPanel = new JPanel();
        sentButtonPanel.setBorder(new EmptyBorder(10, 0, 0, 20));
        sentButtonPanel.setBackground(Color.WHITE);
        centerBottomPanel.add(sentButtonPanel, BorderLayout.EAST);
        ImageIcon sentIcon = new ImageIcon("send.png");
        JButton sent = new JButton(sentIcon);
        sent.setMaximumSize(new Dimension(100, 200));
        sent.setBackground(Color.WHITE);
        sent.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                String modifiedString = messageTextField.getText();
                if (messageTextField.getText().length() > 59) 
                {
                    // Split the string after 10 characters and insert a newline
                    modifiedString = "<html>" + messageTextField.getText().substring(0, 59) + "<br>" + messageTextField.getText().substring(59) + "</html>";
                }
                JPanel panel = new JPanel(new BorderLayout());
                panel.setBorder(new EmptyBorder(0, 0, 20, 0));
                panel.setBackground(Color.WHITE);
                centerCenterPanel.add(panel);
                JLabel userChat = new JLabel(modifiedString);
                userChat.setFont(new Font("Arial", Font.PLAIN, 38));
                
                
                //userChat.setHorizontalAlignment(SwingConstants.RIGHT);
                //JLabel iconLabel = new JLabel(new ImageIcon("user(1).png"));
                //panel.add(userChat);
                //panel.add(iconLabel, BorderLayout.EAST);
                ArrayList<ArrayList> UserAppointmentList = null;
                for(User userAcc : MainLogic.userAccount)
                {
                    if((userAcc.getUserInfo().get(0)).equals(userID))
                    {
                        UserAppointmentList = userAcc.getAppointmentList();
                    }
                }
                if(UserAppointmentList.get(0) == null || UserAppointmentList.get(0).isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "No companion assigned.");
                }
                else
                {
                    String chatID = userID.replaceAll("g0", "gc");
                    saveChat(chatID, "guardian", messageTextField.getText(), userID);                    
                }
                
                
                //refreshChat(userID, centerCenterPanel);
                
                centerCenterPanel.revalidate();
                centerCenterPanel.repaint();
            }
        });
        sentButtonPanel.add(sent);
        
        
        
        
        refreshChat(userID, dashboard, centerCenterPanel);
        
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                refreshChat(userID, dashboard, centerCenterPanel);
            }
        };
        timer.scheduleAtFixedRate(task, 0, 500);

        //userArrayList.add("companion");
        //messageHistoryArrayList.add("Hi, I am Avery. I just arrived and helped Mr. Harris with his morning routine. He’s doing fine so far.");
        //userArrayList.add("user");
        //messageHistoryArrayList.add("Thanks, Avery! Make sure he takes his medication and has breakfast. He sometimes forgets.");
        //userArrayList.add("companion");
        //messageHistoryArrayList.add("He took his meds and had toast with scrambled eggs. He seemed to enjoy it.");
        //userArrayList.add("user");
        //messageHistoryArrayList.add("Great! How’s his mood?");
        //userArrayList.add("companion");
        //messageHistoryArrayList.add("He’s in good spirits. We talked about his garden, and he’s excited to get outside later. I’ll keep an eye on him.");
        //userArrayList.add("user");
        //messageHistoryArrayList.add("Perfect. Thanks, Avery. Call me if you need anything.");
        //userArrayList.add("companion");
        //messageHistoryArrayList.add("Will do! Thanks.");
        
        
        
        
        
        
        JButton dailyReport = new JButton("Companion");
        dailyReport.setMaximumSize(new Dimension(250, 110));
        dailyReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        dailyReport.setFont(new Font("Arial", Font.BOLD, 40));
        dailyReport.setBackground(Color.WHITE);
        dailyReport.setForeground(Color.BLACK);
        dailyReport.setBorder(new LineBorder(Color.BLACK, 7));
        dailyReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                
            }
        });
        leftPanel.add(dailyReport);
        
        
        JPanel medicalReportButtonPanel = new JPanel();
        medicalReportButtonPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        medicalReportButtonPanel.setBackground(new Color(238,238,238,255));
        leftPanel.add(medicalReportButtonPanel);
        JButton medicalReport = new JButton("Therapist");
        medicalReport.setMaximumSize(new Dimension(150, 110));
        medicalReport.setAlignmentX(Component.CENTER_ALIGNMENT);
        medicalReport.setFont(new Font("Arial", Font.BOLD, 40));
        medicalReport.setBackground(Color.WHITE);
        medicalReport.setForeground(Color.BLACK);
        medicalReport.setBorder(new LineBorder(Color.BLACK, 7));
        medicalReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                GuardianTherapistRealTimeChatGUI guardianTherapistRealTimeChatGUI = new GuardianTherapistRealTimeChatGUI(dashboard, userID);
                dashboard.remove(GuardianCompanionRealTimeChatGUI.this);
                dashboard.add(guardianTherapistRealTimeChatGUI.getPanel(), BorderLayout.CENTER);
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        medicalReportButtonPanel.add(medicalReport);
        
    }
    public JPanel getPanel() {return GuardianCompanionRealTimeChatGUI.this;}
    public ArrayList getChat(String userid)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        ArrayList<ArrayList> chat = new ArrayList<ArrayList>();

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.chat"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String chatID = userid.replaceAll("g0", "gc");
                if(resultSet.getString(1).equals(chatID) && (resultSet.getString(2).equals("companion") || resultSet.getString(2).equals("guardian")))
                {
                    String converId = resultSet.getString(1);
                    String role = resultSet.getString(2);
                    String message = resultSet.getString(3);
                    String userID = resultSet.getString(4);
                    
                    
                    
                    ArrayList<Object> chatline = new ArrayList<Object>();
                    chatline.add(converId);
                    chatline.add(role);
                    chatline.add(message);
                    chatline.add(userID);
                    chat.add(chatline);
                }
            }
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return chat;
    }
    public void saveChat(String converid, String username, String message, String userid)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "INSERT INTO chat VALUES(?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            
            
            statement.setString(1, converid);
            statement.setString(2, username);
            statement.setString(3, message);
            statement.setString(4, userid);
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    void refreshChat(String userID, JFrame dashboard, JPanel centerCenterPanel)
    {
        ArrayList<ArrayList> chat = getChat(userID);
        ArrayList<String> userArrayList = new ArrayList<>();
        ArrayList<String> messageHistoryArrayList = new ArrayList<>();
        for(ArrayList chatline : chat)
        {
            userArrayList.add((String)chatline.get(1));
            messageHistoryArrayList.add((String)chatline.get(2));
        }
        
        centerCenterPanel.removeAll();
        
        for (int i = 0; i < userArrayList.size(); i++) 
        {
            String modifiedString = messageHistoryArrayList.get(i);
            if (messageHistoryArrayList.get(i).length() > 59) 
            {
                // Split the string after 10 characters and insert a newline
                modifiedString = "<html>" + messageHistoryArrayList.get(i).substring(0, 59) + "<br>" + messageHistoryArrayList.get(i).substring(59) + "</html>";
            }
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(new EmptyBorder(0, 0, 20, 0));
            panel.setBackground(Color.WHITE);
            centerCenterPanel.add(panel);
            JLabel userChat = new JLabel(modifiedString);
            userChat.setFont(new Font("Arial", Font.PLAIN, 38));
            if(userArrayList.get(i).equals("companion"))
            {
                userChat.setIcon(new ImageIcon("user.png"));
                panel.add(userChat);
            }
            else
            {
                userChat.setHorizontalAlignment(SwingConstants.RIGHT);
                JLabel iconLabel = new JLabel(new ImageIcon("user(1).png"));
                panel.add(userChat);
                panel.add(iconLabel, BorderLayout.EAST);
            }
        }
        dashboard.revalidate();
        dashboard.repaint();
    }
}