import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class CompanionEditProfileGUI extends JPanel implements DashboardContentParentGUI
{
    public CompanionEditProfileGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        JPanel companionInfoPanel = new JPanel();
        companionInfoPanel.setBackground(Color.WHITE);
        companionInfoPanel.setLayout(new BoxLayout(companionInfoPanel, BoxLayout.Y_AXIS));
        companionInfoPanel.setBorder(new EmptyBorder(50, 100, 0, 0));
        add(companionInfoPanel, BorderLayout.WEST);
        
        JPanel companionRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionRolePanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionRolePanel);
        JLabel companionRole = new JLabel("Companion");
        companionRole.setPreferredSize(new Dimension(270, 40));
        companionRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        companionRole.setForeground(Color.BLACK);
        Border groleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        companionRole.setBorder(groleBottomBorder);
        companionRolePanel.add(companionRole);
        
        JPanel companionUsernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionUsernamePanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionUsernamePanel);
        JLabel companionUsernameLabel = new JLabel("Username:");
        companionUsernameLabel.setPreferredSize(new Dimension(140, 40));
        companionUsernameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionUsernamePanel.add(companionUsernameLabel);
        JTextField companionUsernameTextField = new JTextField();
        companionUsernameTextField.setColumns(20);
        companionUsernameTextField.setPreferredSize(new Dimension(40, 40));
        companionUsernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionUsernameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionUsernamePanel.add(companionUsernameTextField);
        
        JPanel companionPhoneNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionPhoneNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionPhoneNumberPanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionPhoneNumberPanel);
        JLabel companionPhoneNumberLabel = new JLabel("Phone Number:");
        companionPhoneNumberLabel.setPreferredSize(new Dimension(200, 40));
        companionPhoneNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionPhoneNumberPanel.add(companionPhoneNumberLabel);
        JTextField companionPhoneNumberTextField = new JTextField();
        companionPhoneNumberTextField.setColumns(20);
        companionPhoneNumberTextField.setPreferredSize(new Dimension(40, 40));
        companionPhoneNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionPhoneNumberTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionPhoneNumberPanel.add(companionPhoneNumberTextField);
        
        JPanel companionEmailPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionEmailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionEmailPanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionEmailPanel);
        JLabel companionEmailLabel = new JLabel("Email:");
        companionEmailLabel.setPreferredSize(new Dimension(90, 40));
        companionEmailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionEmailPanel.add(companionEmailLabel);
        JTextField companionEmailTextField = new JTextField();
        companionEmailTextField.setColumns(20);
        companionEmailTextField.setPreferredSize(new Dimension(40, 40));
        companionEmailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionEmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionEmailPanel.add(companionEmailTextField);
        
        JPanel companionAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionAddressPanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionAddressPanel);
        JLabel companionAddressLabel = new JLabel("Address:");
        companionAddressLabel.setPreferredSize(new Dimension(120, 40));
        companionAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionAddressPanel.add(companionAddressLabel);
        JTextField companionAddressTextField = new JTextField();
        companionAddressTextField.setColumns(20);
        companionAddressTextField.setPreferredSize(new Dimension(40, 40));
        companionAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionAddressPanel.add(companionAddressTextField);
        
        JPanel companionPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionPasswordPanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionPasswordPanel);
        JLabel companionPasswordLabel = new JLabel("New Password:");
        companionPasswordLabel.setPreferredSize(new Dimension(200, 40));
        companionPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionPasswordPanel.add(companionPasswordLabel);
        JTextField companionPasswordTextField = new JTextField();
        companionPasswordTextField.setColumns(20);
        companionPasswordTextField.setPreferredSize(new Dimension(40, 40));
        companionPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionPasswordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionPasswordPanel.add(companionPasswordTextField);
        
        JPanel companionConfirmPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionConfirmPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionConfirmPasswordPanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionConfirmPasswordPanel);
        JLabel companionConfirmPasswordLabel = new JLabel("Confirm Password:");
        companionConfirmPasswordLabel.setPreferredSize(new Dimension(245, 40));
        companionConfirmPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionConfirmPasswordPanel.add(companionConfirmPasswordLabel);
        JTextField companionConfirmPasswordTextField = new JTextField();
        companionConfirmPasswordTextField.setColumns(20);
        companionConfirmPasswordTextField.setPreferredSize(new Dimension(40, 40));
        companionConfirmPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionConfirmPasswordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionConfirmPasswordPanel.add(companionConfirmPasswordTextField);
        
        JPanel button1Panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        button1Panel.setBorder(new EmptyBorder(50, 0, 0, 0));
        button1Panel.setBackground(Color.WHITE);
        companionInfoPanel.add(button1Panel);
        JButton back = new JButton("Back");
        back.setPreferredSize(new Dimension(230, 70));
        back.setFont(new Font("Serif", Font.BOLD, 30));
        back.setBackground(new Color(68,147,186,255));
        back.setForeground(Color.BLACK);
        back.setBorder(new LineBorder(Color.BLACK, 7));
        back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                CompanionProfileGUI companionProfileGUI = new CompanionProfileGUI(dashboard, userID);
                dashboard.remove(CompanionEditProfileGUI.this);
                dashboard.add(companionProfileGUI.getPanel(), BorderLayout.CENTER);

                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        button1Panel.add(back);
        
        
        
        
        
        JPanel bigButtonPanel = new JPanel(new BorderLayout());
        bigButtonPanel.setBackground(Color.WHITE);
        bigButtonPanel.setBorder(new EmptyBorder(0, 0, 15, 50));
        add(bigButtonPanel, BorderLayout.EAST);
        JPanel button2Panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        button2Panel.setBackground(Color.WHITE);
        bigButtonPanel.add(button2Panel, BorderLayout.SOUTH);
        JButton save = new JButton("Save");
        save.setPreferredSize(new Dimension(230, 70));
        save.setFont(new Font("Serif", Font.BOLD, 30));
        save.setBackground(new Color(68,147,186,255));
        save.setForeground(Color.BLACK);
        save.setBorder(new LineBorder(Color.BLACK, 7));
        save.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(companionConfirmPasswordTextField.getText().equals(companionPasswordTextField.getText()))
                {
                    for(User userAcc : MainLogic.userAccount)
                    {
                        if((userAcc.getUserInfo().get(0)).equals(userID))
                        {
                            CompanionUser companion = (CompanionUser) userAcc;      //Cast to CompanionUser
                            companion.setUserInfo(companionUsernameTextField.getText(), companionConfirmPasswordTextField.getText(), companionEmailTextField.getText(), Integer.parseInt(companionPhoneNumberTextField.getText()), companionAddressTextField.getText());
                            companion.editDatabaseInfo(userID, (String)userAcc.getUserInfo().get(1), companionUsernameTextField.getText(), companionConfirmPasswordTextField.getText(), (String)userAcc.getUserInfo().get(4), companionEmailTextField.getText(), Integer.parseInt(companionPhoneNumberTextField.getText()), null, null, companionAddressTextField.getText());
                            JOptionPane.showMessageDialog(null, "Saved!");
                            break;
                        }
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "New password doesn't match confirm password.");
                }
            }
        });
        button2Panel.add(save);
    }
    public JPanel getPanel() {return CompanionEditProfileGUI.this;}
}