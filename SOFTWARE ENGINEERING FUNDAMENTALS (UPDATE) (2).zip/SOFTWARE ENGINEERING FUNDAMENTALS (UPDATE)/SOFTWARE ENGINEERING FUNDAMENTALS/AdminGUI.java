import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class AdminGUI extends JFrame {
    private String displayingPanel;
    public AdminGUI() {
        super("ADMIN");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());

        JPanel navigationBarPanel = new JPanel();
        navigationBarPanel.setPreferredSize(new Dimension(Integer.MAX_VALUE, 100));
        navigationBarPanel.setLayout(new GridLayout(1, 2));
        add(navigationBarPanel, BorderLayout.NORTH);

        JPanel dashboardPanel = new JPanel(new BorderLayout());
        dashboardPanel.setBackground(Color.WHITE);
        displayingPanel = "dashboard";
        add(dashboardPanel, BorderLayout.CENTER);

        JPanel leftNavigationBarPanel = new JPanel();
        leftNavigationBarPanel.setPreferredSize(new Dimension(800, 100));
        leftNavigationBarPanel.setBorder(new EmptyBorder(13, 30, 0, 0));
        leftNavigationBarPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        leftNavigationBarPanel.setBackground(new Color(68, 147, 186, 255));
        navigationBarPanel.add(leftNavigationBarPanel);

        JButton home = new JButton("Home");
        home.setPreferredSize(new Dimension(110, 60));
        home.setFont(new Font("Arial", Font.BOLD, 24));
        home.setBackground(Color.WHITE);
        home.setForeground(new Color(68, 147, 186, 255));
        Border homeBottomBorder = BorderFactory.createMatteBorder(0, 10, 0, 0, new Color(68, 147, 186, 255));
        home.setBorder(homeBottomBorder);
        home.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("dashboard"))
                {
                    AdminGUI.this.getContentPane().removeAll();
                    AdminGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    AdminGUI.this.add(dashboardPanel, BorderLayout.CENTER);
                    displayingPanel = "dashboard";
                    
                    AdminGUI.this.revalidate();
                    AdminGUI.this.repaint();
                }
            }
        });
        leftNavigationBarPanel.add(home);


        JButton aboutUs = new JButton("About Us");
        aboutUs.setPreferredSize(new Dimension(200, 60));
        aboutUs.setFont(new Font("Arial", Font.BOLD, 24));
        aboutUs.setBackground(Color.WHITE);
        aboutUs.setForeground(new Color(68, 147, 186, 255));
        Border aboutUsBottomBorder = BorderFactory.createMatteBorder(0, 40, 0, 0, new Color(68, 147, 186, 255));
        aboutUs.setBorder(aboutUsBottomBorder);
        aboutUs.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("aboutus"))
                {
                    AboutUsGUI aboutUsGUI = new AboutUsGUI();
                    AdminGUI.this.getContentPane().removeAll();
                    AdminGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    AdminGUI.this.add(aboutUsGUI.getAboutUsPanel(), BorderLayout.CENTER);
                    displayingPanel = "aboutus";
                    
                    
                    AdminGUI.this.revalidate();
                    AdminGUI.this.repaint();
                }
            }
        });
        leftNavigationBarPanel.add(aboutUs);

        JPanel rightNavigationBarPanel = new JPanel();
        rightNavigationBarPanel.setPreferredSize(new Dimension(800, 100));
        rightNavigationBarPanel.setBorder(new EmptyBorder(13, 0, 0, 30));
        rightNavigationBarPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        rightNavigationBarPanel.setBackground(new Color(68, 147, 186, 255));
        navigationBarPanel.add(rightNavigationBarPanel);

        JButton logout = new JButton("Logout");
        logout.setPreferredSize(new Dimension(130, 60));
        logout.setFont(new Font("Arial", Font.BOLD, 24));
        logout.setBackground(Color.WHITE);
        logout.setForeground(new Color(68, 147, 186, 255));
        logout.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                int response = JOptionPane.showConfirmDialog(
                null,
                "Do you want to logout?",
                "Confirmation",
                JOptionPane.YES_NO_CANCEL_OPTION
                );
                if (response == JOptionPane.YES_OPTION)
                {
                    new MainGUI();
                    dispose();
                }
            }
        });
        rightNavigationBarPanel.add(logout);

        JPanel iconPanel = new JPanel();
        iconPanel.setBackground(Color.WHITE);
        dashboardPanel.add(iconPanel, BorderLayout.EAST);

        ImageIcon icon = new ImageIcon("LOGO.jpg"); 
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setBorder(new EmptyBorder(100, 0, 0, 0));
        iconPanel.add(iconLabel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS)); 
        buttonPanel.setBorder(new EmptyBorder(180, 0, 0, 0)); 
        dashboardPanel.add(buttonPanel, BorderLayout.CENTER);
        
        
        JButton userManagement = createButton("User Management");
        userManagement.setFont(new Font("Arial", Font.BOLD, 36));
        userManagement.setMaximumSize(new Dimension(350, 100));
        userManagement.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                UserManagementGUI userManagement = new UserManagementGUI();
                AdminGUI.this.getContentPane().removeAll();
                AdminGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                AdminGUI.this.add(userManagement.getUserManagementPanel(), BorderLayout.CENTER);
                displayingPanel = "usermanagement";    
                    
                AdminGUI.this.revalidate();
                AdminGUI.this.repaint();
            }
        });
        buttonPanel.add(userManagement);

        
        JButton approveApplication = createButton("Application Approval");
        Border userNameBottomBorder = BorderFactory.createMatteBorder(100, 0, 0, 0, Color.WHITE);
        approveApplication.setBorder(userNameBottomBorder);
        approveApplication.setFont(new Font("Arial", Font.BOLD, 36));
        approveApplication.setMaximumSize(new Dimension(400, 200));
        approveApplication.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                ApproveApplicationGUI approveApplication = new ApproveApplicationGUI();
                AdminGUI.this.getContentPane().removeAll();
                AdminGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                AdminGUI.this.add(approveApplication.getApproveApplicationPanel(), BorderLayout.CENTER);
                displayingPanel = "applicationapproval";    
                    
                AdminGUI.this.revalidate();
                AdminGUI.this.repaint();
            }
        });
        buttonPanel.add(approveApplication);

        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setBackground(new Color(68, 147, 186, 255));
        button.setForeground(Color.WHITE);
        return button;
    }
}