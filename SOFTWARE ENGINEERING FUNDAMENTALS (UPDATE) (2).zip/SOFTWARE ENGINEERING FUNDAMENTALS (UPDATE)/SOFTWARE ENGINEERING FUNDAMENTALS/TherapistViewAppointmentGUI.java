import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;

public class TherapistViewAppointmentGUI extends JPanel implements DashboardContentParentGUI
{
    public TherapistViewAppointmentGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        
        JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        centerPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        add(bottomPanel, BorderLayout.SOUTH);
        
        ArrayList<JPanel> appointmentsArrayList = new ArrayList<>();
        
        
        
        
        ArrayList<ArrayList> UserAppointmentList = null;
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                MedicalTherapistUser medicalTherapist = (MedicalTherapistUser) userAcc;
                UserAppointmentList = medicalTherapist.getAppointmentList();
            }
        }
        
        
        
        for(ArrayList appointments : UserAppointmentList)
        {
            JPanel appointment0 = new JPanel();
            appointment0.setPreferredSize(new Dimension(380, 230));
            appointment0.setLayout(new BoxLayout(appointment0, BoxLayout.Y_AXIS));
            appointment0.setBorder(new LineBorder(Color.BLACK, 7));
            appointment0.setBackground(new Color(68,147,186,255));
        
            JPanel appointment0Panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            appointment0Panel.setBorder(new EmptyBorder(5, 0, 0, 0));
            appointment0Panel.setBackground(new Color(68,147,186,255));
            appointment0.add(appointment0Panel);
            JLabel service0Label = new JLabel("Name:");
            service0Label.setPreferredSize(new Dimension(90, 40));
            service0Label.setFont(new Font("Arial", Font.BOLD, 24));
            appointment0Panel.add(service0Label);
            JTextField service0TextField = new JTextField((String)appointments.get(1));
            service0TextField.setColumns(10);
            service0TextField.setPreferredSize(new Dimension(40, 40));
            service0TextField.setFont(new Font("Arial", Font.PLAIN, 20));
            service0TextField.setBorder(new LineBorder(Color.BLACK, 5));
            service0TextField.setEditable(false);
            appointment0Panel.add(service0TextField);
            JLabel date0Label = new JLabel("Date:");
            date0Label.setPreferredSize(new Dimension(80, 40));
            date0Label.setFont(new Font("Arial", Font.BOLD, 24));
            appointment0Panel.add(date0Label);
            JTextField date0TextField = new JTextField((String)appointments.get(2));
            date0TextField.setColumns(11);
            date0TextField.setPreferredSize(new Dimension(40, 40));
            date0TextField.setFont(new Font("Arial", Font.PLAIN, 20));
            date0TextField.setBorder(new LineBorder(Color.BLACK, 5));
            date0TextField.setEditable(false);
            appointment0Panel.add(date0TextField);
            JLabel time0Label = new JLabel("Time:");
            time0Label.setPreferredSize(new Dimension(80, 40));
            time0Label.setFont(new Font("Arial", Font.BOLD, 24));
            appointment0Panel.add(time0Label);
            JTextField time0TextField = new JTextField((String)appointments.get(3));
            time0TextField.setColumns(10);
            time0TextField.setPreferredSize(new Dimension(40, 40));
            time0TextField.setFont(new Font("Arial", Font.PLAIN, 20));
            time0TextField.setBorder(new LineBorder(Color.BLACK, 5));
            time0TextField.setEditable(false);
            appointment0Panel.add(time0TextField);
            JLabel therapyService0Label = new JLabel("Address: ");
            therapyService0Label.setPreferredSize(new Dimension(110, 80));
            therapyService0Label.setFont(new Font("Arial", Font.BOLD, 24));
            appointment0Panel.add(therapyService0Label);
            JTextField therapyService0TextField = new JTextField((String)appointments.get(4));
            therapyService0TextField.setColumns(12);
            therapyService0TextField.setPreferredSize(new Dimension(40, 40));
            therapyService0TextField.setFont(new Font("Arial", Font.PLAIN, 20));
            therapyService0TextField.setBorder(new LineBorder(Color.BLACK, 5));
            therapyService0TextField.setEditable(false);
            appointment0Panel.add(therapyService0TextField);
        
            appointmentsArrayList.add(appointment0);
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        for(JPanel appointmentPanel : appointmentsArrayList)
        {
            centerPanel.add(appointmentPanel);
        }
        
        
    }
    public JPanel getPanel() {return TherapistViewAppointmentGUI.this;}
}