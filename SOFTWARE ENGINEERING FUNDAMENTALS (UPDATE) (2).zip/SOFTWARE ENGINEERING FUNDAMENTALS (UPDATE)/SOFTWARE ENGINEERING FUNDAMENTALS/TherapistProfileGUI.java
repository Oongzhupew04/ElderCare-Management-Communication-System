import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class TherapistProfileGUI extends JPanel implements DashboardContentParentGUI
{
    public TherapistProfileGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        JPanel therapistInfoPanel = new JPanel();
        therapistInfoPanel.setBackground(Color.WHITE);
        therapistInfoPanel.setLayout(new BoxLayout(therapistInfoPanel, BoxLayout.Y_AXIS));
        therapistInfoPanel.setBorder(new EmptyBorder(50, 100, 0, 0));
        add(therapistInfoPanel, BorderLayout.WEST);
        
        JPanel therapistRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistRolePanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistRolePanel);
        JLabel therapistRole = new JLabel("Therapist");
        therapistRole.setPreferredSize(new Dimension(230, 40));
        therapistRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        therapistRole.setForeground(Color.BLACK);
        Border groleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        therapistRole.setBorder(groleBottomBorder);
        therapistRolePanel.add(therapistRole);
        
        JPanel therapistUsernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistUsernamePanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistUsernamePanel);
        JLabel therapistUsernameLabel = new JLabel("Username:");
        therapistUsernameLabel.setPreferredSize(new Dimension(140, 40));
        therapistUsernameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistUsernamePanel.add(therapistUsernameLabel);
        JTextField therapistUsernameTextField = new JTextField(getUserData(userID, 2));
        therapistUsernameTextField.setColumns(20);
        therapistUsernameTextField.setPreferredSize(new Dimension(40, 40));
        therapistUsernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistUsernameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistUsernameTextField.setEditable(false);
        therapistUsernamePanel.add(therapistUsernameTextField);
        
        JPanel therapistPhoneNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistPhoneNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistPhoneNumberPanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistPhoneNumberPanel);
        JLabel therapistPhoneNumberLabel = new JLabel("Phone Number:");
        therapistPhoneNumberLabel.setPreferredSize(new Dimension(200, 40));
        therapistPhoneNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistPhoneNumberPanel.add(therapistPhoneNumberLabel);
        JTextField therapistPhoneNumberTextField = new JTextField(getUserData(userID, 6));
        therapistPhoneNumberTextField.setColumns(20);
        therapistPhoneNumberTextField.setPreferredSize(new Dimension(40, 40));
        therapistPhoneNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistPhoneNumberTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistPhoneNumberTextField.setEditable(false);
        therapistPhoneNumberPanel.add(therapistPhoneNumberTextField);
        
        JPanel therapistEmailPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistEmailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistEmailPanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistEmailPanel);
        JLabel therapistEmailLabel = new JLabel("Email:");
        therapistEmailLabel.setPreferredSize(new Dimension(90, 40));
        therapistEmailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistEmailPanel.add(therapistEmailLabel);
        JTextField therapistEmailTextField = new JTextField(getUserData(userID, 5));
        therapistEmailTextField.setColumns(20);
        therapistEmailTextField.setPreferredSize(new Dimension(40, 40));
        therapistEmailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistEmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistEmailTextField.setEditable(false);
        therapistEmailPanel.add(therapistEmailTextField);
        
        JPanel therapistAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistAddressPanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistAddressPanel);
        JLabel therapistAddressLabel = new JLabel("Address:");
        therapistAddressLabel.setPreferredSize(new Dimension(120, 40));
        therapistAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistAddressPanel.add(therapistAddressLabel);
        JTextField therapistAddressTextField = new JTextField(getUserData(userID, 7));
        therapistAddressTextField.setColumns(20);
        therapistAddressTextField.setPreferredSize(new Dimension(40, 40));
        therapistAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistAddressTextField.setEditable(false);
        therapistAddressPanel.add(therapistAddressTextField);
        
        JPanel therapistPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistPasswordPanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistPasswordPanel);
        JLabel therapistPasswordLabel = new JLabel("Password:");
        therapistPasswordLabel.setPreferredSize(new Dimension(140, 40));
        therapistPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistPasswordPanel.add(therapistPasswordLabel);
        JTextField therapistPasswordTextField = new JTextField(getUserData(userID, 3));
        therapistPasswordTextField.setColumns(20);
        therapistPasswordTextField.setPreferredSize(new Dimension(40, 40));
        therapistPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistPasswordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistPasswordTextField.setEditable(false);
        therapistPasswordPanel.add(therapistPasswordTextField);
        
        
        
        
        JPanel bigButtonPanel = new JPanel(new BorderLayout());
        bigButtonPanel.setBackground(Color.WHITE);
        bigButtonPanel.setBorder(new EmptyBorder(0, 0, 50, 50));
        add(bigButtonPanel, BorderLayout.EAST);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);
        bigButtonPanel.add(buttonPanel, BorderLayout.SOUTH);
        JButton update = new JButton("Update Profile");
        update.setPreferredSize(new Dimension(230, 70));
        update.setFont(new Font("Serif", Font.BOLD, 30));
        update.setBackground(new Color(68,147,186,255));
        update.setForeground(Color.BLACK);
        update.setBorder(new LineBorder(Color.BLACK, 7));
        update.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                TherapistEditProfileGUI therapistEditProfileGUI = new TherapistEditProfileGUI(dashboard, userID);
                dashboard.remove(TherapistProfileGUI.this);
                dashboard.add(therapistEditProfileGUI.getPanel(), BorderLayout.CENTER);
                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        buttonPanel.add(update);
    }
    public JPanel getPanel() {return TherapistProfileGUI.this;}
    public String getUserData(String userID, int index)
    {
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                String data = String.valueOf(userAcc.getUserInfo().get(index));
                return data;
            }
        }
        return null;
    }
}