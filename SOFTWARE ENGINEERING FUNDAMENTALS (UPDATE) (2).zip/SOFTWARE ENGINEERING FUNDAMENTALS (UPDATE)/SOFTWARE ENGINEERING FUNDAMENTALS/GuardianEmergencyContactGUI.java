import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;
import java.util.*;

public class GuardianEmergencyContactGUI extends JPanel implements DashboardContentParentGUI
{
    public GuardianEmergencyContactGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        
        JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        centerPanel.setBorder(new EmptyBorder(30, 30, 30, 30));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        add(bottomPanel, BorderLayout.SOUTH);
        
        ArrayList<JPanel> appointmentsArrayList = new ArrayList<>();
        
        
        
        
        ArrayList<ArrayList> emergencyContactList = null;
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                GuardianUser guardian = (GuardianUser) userAcc;
                emergencyContactList = guardian.getEmergencyContactList();
                break;
            }
        }
        
        for(ArrayList emergencyContact : emergencyContactList)
        {
            JPanel appointment = new JPanel();
            appointment.setPreferredSize(new Dimension(800, 270));
            appointment.setLayout(new BoxLayout(appointment, BoxLayout.Y_AXIS));
            appointment.setBorder(new LineBorder(Color.BLACK, 7));
            appointment.setBackground(new Color(68,147,186,255));
        
            JPanel appointmentPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            appointmentPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
            appointmentPanel.setBackground(new Color(68,147,186,255));
            appointment.add(appointmentPanel);
            JLabel serviceLabel = new JLabel("Name:");
            serviceLabel.setPreferredSize(new Dimension(80, 40));
            serviceLabel.setFont(new Font("Arial", Font.BOLD, 24));
            appointmentPanel.add(serviceLabel);
            JTextField serviceTextField = new JTextField((String)emergencyContact.get(0));
            serviceTextField.setColumns(32);
            serviceTextField.setPreferredSize(new Dimension(40, 40));
            serviceTextField.setFont(new Font("Arial", Font.PLAIN, 20));
            serviceTextField.setBorder(new LineBorder(Color.BLACK, 5));
            serviceTextField.setEditable(false);
            appointmentPanel.add(serviceTextField);
            JLabel dateLabel = new JLabel("Contact:");
            dateLabel.setPreferredSize(new Dimension(110, 40));
            dateLabel.setFont(new Font("Arial", Font.BOLD, 24));
            appointmentPanel.add(dateLabel);
            JTextField dateTextField = new JTextField(String.valueOf(emergencyContact.get(1)));
            dateTextField.setColumns(35);
            dateTextField.setPreferredSize(new Dimension(40, 40));
            dateTextField.setFont(new Font("Arial", Font.PLAIN, 20));
            dateTextField.setBorder(new LineBorder(Color.BLACK, 5));
            dateTextField.setEditable(false);
            appointmentPanel.add(dateTextField);
            JLabel timeLabel = new JLabel("Relationship:");
            timeLabel.setPreferredSize(new Dimension(160, 40));
            timeLabel.setFont(new Font("Arial", Font.BOLD, 24));
            appointmentPanel.add(timeLabel);
            JTextField timeTextField = new JTextField((String)emergencyContact.get(2));
            timeTextField.setColumns(30);
            timeTextField.setPreferredSize(new Dimension(40, 40));
            timeTextField.setFont(new Font("Arial", Font.PLAIN, 20));
            timeTextField.setBorder(new LineBorder(Color.BLACK, 5));
            timeTextField.setEditable(false);
            appointmentPanel.add(timeTextField);
            JLabel therapyServiceLabel = new JLabel("Email:");
            therapyServiceLabel.setPreferredSize(new Dimension(80, 40));
            therapyServiceLabel.setFont(new Font("Arial", Font.BOLD, 24));
            appointmentPanel.add(therapyServiceLabel);
            JTextField therapyServiceTextField = new JTextField((String)emergencyContact.get(3));
            therapyServiceTextField.setColumns(35);
            therapyServiceTextField.setPreferredSize(new Dimension(40, 40));
            therapyServiceTextField.setFont(new Font("Arial", Font.PLAIN, 20));
            therapyServiceTextField.setBorder(new LineBorder(Color.BLACK, 5));
            therapyServiceTextField.setEditable(false);
            appointmentPanel.add(therapyServiceTextField);
            JLabel addressLabel = new JLabel("Address:");
            addressLabel.setPreferredSize(new Dimension(120, 40));
            addressLabel.setFont(new Font("Arial", Font.BOLD, 24));
            appointmentPanel.add(addressLabel);
            JTextField addressTextField = new JTextField((String)emergencyContact.get(4));
            addressTextField.setColumns(35);
            addressTextField.setPreferredSize(new Dimension(40, 40));
            addressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
            addressTextField.setBorder(new LineBorder(Color.BLACK, 5));
            addressTextField.setEditable(false);
            appointmentPanel.add(addressTextField);
        
            appointmentsArrayList.add(appointment);
        }
        
        
        
        
        
        
        JPanel addEmergencyContactButtonPanel = new JPanel();
        addEmergencyContactButtonPanel.setBorder(new EmptyBorder(0, 0, 30, 0));
        addEmergencyContactButtonPanel.setBackground(Color.WHITE);
        bottomPanel.add(addEmergencyContactButtonPanel);
        JButton addEmergencyContact = new JButton("Add Emergency Contact");
        addEmergencyContact.setMaximumSize(new Dimension(170, 55));
        addEmergencyContact.setAlignmentX(Component.CENTER_ALIGNMENT);
        addEmergencyContact.setFont(new Font("Arial", Font.BOLD, 40));
        addEmergencyContact.setBackground(Color.WHITE);
        addEmergencyContact.setForeground(Color.BLACK);
        addEmergencyContact.setBorder(new LineBorder(Color.BLACK, 7));
        addEmergencyContact.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                GuardianAddEmergencyContactGUI guardianAddEmergencyContactGUI = new GuardianAddEmergencyContactGUI(dashboard, userID);
                dashboard.remove(GuardianEmergencyContactGUI.this);
                dashboard.add(guardianAddEmergencyContactGUI.getPanel(), BorderLayout.CENTER);
                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        addEmergencyContactButtonPanel.add(addEmergencyContact);
        
        
        
        
        
        
        
        
        for(JPanel appointmentPanel : appointmentsArrayList)
        {
            centerPanel.add(appointmentPanel);
        }
        
        
    }
    public JPanel getPanel() {return GuardianEmergencyContactGUI.this;}
}