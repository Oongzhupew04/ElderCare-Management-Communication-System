import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class MainGUI extends JFrame
{
    public MainGUI()
    {
          super("ELDERCARE");
          setExtendedState(JFrame.MAXIMIZED_BOTH);
          
          JPanel mainPanel = new JPanel();
          mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
          mainPanel.setBackground(Color.WHITE);
          add(mainPanel);
          ImageIcon icon = new ImageIcon("LOGO.jpg");
          JLabel iconLabel = new JLabel(icon);
          iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
          mainPanel.add(iconLabel);
          
           
          JPanel buttonPanel = new JPanel();
          buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 70, 0));
          buttonPanel.setBackground(Color.WHITE);
          mainPanel.add(buttonPanel);
          
          
          JButton register = new JButton("Register");
          register.setPreferredSize(new Dimension(300, 70));
          register.setFont(new Font("Arial", Font.BOLD, 36));
          register.setBackground(new Color(68,147,186,255));
          register.setForeground(Color.WHITE);
          register.addActionListener(new ActionListener(){
              @Override
              public void actionPerformed(ActionEvent evt)
              {
                  new RegisterGUI();
                  dispose();
              }
          });
          buttonPanel.add(register);
          
          
          JButton login = new JButton("Login");
          login.setPreferredSize(new Dimension(300, 70));
          login.setFont(new Font("Arial", Font.BOLD, 36));
          login.setBackground(Color.WHITE);
          login.setForeground(new Color(68,147,186,255));
          login.setBorder(new LineBorder(new Color(68,147,186,255), 3));
          login.addActionListener(new ActionListener(){
             @Override
             public void actionPerformed(ActionEvent evt)
             {
                new LoginGUI();
                dispose();
             }
          });
          buttonPanel.add(login);
          
          
          
          
          setVisible(true);
          setResizable(false);
          setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}