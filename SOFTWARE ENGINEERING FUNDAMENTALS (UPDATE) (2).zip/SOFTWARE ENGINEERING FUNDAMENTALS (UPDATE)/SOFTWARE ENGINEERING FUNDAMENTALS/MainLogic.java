import java.sql.*;
import java.util.*;

public class MainLogic  
{
    public static int userAccCount = 0;
    public static ArrayList<User> userAccount = new ArrayList<User>();
    public MainLogic()
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.userinfo"; // Replace with your table name
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(5).equals("guardian"))
                {
                    String guardianId = resultSet.getString(1);
                    String guardianName = resultSet.getString(2);
                    String guardianUsername = resultSet.getString(3);
                    String guardianPassword = resultSet.getString(4);
                    String guardianRole = resultSet.getString(5);
                    String guardianEmail = resultSet.getString(6);
                    int guardianPhoneNumber = resultSet.getInt(7);
                    String guardianAddress = resultSet.getString(10);
                    
                    String guardianQuery = "SELECT * FROM ElderCare_stiffmebee.elderinfo WHERE guardianid = ?";
                    PreparedStatement guardianStatement = connection.prepareStatement(guardianQuery);
                    guardianStatement.setString(1, guardianId);
                    ResultSet guardianResultSet = guardianStatement.executeQuery();
                    if(guardianResultSet.next())
                    {
                        User guardianUser = new GuardianUser(guardianId, guardianName, guardianUsername, guardianPassword, guardianRole, guardianEmail, guardianPhoneNumber, guardianAddress, guardianResultSet.getString(1), guardianResultSet.getString(2), Integer.parseInt(guardianResultSet.getString(3)), guardianResultSet.getString(4), guardianResultSet.getString(5), guardianResultSet.getString(6));
                        userAccount.add(guardianUser);
                    }
                }
                else if(resultSet.getString(5).equals("companion"))
                {
                    User companionUser = new CompanionUser(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6), resultSet.getInt(7), resultSet.getInt(8), resultSet.getString(10));
                    userAccount.add(companionUser);
                }
                else if(resultSet.getString(5).equals("therapist"))
                {
                    User medicalTherapistUser = new MedicalTherapistUser(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6), resultSet.getInt(7), resultSet.getInt(8), resultSet.getString(9), resultSet.getString(10));
                    userAccount.add(medicalTherapistUser);
                }
                userAccCount++;
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}