import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;
import java.sql.*;

public class GuardianGUI extends JFrame
{
    public GuardianGUI()
    {
        super("GUARDIAN");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        JPanel guardianPanel = new JPanel();
        guardianPanel.setLayout(new BoxLayout(guardianPanel, BoxLayout.Y_AXIS));
        guardianPanel.setBackground(Color.WHITE);
        add(guardianPanel);
        
        
        JPanel logoPanel = new JPanel();
        //logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
        logoPanel.setPreferredSize(new Dimension(Integer.MAX_VALUE, 20));
        logoPanel.setBackground(Color.WHITE);
        guardianPanel.add(logoPanel);
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(321, 242, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoPanel.add(iconLabel);
        
        JPanel contentPanel = new JPanel();
        //contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(new EmptyBorder(30, 0, 0, 0));
        contentPanel.setPreferredSize(new Dimension(Integer.MAX_VALUE, 410));
        contentPanel.setBackground(new Color(68,147,186,255));
        guardianPanel.add(contentPanel);
        
        JPanel bigPanel = new JPanel();
        bigPanel.setBorder(new EmptyBorder(20, 0, 0, 0));
        bigPanel.setPreferredSize(new Dimension(700, 500));
        bigPanel.setLayout(new BoxLayout(bigPanel, BoxLayout.Y_AXIS));
        bigPanel.setBackground(Color.WHITE);
        contentPanel.add(bigPanel);
        
        JLabel role = new JLabel("Guardian");
        role.setPreferredSize(new Dimension(100, 40));
        role.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 34));
        role.setForeground(Color.BLACK);
        role.setAlignmentX(Component.CENTER_ALIGNMENT);
        bigPanel.add(role);
        
        JPanel namePanel = new JPanel();
        namePanel.setBackground(Color.WHITE);
        bigPanel.add(namePanel);
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setPreferredSize(new Dimension(100, 40));
        nameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        namePanel.add(nameLabel);
        JTextField nameTextField = new JTextField();
        nameTextField.setColumns(20);
        nameTextField.setPreferredSize(new Dimension(40, 40));
        nameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border nameBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        nameTextField.setBorder(nameBottomBorder);
        namePanel.add(nameTextField);
        
        JPanel userNamePanel = new JPanel();
        userNamePanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        userNamePanel.setBackground(Color.WHITE);
        bigPanel.add(userNamePanel);
        JLabel userNameLabel = new JLabel("Username:");
        userNameLabel.setPreferredSize(new Dimension(160, 40));
        userNameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        userNamePanel.add(userNameLabel);
        JTextField userNameTextField = new JTextField();
        userNameTextField.setColumns(20);
        userNameTextField.setPreferredSize(new Dimension(40, 40));
        userNameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border userNameBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        userNameTextField.setBorder(userNameBottomBorder);
        userNamePanel.add(userNameTextField);
        
        JPanel passwordPanel = new JPanel();
        passwordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        passwordPanel.setBackground(Color.WHITE);
        bigPanel.add(passwordPanel);
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setPreferredSize(new Dimension(150, 40));
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        passwordPanel.add(passwordLabel);
        JTextField passwordTextField = new JTextField();
        passwordTextField.setColumns(20);
        passwordTextField.setPreferredSize(new Dimension(40, 40));
        passwordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border passwordBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        passwordTextField.setBorder(passwordBottomBorder);
        passwordPanel.add(passwordTextField);
        
        JPanel emailPanel = new JPanel();
        emailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        emailPanel.setBackground(Color.WHITE);
        bigPanel.add(emailPanel);
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setPreferredSize(new Dimension(100, 40));
        emailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        emailPanel.add(emailLabel);
        JTextField emailTextField = new JTextField();
        emailTextField.setColumns(20);
        emailTextField.setPreferredSize(new Dimension(40, 40));
        emailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border emailBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        emailTextField.setBorder(emailBottomBorder);
        emailPanel.add(emailTextField);
        
        JPanel phonePanel = new JPanel();
        phonePanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        phonePanel.setBackground(Color.WHITE);
        bigPanel.add(phonePanel);
        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setPreferredSize(new Dimension(110, 40));
        phoneLabel.setFont(new Font("Arial", Font.BOLD, 26));
        phonePanel.add(phoneLabel);
        JTextField phoneTextField = new JTextField();
        phoneTextField.setColumns(20);
        phoneTextField.setPreferredSize(new Dimension(40, 40));
        phoneTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border phoneBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        phoneTextField.setBorder(phoneBottomBorder);
        phonePanel.add(phoneTextField);
        
        JPanel addressPanel = new JPanel();
        addressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        addressPanel.setBackground(Color.WHITE);
        bigPanel.add(addressPanel);
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setPreferredSize(new Dimension(130, 40));
        addressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        addressPanel.add(addressLabel);
        JTextField addressTextField = new JTextField();
        addressTextField.setColumns(20);
        addressTextField.setPreferredSize(new Dimension(40, 40));
        addressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border addressBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, new Color(68,147,186,255));
        addressTextField.setBorder(addressBottomBorder);
        addressPanel.add(addressTextField);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        buttonPanel.setBackground(Color.WHITE);
        bigPanel.add(buttonPanel);
        JButton next = new JButton("Next");
        next.setPreferredSize(new Dimension(100, 40));
        next.setFont(new Font("Arial", Font.BOLD, 30));
        next.setBackground(Color.WHITE);
        next.setForeground(new Color(68,147,186,255));
        next.setBorder(new LineBorder(new Color(68,147,186,255), 5));
        next.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new GuardianNextGUI(nameTextField.getText(),userNameTextField.getText(), passwordTextField.getText(), emailTextField.getText(), Integer.parseInt(phoneTextField.getText()), addressTextField.getText());
                dispose();
            }
        });
        buttonPanel.add(next);
        
        
        
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}