import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class CompanionProfileGUI extends JPanel implements DashboardContentParentGUI
{
    public CompanionProfileGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        JPanel companionInfoPanel = new JPanel();
        companionInfoPanel.setBackground(Color.WHITE);
        companionInfoPanel.setLayout(new BoxLayout(companionInfoPanel, BoxLayout.Y_AXIS));
        companionInfoPanel.setBorder(new EmptyBorder(50, 100, 0, 0));
        add(companionInfoPanel, BorderLayout.WEST);
        
        JPanel companionRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionRolePanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionRolePanel);
        JLabel companionRole = new JLabel("Companion");
        companionRole.setPreferredSize(new Dimension(270, 40));
        companionRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        companionRole.setForeground(Color.BLACK);
        Border groleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        companionRole.setBorder(groleBottomBorder);
        companionRolePanel.add(companionRole);
        
        JPanel companionUsernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionUsernamePanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionUsernamePanel);
        JLabel companionUsernameLabel = new JLabel("Username:");
        companionUsernameLabel.setPreferredSize(new Dimension(140, 40));
        companionUsernameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionUsernamePanel.add(companionUsernameLabel);
        JTextField companionUsernameTextField = new JTextField(getUserData(userID, 2));
        companionUsernameTextField.setColumns(20);
        companionUsernameTextField.setPreferredSize(new Dimension(40, 40));
        companionUsernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionUsernameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionUsernameTextField.setEditable(false);
        companionUsernamePanel.add(companionUsernameTextField);
        
        JPanel companionPhoneNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionPhoneNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionPhoneNumberPanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionPhoneNumberPanel);
        JLabel companionPhoneNumberLabel = new JLabel("Phone Number:");
        companionPhoneNumberLabel.setPreferredSize(new Dimension(200, 40));
        companionPhoneNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionPhoneNumberPanel.add(companionPhoneNumberLabel);
        JTextField companionPhoneNumberTextField = new JTextField(getUserData(userID, 6));
        companionPhoneNumberTextField.setColumns(20);
        companionPhoneNumberTextField.setPreferredSize(new Dimension(40, 40));
        companionPhoneNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionPhoneNumberTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionPhoneNumberTextField.setEditable(false);
        companionPhoneNumberPanel.add(companionPhoneNumberTextField);
        
        JPanel companionEmailPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionEmailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionEmailPanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionEmailPanel);
        JLabel companionEmailLabel = new JLabel("Email:");
        companionEmailLabel.setPreferredSize(new Dimension(90, 40));
        companionEmailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionEmailPanel.add(companionEmailLabel);
        JTextField companionEmailTextField = new JTextField(getUserData(userID, 5));
        companionEmailTextField.setColumns(20);
        companionEmailTextField.setPreferredSize(new Dimension(40, 40));
        companionEmailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionEmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionEmailTextField.setEditable(false);
        companionEmailPanel.add(companionEmailTextField);
        
        JPanel companionAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionAddressPanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionAddressPanel);
        JLabel companionAddressLabel = new JLabel("Address:");
        companionAddressLabel.setPreferredSize(new Dimension(120, 40));
        companionAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionAddressPanel.add(companionAddressLabel);
        JTextField companionAddressTextField = new JTextField(getUserData(userID, 7));
        companionAddressTextField.setColumns(20);
        companionAddressTextField.setPreferredSize(new Dimension(40, 40));
        companionAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionAddressTextField.setEditable(false);
        companionAddressPanel.add(companionAddressTextField);
        
        JPanel companionPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        companionPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        companionPasswordPanel.setBackground(Color.WHITE);
        companionInfoPanel.add(companionPasswordPanel);
        JLabel companionPasswordLabel = new JLabel("Password:");
        companionPasswordLabel.setPreferredSize(new Dimension(140, 40));
        companionPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        companionPasswordPanel.add(companionPasswordLabel);
        JTextField companionPasswordTextField = new JTextField(getUserData(userID, 3));
        companionPasswordTextField.setColumns(20);
        companionPasswordTextField.setPreferredSize(new Dimension(40, 40));
        companionPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        companionPasswordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        companionPasswordTextField.setEditable(false);
        companionPasswordPanel.add(companionPasswordTextField);
        
        
        
        
        JPanel bigButtonPanel = new JPanel(new BorderLayout());
        bigButtonPanel.setBackground(Color.WHITE);
        bigButtonPanel.setBorder(new EmptyBorder(0, 0, 50, 50));
        add(bigButtonPanel, BorderLayout.EAST);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);
        bigButtonPanel.add(buttonPanel, BorderLayout.SOUTH);
        JButton update = new JButton("Update Profile");
        update.setPreferredSize(new Dimension(230, 70));
        update.setFont(new Font("Serif", Font.BOLD, 30));
        update.setBackground(new Color(68,147,186,255));
        update.setForeground(Color.BLACK);
        update.setBorder(new LineBorder(Color.BLACK, 7));
        update.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                CompanionEditProfileGUI companionEditProfileGUI = new CompanionEditProfileGUI(dashboard, userID);
                dashboard.remove(CompanionProfileGUI.this);
                dashboard.add(companionEditProfileGUI.getPanel(), BorderLayout.CENTER);
                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        buttonPanel.add(update);
    }
    public JPanel getPanel() {return CompanionProfileGUI.this;}
    public String getUserData(String userID, int index)
    {
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                String data = String.valueOf(userAcc.getUserInfo().get(index));
                return data;
            }
        }
        return null;
    }
}