import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class TherapistEditProfileGUI extends JPanel implements DashboardContentParentGUI
{
    public TherapistEditProfileGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        JPanel therapistInfoPanel = new JPanel();
        therapistInfoPanel.setBackground(Color.WHITE);
        therapistInfoPanel.setLayout(new BoxLayout(therapistInfoPanel, BoxLayout.Y_AXIS));
        therapistInfoPanel.setBorder(new EmptyBorder(50, 100, 0, 0));
        add(therapistInfoPanel, BorderLayout.WEST);
        
        JPanel therapistRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistRolePanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistRolePanel);
        JLabel therapistRole = new JLabel("Therapist");
        therapistRole.setPreferredSize(new Dimension(230, 40));
        therapistRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        therapistRole.setForeground(Color.BLACK);
        Border groleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        therapistRole.setBorder(groleBottomBorder);
        therapistRolePanel.add(therapistRole);
        
        JPanel therapistUsernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistUsernamePanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistUsernamePanel);
        JLabel therapistUsernameLabel = new JLabel("Username:");
        therapistUsernameLabel.setPreferredSize(new Dimension(140, 40));
        therapistUsernameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistUsernamePanel.add(therapistUsernameLabel);
        JTextField therapistUsernameTextField = new JTextField();
        therapistUsernameTextField.setColumns(20);
        therapistUsernameTextField.setPreferredSize(new Dimension(40, 40));
        therapistUsernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistUsernameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistUsernamePanel.add(therapistUsernameTextField);
        
        JPanel therapistPhoneNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistPhoneNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistPhoneNumberPanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistPhoneNumberPanel);
        JLabel therapistPhoneNumberLabel = new JLabel("Phone Number:");
        therapistPhoneNumberLabel.setPreferredSize(new Dimension(200, 40));
        therapistPhoneNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistPhoneNumberPanel.add(therapistPhoneNumberLabel);
        JTextField therapistPhoneNumberTextField = new JTextField();
        therapistPhoneNumberTextField.setColumns(20);
        therapistPhoneNumberTextField.setPreferredSize(new Dimension(40, 40));
        therapistPhoneNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistPhoneNumberTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistPhoneNumberPanel.add(therapistPhoneNumberTextField);
        
        JPanel therapistEmailPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistEmailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistEmailPanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistEmailPanel);
        JLabel therapistEmailLabel = new JLabel("Email:");
        therapistEmailLabel.setPreferredSize(new Dimension(90, 40));
        therapistEmailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistEmailPanel.add(therapistEmailLabel);
        JTextField therapistEmailTextField = new JTextField();
        therapistEmailTextField.setColumns(20);
        therapistEmailTextField.setPreferredSize(new Dimension(40, 40));
        therapistEmailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistEmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistEmailPanel.add(therapistEmailTextField);
        
        JPanel therapistAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistAddressPanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistAddressPanel);
        JLabel therapistAddressLabel = new JLabel("Address:");
        therapistAddressLabel.setPreferredSize(new Dimension(120, 40));
        therapistAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistAddressPanel.add(therapistAddressLabel);
        JTextField therapistAddressTextField = new JTextField();
        therapistAddressTextField.setColumns(20);
        therapistAddressTextField.setPreferredSize(new Dimension(40, 40));
        therapistAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistAddressPanel.add(therapistAddressTextField);
        
        JPanel therapistPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistPasswordPanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistPasswordPanel);
        JLabel therapistPasswordLabel = new JLabel("New Password:");
        therapistPasswordLabel.setPreferredSize(new Dimension(200, 40));
        therapistPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistPasswordPanel.add(therapistPasswordLabel);
        JTextField therapistPasswordTextField = new JTextField();
        therapistPasswordTextField.setColumns(20);
        therapistPasswordTextField.setPreferredSize(new Dimension(40, 40));
        therapistPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistPasswordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistPasswordPanel.add(therapistPasswordTextField);
        
        JPanel therapistConfirmPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        therapistConfirmPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        therapistConfirmPasswordPanel.setBackground(Color.WHITE);
        therapistInfoPanel.add(therapistConfirmPasswordPanel);
        JLabel therapistConfirmPasswordLabel = new JLabel("Confirm Password:");
        therapistConfirmPasswordLabel.setPreferredSize(new Dimension(245, 40));
        therapistConfirmPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        therapistConfirmPasswordPanel.add(therapistConfirmPasswordLabel);
        JTextField therapistConfirmPasswordTextField = new JTextField();
        therapistConfirmPasswordTextField.setColumns(20);
        therapistConfirmPasswordTextField.setPreferredSize(new Dimension(40, 40));
        therapistConfirmPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        therapistConfirmPasswordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        therapistConfirmPasswordPanel.add(therapistConfirmPasswordTextField);
        
        JPanel button1Panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        button1Panel.setBorder(new EmptyBorder(50, 0, 0, 0));
        button1Panel.setBackground(Color.WHITE);
        therapistInfoPanel.add(button1Panel);
        JButton back = new JButton("Back");
        back.setPreferredSize(new Dimension(230, 70));
        back.setFont(new Font("Serif", Font.BOLD, 30));
        back.setBackground(new Color(68,147,186,255));
        back.setForeground(Color.BLACK);
        back.setBorder(new LineBorder(Color.BLACK, 7));
        back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                TherapistProfileGUI therapistProfileGUI = new TherapistProfileGUI(dashboard, userID);
                dashboard.remove(TherapistEditProfileGUI.this);
                dashboard.add(therapistProfileGUI.getPanel(), BorderLayout.CENTER);

                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        button1Panel.add(back);
        
        
        
        
        
        JPanel bigButtonPanel = new JPanel(new BorderLayout());
        bigButtonPanel.setBackground(Color.WHITE);
        bigButtonPanel.setBorder(new EmptyBorder(0, 0, 15, 50));
        add(bigButtonPanel, BorderLayout.EAST);
        JPanel button2Panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        button2Panel.setBackground(Color.WHITE);
        bigButtonPanel.add(button2Panel, BorderLayout.SOUTH);
        JButton save = new JButton("Save");
        save.setPreferredSize(new Dimension(230, 70));
        save.setFont(new Font("Serif", Font.BOLD, 30));
        save.setBackground(new Color(68,147,186,255));
        save.setForeground(Color.BLACK);
        save.setBorder(new LineBorder(Color.BLACK, 7));
        save.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(therapistConfirmPasswordTextField.getText().equals(therapistPasswordTextField.getText()))
                {
                    for(User userAcc : MainLogic.userAccount)
                    {
                        if((userAcc.getUserInfo().get(0)).equals(userID))
                        {
                            MedicalTherapistUser therapist = (MedicalTherapistUser) userAcc;      //Cast to MedicalTherapistUser
                            therapist.setUserInfo(therapistUsernameTextField.getText(), therapistConfirmPasswordTextField.getText(), therapistEmailTextField.getText(), Integer.parseInt(therapistPhoneNumberTextField.getText()), therapistAddressTextField.getText());
                            therapist.editDatabaseInfo(userID, (String)userAcc.getUserInfo().get(1), therapistUsernameTextField.getText(), therapistConfirmPasswordTextField.getText(), (String)userAcc.getUserInfo().get(4), therapistEmailTextField.getText(), Integer.parseInt(therapistPhoneNumberTextField.getText()), null, null, therapistAddressTextField.getText());
                            JOptionPane.showMessageDialog(null, "Saved!");
                            break;
                        }
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "New password doesn't match confirm password.");
                }
            }
        });
        button2Panel.add(save);
    }
    public JPanel getPanel() {return TherapistEditProfileGUI.this;}
}