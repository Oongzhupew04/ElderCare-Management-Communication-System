import java.util.ArrayList;
import java.sql.*;

public class MedicalTherapistUser extends User
{
    static ArrayList<Object> ElderInfo = new ArrayList<Object>();
    static ArrayList<Object> MedicalTherapistUserInfo = new ArrayList<Object>();
    static ArrayList<ArrayList> AppointmentList = new ArrayList<ArrayList>();
    public MedicalTherapistUser(String ID, String name, String username, String password, String role, String email, int phoneNumber, int licenseNumber, String therapistService, String address)
    {
        MedicalTherapistUserInfo.add(ID);
        MedicalTherapistUserInfo.add(name);
        MedicalTherapistUserInfo.add(username);
        MedicalTherapistUserInfo.add(password);
        MedicalTherapistUserInfo.add(role);
        MedicalTherapistUserInfo.add(email);
        MedicalTherapistUserInfo.add(phoneNumber);
        MedicalTherapistUserInfo.add(licenseNumber);
        MedicalTherapistUserInfo.add(therapistService);
        MedicalTherapistUserInfo.add(address);
        
        updateAppointment();
    }
    ArrayList<Object> getUserInfo(){return MedicalTherapistUserInfo;}
    ArrayList<Object> getElderInfo(){return ElderInfo;}
    ArrayList<ArrayList> getAppointmentList(){return AppointmentList;}
    void setUserInfo(String username, String password, String email, int phoneNumber, String address)
    {
        String ID = (String)MedicalTherapistUserInfo.get(0);
        String name = (String)MedicalTherapistUserInfo.get(1);
        String role = (String)MedicalTherapistUserInfo.get(4);
        String licenseNumber = (String)MedicalTherapistUserInfo.get(7);
        MedicalTherapistUserInfo.clear();
        MedicalTherapistUserInfo.add(ID);
        MedicalTherapistUserInfo.add(name);
        MedicalTherapistUserInfo.add(username);
        MedicalTherapistUserInfo.add(password);
        MedicalTherapistUserInfo.add(role);
        MedicalTherapistUserInfo.add(email);
        MedicalTherapistUserInfo.add(phoneNumber);
        MedicalTherapistUserInfo.add(licenseNumber);
        MedicalTherapistUserInfo.add(address);
    }
    void setDatabaseInfo(String ID, String name, String username, String password, String role, String email, int phoneNumber, Integer licenseNumber, String therapistService, String address)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "INSERT INTO userinfo VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            statement.setString(1, ID);
            statement.setString(2, name);
            statement.setString(3, username);
            statement.setString(4, password);
            statement.setString(5, role);
            statement.setString(6, email);
            statement.setInt(7, phoneNumber);
            statement.setInt(8, licenseNumber);
            statement.setString(9, therapistService);
            statement.setString(10, address);
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    void editDatabaseInfo(String ID, String name, String username, String password, String role, String email, int phoneNumber, Integer licenseNumber, String therapistService, String address)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "UPDATE userinfo SET name = ?, username = ?, password = ?, role = ?, email = ?, phone = ?, licensenumber = ?, therapistservice = ?, address = ? WHERE userid = ?;";
            statement = connection.prepareStatement(query);
            
            
            statement.setString(1, name);
            statement.setString(2, username);
            statement.setString(3, password);
            statement.setString(4, role);
            statement.setString(5, email);
            statement.setInt(6, phoneNumber);
            statement.setNull(7, Types.INTEGER);
            statement.setNull(8, Types.VARCHAR);
            statement.setString(9, address);
            statement.setString(10, ID);
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public static void updateAppointment()
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.appointment"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(8) != null && resultSet.getString(8).equals(MedicalTherapistUserInfo.get(0)))
                {
                    String appointmentId = resultSet.getString(1);
                    String patientName = resultSet.getString(2);
                    String appointmentDate = resultSet.getDate(3).toString();
                    String appointmentTime = resultSet.getTime(4).toString();
                    String address = resultSet.getString(5);
                    String therapyService = resultSet.getString(6);
                    String companionID = resultSet.getString(7);
                    String therapistID = resultSet.getString(8);
                    
                    
                    //if(resultSet.next())
                    //{
                        ArrayList<Object> Appointment = new ArrayList<Object>();
                        Appointment.add(appointmentId);
                        Appointment.add(patientName);
                        Appointment.add(appointmentDate);
                        Appointment.add(appointmentTime);
                        Appointment.add(address);
                        Appointment.add(therapyService);
                        Appointment.add(companionID);
                        Appointment.add(therapistID);
                        AppointmentList.add(Appointment);
                    //}
                }
            }
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        setElderInfo();
    }
    ArrayList getEmergencyContactList()
    {
        ArrayList<ArrayList> emergencyContactList = new ArrayList<ArrayList>();
        
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.emergencycontact"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(6).equals(ElderInfo.get(6)))
                {
                    String name = resultSet.getString(1);
                    int phone = resultSet.getInt(2);
                    String relation = resultSet.getString(3);
                    String email = resultSet.getString(4);
                    String address = resultSet.getString(5);
                    String guardianID = resultSet.getString(6);
                    
                    
                    //if(resultSet.next())
                    //{
                        ArrayList<Object> emergencyContact = new ArrayList<Object>();
                        emergencyContact.add(name);
                        emergencyContact.add(phone);
                        emergencyContact.add(relation);
                        emergencyContact.add(email);
                        emergencyContact.add(address);
                        emergencyContact.add(guardianID);
                        emergencyContactList.add(emergencyContact);
                    //}
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return emergencyContactList;
    }
    public static void setElderInfo()
    {
        
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.elderinfo"; 
            resultSet = statement.executeQuery(query);

            if(AppointmentList.isEmpty())
            {
                return;
            }
            
            String elderid = (String)(AppointmentList.get(0).get(0));
            elderid = elderid.replace('a', 'e');
            while (resultSet.next()) {
                    if(resultSet.getString(1).equals(elderid))
                    {
                        String elderID = resultSet.getString(1);
                        String name = resultSet.getString(2);
                        int age = resultSet.getInt(3);
                        String gender = resultSet.getString(4);
                        String medicalRecord = resultSet.getString(5);
                        String address = resultSet.getString(6);
                        String guardianID = resultSet.getString(7);
                    
                    
                        
                        
                            ElderInfo.add(elderID);
                            ElderInfo.add(name);
                            ElderInfo.add(age);
                            ElderInfo.add(gender);
                            ElderInfo.add(medicalRecord);
                            ElderInfo.add(address);
                            ElderInfo.add(guardianID);
                        
                    }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        //System.out.println(AppointmentList.get(0));
        //System.out.println(ElderInfo);
    }
    ArrayList getDailyReportList()
    {
        ArrayList<ArrayList> dailyReportList = new ArrayList<ArrayList>();
        
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.dailyreport"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(8).equals((String)ElderInfo.get(0)))
                {
                    String date = resultSet.getDate(1).toString();
                    int amountofmeal = resultSet.getInt(2);
                    String bloodpressure = resultSet.getString(3);
                    String exercise = resultSet.getString(4);
                    String medicine = resultSet.getString(5);
                    String note = resultSet.getString(6);
                    String companionID = resultSet.getString(7);
                    String elderID = resultSet.getString(8);
                    
                    
                    //if(resultSet.next())
                    //{
                        ArrayList<Object> dailyReport = new ArrayList<Object>();
                        dailyReport.add(date);
                        dailyReport.add(amountofmeal);
                        dailyReport.add(bloodpressure);
                        dailyReport.add(exercise);
                        dailyReport.add(medicine);
                        dailyReport.add(note);
                        dailyReport.add(companionID);
                        dailyReport.add(elderID);
                        dailyReportList.add(dailyReport);
                    //}
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return dailyReportList;
    }
    ArrayList getMedicalReportList()
    {
        ArrayList<ArrayList> medicalReportList = new ArrayList<ArrayList>();
        
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.medicalreport"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(8) != null && resultSet.getString(8).equals(MedicalTherapistUserInfo.get(0)))
                {
                    String date = resultSet.getDate(1).toString();
                    String therapistService = resultSet.getString(2);
                    String medicalHistory = resultSet.getString(3);
                    String medication = resultSet.getString(4);
                    String dosage = resultSet.getString(5);
                    String note = resultSet.getString(6);
                    String elderID = resultSet.getString(7);
                    String therapistID = resultSet.getString(8);
                    
                    
                    //if(resultSet.next())
                    //{
                        ArrayList<Object> medicalReport = new ArrayList<Object>();
                        medicalReport.add(date);
                        medicalReport.add(therapistService);
                        medicalReport.add(medicalHistory);
                        medicalReport.add(medication);
                        medicalReport.add(dosage);
                        medicalReport.add(note);
                        medicalReport.add(elderID);
                        medicalReport.add(therapistID);
                        medicalReportList.add(medicalReport);
                    //}
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return medicalReportList;
    }
    void saveMedicalReportDatabase(String date, String therapistService, String medicalHistory, String medication, String dosage, String note, String elderID, String therapistID)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "INSERT INTO medicalreport VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            
            
            
            
            
            statement.setString(1, date);
            statement.setString(2, therapistService);
            statement.setString(3, medicalHistory);
            statement.setString(4, medication);
            statement.setString(5, dosage);
            statement.setString(6, note);
            statement.setString(7, elderID);
            statement.setString(8, therapistID);
            
            statement.executeUpdate();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}