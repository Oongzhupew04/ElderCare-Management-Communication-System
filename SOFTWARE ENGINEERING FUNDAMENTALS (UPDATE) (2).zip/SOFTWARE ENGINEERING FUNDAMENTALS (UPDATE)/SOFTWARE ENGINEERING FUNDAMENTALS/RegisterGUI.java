import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class RegisterGUI extends JFrame
{
    public RegisterGUI()
    {
        super("REGISTER");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        JPanel registerPanel = new JPanel();
        registerPanel.setLayout(new BoxLayout(registerPanel, BoxLayout.Y_AXIS));
        registerPanel.setBackground(Color.WHITE);
        add(registerPanel);
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(513, 387, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        registerPanel.add(iconLabel);
        
        
        JPanel rolePanel = new JPanel();
        rolePanel.setBackground(Color.WHITE);
        registerPanel.add(rolePanel);
        JLabel role = new JLabel("Register");
        role.setPreferredSize(new Dimension(180, 48));
        role.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 40));
        role.setBackground(Color.WHITE);
        role.setOpaque(true);
        role.setForeground(Color.BLACK);
        role.setAlignmentX(Component.CENTER_ALIGNMENT);
        rolePanel.add(role);
        ImageIcon regIcon = new ImageIcon("register3.png");
        JLabel regIconLabel = new JLabel(regIcon);
        regIconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        rolePanel.add(regIconLabel);
        
        JPanel buttonPanel1 = new JPanel();
        buttonPanel1.setBorder(new EmptyBorder(50, 0, 0, 0));
        buttonPanel1.setLayout(new FlowLayout(FlowLayout.CENTER, 200, 0));
        buttonPanel1.setBackground(new Color(68,147,186,255));
        registerPanel.add(buttonPanel1);
        
        
        JButton guardian = new JButton("Guardian  >");
        guardian.setPreferredSize(new Dimension(300, 85));
        guardian.setFont(new Font("Serif", Font.BOLD, 30));
        guardian.setBackground(Color.BLACK);
        guardian.setForeground(Color.WHITE);
        guardian.setBorder(new LineBorder(Color.WHITE, 5));
        guardian.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new GuardianGUI();
                dispose();
            }
        });
        buttonPanel1.add(guardian);
          
          
        JButton companion = new JButton("Companion  >");
        companion.setPreferredSize(new Dimension(300, 85));
        companion.setFont(new Font("Serif", Font.BOLD, 30));
        companion.setBackground(Color.BLACK);
        companion.setForeground(Color.WHITE);
        companion.setBorder(new LineBorder(Color.WHITE, 5));
        companion.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                 new CompanionGUI();
                 dispose();
            }
        });
        buttonPanel1.add(companion);
        
        
        JPanel buttonPanel2 = new JPanel();
        buttonPanel2.setLayout(new FlowLayout(FlowLayout.CENTER, 70, 0));
        buttonPanel2.setBackground(new Color(68,147,186,255));
        registerPanel.add(buttonPanel2);
        
        
        
        JButton medicalTherapist = new JButton("Medical Therapist  >");
        medicalTherapist.setPreferredSize(new Dimension(400, 85));
        medicalTherapist.setFont(new Font("Serif", Font.BOLD, 30));
        medicalTherapist.setBackground(Color.BLACK);
        medicalTherapist.setForeground(Color.WHITE);
        medicalTherapist.setBorder(new LineBorder(Color.WHITE, 5));
        medicalTherapist.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                 new MedicalTherapistGUI();
                 dispose();
            }
        });
        buttonPanel2.add(medicalTherapist);
        
        
        
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}