import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.sql.*;

public class UserManagementGUI extends JPanel {
    private JPanel itemListPanel;
    //private static final String[] roles = {"Guardian", "Companion", "Therapist"};

    public UserManagementGUI() {
        setLayout(new BorderLayout());

        // Main panel with white background and scroll pane
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20)); // Add padding around the main panel
        add(mainPanel);
        
        JPanel userManagementPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        userManagementPanel.setBorder(new EmptyBorder(10, 30, 0, 0)); 
        userManagementPanel.setBackground(Color.WHITE);
        add(userManagementPanel, BorderLayout.NORTH);
        JLabel userManagementLabel = new JLabel("User Management");
        userManagementLabel.setFont(new Font("Arial", Font.BOLD, 34));
        Border userManagementBottomBorder = BorderFactory.createMatteBorder(0, 0, 3, 0, Color.BLACK);
        userManagementLabel.setBorder(userManagementBottomBorder);
        userManagementPanel.add(userManagementLabel);
        
        // Labels above the list
        JPanel labelPanel = new JPanel(new GridLayout(1, 2));
        labelPanel.setBorder(new EmptyBorder(10, 10, 10, 0)); // Add padding below the labels
        JLabel userNameLabel = new JLabel("User Name");
        userNameLabel.setFont(new Font("Arial", Font.BOLD, 24));
        JLabel roleLabel = new JLabel("Role");
        roleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        labelPanel.add(userNameLabel);
        labelPanel.add(roleLabel);

        // Item list panel with scroll pane
        itemListPanel = new JPanel();
        itemListPanel.setLayout(new BoxLayout(itemListPanel, BoxLayout.Y_AXIS));
        itemListPanel.setBorder(new EmptyBorder(10, 10, 10, 10)); // Add padding around the item list panel
        JScrollPane scrollPane = new JScrollPane(itemListPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        ArrayList <String> userNames = getUsername();
        ArrayList <String> role = getRole();
        for (int i = 0; i < userNames.size(); i++) {
            addItem(userNames.get(i), role.get(i));
        }

        mainPanel.add(labelPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        add(mainPanel, BorderLayout.CENTER);

    }

    private void addItem(String userName, String role) {
        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        itemPanel.setBorder(new EmptyBorder(5, 5, 5, 5)); // Add padding around each item
        
        JPanel userDetailsPanel = new JPanel(new GridLayout(1, 2));
        userDetailsPanel.setBorder(new EmptyBorder(0, 0, 0, 100)); // Add more gap between names and roles
        JLabel userNameLabel = new JLabel(userName);
        userNameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        JLabel roleLabel = new JLabel(role);
        roleLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        roleLabel.setBorder(new EmptyBorder(0, 100, 0, 0)); // Add more padding to the left of the role
        userDetailsPanel.add(userNameLabel);
        userDetailsPanel.add(roleLabel);
        
        JButton deleteButton = new JButton("Delete");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.setBackground(Color.WHITE);
        deleteButton.setForeground(Color.BLACK);
        deleteButton.setBorder(new LineBorder(Color.BLACK, 7));
        deleteButton.setPreferredSize(new Dimension(100, 40));
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteAcc(userName);
                MainLogic.userAccCount--;
                JOptionPane.showMessageDialog(null, "User account deleted");
                itemListPanel.remove(itemPanel);
                itemListPanel.revalidate();
                itemListPanel.repaint();
            }
        });

        itemPanel.add(userDetailsPanel, BorderLayout.CENTER);
        itemPanel.add(deleteButton, BorderLayout.EAST);
        itemListPanel.add(itemPanel);
    }
    public JPanel getUserManagementPanel() {return UserManagementGUI.this;}
    public ArrayList getUsername()
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        ArrayList<String> userNames = new ArrayList<String>();

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.userinfo"; // Replace with your table name
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                    String accUsername = resultSet.getString(3);
                    userNames.add(accUsername);
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return userNames;
    }
    public ArrayList getRole()
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        ArrayList<String> roles = new ArrayList<String>();

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.userinfo"; // Replace with your table name
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                    String accRole = resultSet.getString(5);
                    roles.add(accRole);
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return roles;
    }
    public void deleteAcc(String userName)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "DELETE FROM userinfo WHERE username = ?";
            statement = connection.prepareStatement(query);
            
            
            
            statement.setString(1, userName);
        
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}