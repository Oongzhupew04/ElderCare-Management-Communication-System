import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class GuardianEditProfileGUI extends JPanel implements DashboardContentParentGUI
{
    public GuardianEditProfileGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        JPanel guardianInfoPanel = new JPanel();
        guardianInfoPanel.setBackground(Color.WHITE);
        guardianInfoPanel.setLayout(new BoxLayout(guardianInfoPanel, BoxLayout.Y_AXIS));
        guardianInfoPanel.setBorder(new EmptyBorder(50, 100, 0, 0));
        add(guardianInfoPanel, BorderLayout.WEST);
        
        JPanel guardianRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianRolePanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianRolePanel);
        JLabel guardianRole = new JLabel("Guardian");
        guardianRole.setPreferredSize(new Dimension(210, 40));
        guardianRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        guardianRole.setForeground(Color.BLACK);
        Border groleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        guardianRole.setBorder(groleBottomBorder);
        guardianRolePanel.add(guardianRole);
        
        JPanel guardianUsernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianUsernamePanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianUsernamePanel);
        JLabel guardianUsernameLabel = new JLabel("Username:");
        guardianUsernameLabel.setPreferredSize(new Dimension(140, 40));
        guardianUsernameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianUsernamePanel.add(guardianUsernameLabel);
        JTextField guardianUsernameTextField = new JTextField();
        guardianUsernameTextField.setColumns(20);
        guardianUsernameTextField.setPreferredSize(new Dimension(40, 40));
        guardianUsernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianUsernameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianUsernamePanel.add(guardianUsernameTextField);
        
        JPanel guardianPhoneNumberPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianPhoneNumberPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianPhoneNumberPanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianPhoneNumberPanel);
        JLabel guardianPhoneNumberLabel = new JLabel("Phone Number:");
        guardianPhoneNumberLabel.setPreferredSize(new Dimension(200, 40));
        guardianPhoneNumberLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianPhoneNumberPanel.add(guardianPhoneNumberLabel);
        JTextField guardianPhoneNumberTextField = new JTextField();
        guardianPhoneNumberTextField.setColumns(20);
        guardianPhoneNumberTextField.setPreferredSize(new Dimension(40, 40));
        guardianPhoneNumberTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianPhoneNumberTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianPhoneNumberPanel.add(guardianPhoneNumberTextField);
        
        JPanel guardianEmailPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianEmailPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianEmailPanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianEmailPanel);
        JLabel guardianEmailLabel = new JLabel("Email:");
        guardianEmailLabel.setPreferredSize(new Dimension(90, 40));
        guardianEmailLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianEmailPanel.add(guardianEmailLabel);
        JTextField guardianEmailTextField = new JTextField();
        guardianEmailTextField.setColumns(20);
        guardianEmailTextField.setPreferredSize(new Dimension(40, 40));
        guardianEmailTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianEmailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianEmailPanel.add(guardianEmailTextField);
        
        JPanel guardianAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianAddressPanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianAddressPanel);
        JLabel guardianAddressLabel = new JLabel("Address:");
        guardianAddressLabel.setPreferredSize(new Dimension(120, 40));
        guardianAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianAddressPanel.add(guardianAddressLabel);
        JTextField guardianAddressTextField = new JTextField();
        guardianAddressTextField.setColumns(20);
        guardianAddressTextField.setPreferredSize(new Dimension(40, 40));
        guardianAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianAddressPanel.add(guardianAddressTextField);
        
        JPanel guardianPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianPasswordPanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianPasswordPanel);
        JLabel guardianPasswordLabel = new JLabel("New Password:");
        guardianPasswordLabel.setPreferredSize(new Dimension(200, 40));
        guardianPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianPasswordPanel.add(guardianPasswordLabel);
        JTextField guardianPasswordTextField = new JTextField();
        guardianPasswordTextField.setColumns(20);
        guardianPasswordTextField.setPreferredSize(new Dimension(40, 40));
        guardianPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianPasswordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianPasswordPanel.add(guardianPasswordTextField);
        
        JPanel guardianConfirmPasswordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        guardianConfirmPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        guardianConfirmPasswordPanel.setBackground(Color.WHITE);
        guardianInfoPanel.add(guardianConfirmPasswordPanel);
        JLabel guardianConfirmPasswordLabel = new JLabel("Confirm Password:");
        guardianConfirmPasswordLabel.setPreferredSize(new Dimension(245, 40));
        guardianConfirmPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        guardianConfirmPasswordPanel.add(guardianConfirmPasswordLabel);
        JTextField guardianConfirmPasswordTextField = new JTextField();
        guardianConfirmPasswordTextField.setColumns(20);
        guardianConfirmPasswordTextField.setPreferredSize(new Dimension(40, 40));
        guardianConfirmPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        guardianConfirmPasswordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        guardianConfirmPasswordPanel.add(guardianConfirmPasswordTextField);
        
        JPanel button1Panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        button1Panel.setBorder(new EmptyBorder(50, 0, 0, 0));
        button1Panel.setBackground(Color.WHITE);
        guardianInfoPanel.add(button1Panel);
        JButton back = new JButton("Back");
        back.setPreferredSize(new Dimension(230, 70));
        back.setFont(new Font("Serif", Font.BOLD, 30));
        back.setBackground(new Color(68,147,186,255));
        back.setForeground(Color.BLACK);
        back.setBorder(new LineBorder(Color.BLACK, 7));
        back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                GuardianProfileGUI guardianProfilePanel = new GuardianProfileGUI(dashboard, userID);
                dashboard.remove(GuardianEditProfileGUI.this);
                dashboard.add(guardianProfilePanel.getPanel(), BorderLayout.CENTER);

                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        button1Panel.add(back);
        
        
        
        
        JPanel elderInfoPanel = new JPanel();
        elderInfoPanel.setBackground(Color.WHITE);
        elderInfoPanel.setLayout(new BoxLayout(elderInfoPanel, BoxLayout.Y_AXIS));
        elderInfoPanel.setBorder(new EmptyBorder(50, 100, 0, 0));
        add(elderInfoPanel);
        
        JPanel elderRolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderRolePanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderRolePanel);
        JLabel elderRole = new JLabel("Elder");
        elderRole.setPreferredSize(new Dimension(125, 40));
        elderRole.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 44));
        elderRole.setForeground(Color.BLACK);
        Border eroleBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        elderRole.setBorder(eroleBottomBorder);
        elderRolePanel.add(elderRole);
        
        JPanel elderNamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderNamePanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderNamePanel);
        JLabel elderNameLabel = new JLabel("Name:");
        elderNameLabel.setPreferredSize(new Dimension(85, 40));
        elderNameLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderNamePanel.add(elderNameLabel);
        JTextField elderNameTextField = new JTextField();
        elderNameTextField.setColumns(20);
        elderNameTextField.setPreferredSize(new Dimension(40, 40));
        elderNameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderNameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderNamePanel.add(elderNameTextField);
        
        JPanel elderAgePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderAgePanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderAgePanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderAgePanel);
        JLabel elderAgeLabel = new JLabel("Age:");
        elderAgeLabel.setPreferredSize(new Dimension(65, 40));
        elderAgeLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderAgePanel.add(elderAgeLabel);
        JTextField elderAgeTextField = new JTextField();
        elderAgeTextField.setColumns(20);
        elderAgeTextField.setPreferredSize(new Dimension(40, 40));
        elderAgeTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderAgeTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderAgePanel.add(elderAgeTextField);
        
        JPanel elderGenderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderGenderPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderGenderPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderGenderPanel);
        JLabel elderGenderLabel = new JLabel("Gender:");
        elderGenderLabel.setPreferredSize(new Dimension(110, 40));
        elderGenderLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderGenderPanel.add(elderGenderLabel);
        JTextField elderGenderTextField = new JTextField();
        elderGenderTextField.setColumns(20);
        elderGenderTextField.setPreferredSize(new Dimension(40, 40));
        elderGenderTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderGenderTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderGenderPanel.add(elderGenderTextField);
        
        JPanel elderMedicalRecordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderMedicalRecordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderMedicalRecordPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderMedicalRecordPanel);
        JLabel elderMedicalRecordLabel = new JLabel("Medical Record:");
        elderMedicalRecordLabel.setPreferredSize(new Dimension(210, 40));
        elderMedicalRecordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderMedicalRecordPanel.add(elderMedicalRecordLabel);
        JTextField elderMedicalRecordTextField = new JTextField();
        elderMedicalRecordTextField.setColumns(20);
        elderMedicalRecordTextField.setPreferredSize(new Dimension(40, 40));
        elderMedicalRecordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderMedicalRecordTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderMedicalRecordPanel.add(elderMedicalRecordTextField);
        
        JPanel elderAddressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        elderAddressPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        elderAddressPanel.setBackground(Color.WHITE);
        elderInfoPanel.add(elderAddressPanel);
        JLabel elderAddressLabel = new JLabel("Address:");
        elderAddressLabel.setPreferredSize(new Dimension(120, 40));
        elderAddressLabel.setFont(new Font("Arial", Font.BOLD, 26));
        elderAddressPanel.add(elderAddressLabel);
        JTextField elderAddressTextField = new JTextField();
        elderAddressTextField.setColumns(20);
        elderAddressTextField.setPreferredSize(new Dimension(40, 40));
        elderAddressTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        elderAddressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        elderAddressPanel.add(elderAddressTextField);
        
        JPanel button2Panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        button2Panel.setBorder(new EmptyBorder(100, 0, 0, 100));
        button2Panel.setBackground(Color.WHITE);
        elderInfoPanel.add(button2Panel);
        JButton save = new JButton("Save");
        save.setPreferredSize(new Dimension(230, 70));
        save.setFont(new Font("Serif", Font.BOLD, 30));
        save.setBackground(new Color(68,147,186,255));
        save.setForeground(Color.BLACK);
        save.setBorder(new LineBorder(Color.BLACK, 7));
        save.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(guardianConfirmPasswordTextField.getText().equals(guardianPasswordTextField.getText()))
                {
                    for(User userAcc : MainLogic.userAccount)
                    {
                        if((userAcc.getUserInfo().get(0)).equals(userID))
                        {
                            GuardianUser guardian = (GuardianUser) userAcc;      //Cast to GuardianUser
                            guardian.setUserInfo(guardianUsernameTextField.getText(), guardianConfirmPasswordTextField.getText(), guardianEmailTextField.getText(), Integer.parseInt(guardianPhoneNumberTextField.getText()), guardianAddressTextField.getText(), elderNameTextField.getText(), Integer.parseInt(elderAgeTextField.getText()), elderGenderTextField.getText(), elderMedicalRecordTextField.getText(), elderAddressTextField.getText());
                            guardian.editDatabaseInfo(userID, (String)userAcc.getUserInfo().get(1), guardianUsernameTextField.getText(), guardianConfirmPasswordTextField.getText(), (String)userAcc.getUserInfo().get(4), guardianEmailTextField.getText(), Integer.parseInt(guardianPhoneNumberTextField.getText()), null, null, guardianAddressTextField.getText());
                            JOptionPane.showMessageDialog(null, "Saved!");
                            break;
                        }
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "New password doesn't match confirm password.");
                }
            }
        });
        button2Panel.add(save);
    }
    public JPanel getPanel() {return GuardianEditProfileGUI.this;}
}