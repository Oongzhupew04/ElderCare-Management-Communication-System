import javax.swing.*;
interface DashboardContentParentGUI {
    JPanel getPanel();
}