import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
import java.sql.*;

public class ApproveApplicationGUI extends JPanel {
    private JPanel itemListPanel;
    private List<String> approvedUsers;
    private List<String> rejectedUsers; // New list for rejected users
    //private static final String[] roles = {"Guardian", "Companion", "Therapist"};

    public ApproveApplicationGUI() {
        setLayout(new BorderLayout());

        approvedUsers = new ArrayList<>();
        rejectedUsers = new ArrayList<>(); // Initialize rejected users list

        JPanel approveApplicationPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        approveApplicationPanel.setBorder(new EmptyBorder(10, 30, 0, 0)); 
        approveApplicationPanel.setBackground(Color.WHITE);
        add(approveApplicationPanel, BorderLayout.NORTH);
        JLabel approveApplicationLabel = new JLabel("Application Approval");
        approveApplicationLabel.setFont(new Font("Arial", Font.BOLD, 34));
        Border approveApplicationBottomBorder = BorderFactory.createMatteBorder(0, 0, 3, 0, Color.BLACK);
        approveApplicationLabel.setBorder(approveApplicationBottomBorder);
        approveApplicationPanel.add(approveApplicationLabel);

        // Main panel with white background and scroll pane
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20)); // Add padding around the main panel
        add(mainPanel);
        
        // Labels above the list
        JPanel labelPanel = new JPanel(new GridLayout(1, 2));
        labelPanel.setBorder(new EmptyBorder(10, 0, 20, 0)); // Add padding below the labels
        JLabel userNameLabel = new JLabel("User Name");
        userNameLabel.setFont(new Font("Arial", Font.BOLD, 24));
        JLabel roleLabel = new JLabel("Role");
        roleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        labelPanel.add(userNameLabel);
        labelPanel.add(roleLabel);

        // Item list panel with scroll pane
        itemListPanel = new JPanel();
        itemListPanel.setLayout(new BoxLayout(itemListPanel, BoxLayout.Y_AXIS));
        itemListPanel.setBorder(new EmptyBorder(10, 10, 10, 10)); // Add padding around the item list panel
        JScrollPane scrollPane = new JScrollPane(itemListPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        
        ArrayList <String> userNames = getUsername();
        ArrayList <String> role = getRole();
        for (int i = 0; i < userNames.size(); i++) {
            addItem(userNames.get(i), role.get(i));
        }

        // Add space at the bottom of the list
        JPanel spacePanel = new JPanel();
        spacePanel.setPreferredSize(new Dimension(10, 50));
        itemListPanel.add(spacePanel);

        mainPanel.add(labelPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // History button
        JButton historyButton = new JButton("History");
        historyButton.setFont(new Font("Arial", Font.BOLD, 20));
        historyButton.setBackground(Color.WHITE);
        historyButton.setForeground(Color.BLACK);
        historyButton.setBorder(new LineBorder(Color.BLACK, 6));
        historyButton.setPreferredSize(new Dimension(100, 40)); // Make the button smaller
        historyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showHistory();
            }
        });

        JPanel historyButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Center the button
        historyButtonPanel.add(historyButton);
        mainPanel.add(historyButtonPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);

    }

    private void addItem(String userName, String role) {
        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        itemPanel.setBorder(new EmptyBorder(5, 5, 5, 5)); // Add padding around each item
    
        JPanel userDetailsPanel = new JPanel(new GridLayout(1, 2));
        userDetailsPanel.setBorder(new EmptyBorder(0, 0, 0, 50)); // Adjust spacing between names and roles
        JLabel userNameLabel = new JLabel(userName);
        userNameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        JLabel roleLabel = new JLabel(role);
        roleLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        roleLabel.setBorder(new EmptyBorder(0, 150, 0, 0)); // Increase padding to the left for better alignment
        userDetailsPanel.add(userNameLabel);
        userDetailsPanel.add(roleLabel);
    
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    
        JButton approveButton = new JButton("Approve");
        approveButton.setFont(new Font("Arial", Font.BOLD, 14));
        approveButton.setBackground(Color.WHITE);
        approveButton.setForeground(Color.BLACK);
        approveButton.setBorder(new LineBorder(Color.BLACK, 6));
        approveButton.setPreferredSize(new Dimension(120, 40));
        approveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Object> userAccInfo = getUserAccInfo(userName);
                addToUserInfo(userAccInfo);
                removeFromUserApproval(userName);
                
                approvedUsers.add(userName);
                itemListPanel.remove(itemPanel);
                itemListPanel.revalidate();
                itemListPanel.repaint();
            }
        });
    
        JButton rejectButton = new JButton("Reject");
        rejectButton.setFont(new Font("Arial", Font.BOLD, 14));
        rejectButton.setBackground(Color.WHITE);
        rejectButton.setForeground(Color.BLACK);
        rejectButton.setBorder(new LineBorder(Color.BLACK, 6));
        rejectButton.setPreferredSize(new Dimension(100, 40));
        rejectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeFromUserApproval(userName);
                JOptionPane.showMessageDialog(null, "User removed");
                //removeFromElderInfo();
                
                rejectedUsers.add(userName); // Add to rejected users list
                itemListPanel.remove(itemPanel);
                itemListPanel.revalidate();
                itemListPanel.repaint();
            }
        });
    
        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
    
        itemPanel.add(userDetailsPanel, BorderLayout.CENTER);
        itemPanel.add(buttonPanel, BorderLayout.EAST);
        itemListPanel.add(itemPanel);
    }
    
    private void showHistory() {
        StringBuilder history = new StringBuilder();
        history.append("Approved Users:\n");
        for (String user : approvedUsers) {
            history.append("- ").append(user).append("\n");
        }

        history.append("\nRejected Users:\n");
        for (String user : rejectedUsers) {
            history.append("- ").append(user).append("\n");
        }

        JOptionPane.showMessageDialog(this, history.toString(), "History", JOptionPane.INFORMATION_MESSAGE);
    }
    public JPanel getApproveApplicationPanel() {return ApproveApplicationGUI.this;}
    public ArrayList getUsername()
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        ArrayList<String> userNames = new ArrayList<String>();

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.userapproval"; // Replace with your table name
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                    String accUsername = resultSet.getString(3);
                    userNames.add(accUsername);
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return userNames;
    }
    public ArrayList getRole()
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        ArrayList<String> roles = new ArrayList<String>();

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.userapproval"; // Replace with your table name
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                    String accRole = resultSet.getString(5);
                    roles.add(accRole);
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return roles;
    }
    public ArrayList getUserAccInfo(String userName)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        ArrayList<Object> userAccInfo = new ArrayList<Object>();

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.userapproval"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(3).equals(userName))
                {
                    String userId = resultSet.getString(1);
                    String name = resultSet.getString(2);
                    String user_name = resultSet.getString(3);
                    String pass_word = resultSet.getString(4);
                    String role = resultSet.getString(5);
                    String email = resultSet.getString(6);
                    String phone = resultSet.getString(7);
                    String licenseNumber = resultSet.getString(8);
                    String therapistService = resultSet.getString(9);
                    String address = resultSet.getString(10);
                    
                    
                    userAccInfo.add(userId);
                    userAccInfo.add(name);
                    userAccInfo.add(user_name);
                    userAccInfo.add(pass_word);
                    userAccInfo.add(role);
                    userAccInfo.add(email);
                    userAccInfo.add(phone);
                    userAccInfo.add(licenseNumber);
                    userAccInfo.add(therapistService);
                    userAccInfo.add(address);
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return userAccInfo;
    }
    void addToUserInfo(ArrayList userAccInfo)
    {
        if(userAccInfo.get(4).equals("companion"))
        {
            User companionUser = new CompanionUser((String)userAccInfo.get(0), (String)userAccInfo.get(1), (String)userAccInfo.get(2), (String)userAccInfo.get(3), (String)userAccInfo.get(4), (String)userAccInfo.get(5), Integer.parseInt((String)userAccInfo.get(6)), Integer.parseInt((String)userAccInfo.get(7)), (String)userAccInfo.get(9));
            companionUser.setDatabaseInfo((String)userAccInfo.get(0), (String)userAccInfo.get(1), (String)userAccInfo.get(2), (String)userAccInfo.get(3), (String)userAccInfo.get(4), (String)userAccInfo.get(5), Integer.parseInt((String)userAccInfo.get(6)), Integer.parseInt((String)userAccInfo.get(7)), null, (String)userAccInfo.get(9));
            MainLogic.userAccCount++;
            MainLogic.userAccount.add(companionUser);
            JOptionPane.showMessageDialog(null, "User approved");
        }
        else if(userAccInfo.get(4).equals("guardian"))
        {
            ArrayList<Object> ElderInfo = getElderInfo((String)userAccInfo.get(0));
            
            User guardianUser = new GuardianUser((String)userAccInfo.get(0), (String)userAccInfo.get(1), (String)userAccInfo.get(2), (String)userAccInfo.get(3), (String)userAccInfo.get(4), (String)userAccInfo.get(5), Integer.parseInt((String)userAccInfo.get(6)), (String)userAccInfo.get(9), (String)ElderInfo.get(0), (String)ElderInfo.get(1), (Integer)ElderInfo.get(2), (String)ElderInfo.get(3), (String)ElderInfo.get(4), (String)ElderInfo.get(5));
            guardianUser.setDatabaseInfo((String)userAccInfo.get(0), (String)userAccInfo.get(1), (String)userAccInfo.get(2), (String)userAccInfo.get(3), (String)userAccInfo.get(4), (String)userAccInfo.get(5), Integer.parseInt((String)userAccInfo.get(6)), null, null, (String)userAccInfo.get(9));
            MainLogic.userAccCount++;
            MainLogic.userAccount.add(guardianUser);
            JOptionPane.showMessageDialog(null, "User approved");
        }
        else if(userAccInfo.get(4).equals("therapist"))
        {
            User medicalTherapistUser = new MedicalTherapistUser((String)userAccInfo.get(0), (String)userAccInfo.get(1), (String)userAccInfo.get(2), (String)userAccInfo.get(3), (String)userAccInfo.get(4), (String)userAccInfo.get(5), Integer.parseInt((String)userAccInfo.get(6)), Integer.parseInt((String)userAccInfo.get(7)), (String)userAccInfo.get(8), (String)userAccInfo.get(9));
            medicalTherapistUser.setDatabaseInfo((String)userAccInfo.get(0), (String)userAccInfo.get(1), (String)userAccInfo.get(2), (String)userAccInfo.get(3), (String)userAccInfo.get(4), (String)userAccInfo.get(5), Integer.parseInt((String)userAccInfo.get(6)), Integer.parseInt((String)userAccInfo.get(7)), (String)userAccInfo.get(8), (String)userAccInfo.get(9));
            MainLogic.userAccCount++;
            MainLogic.userAccount.add(medicalTherapistUser);
            JOptionPane.showMessageDialog(null, "User approved");
        }
    }
    void removeFromUserApproval(String userName)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "DELETE FROM userapproval WHERE username = ?";
            statement = connection.prepareStatement(query);
            
            
            
            statement.setString(1, userName);
        
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    ArrayList getElderInfo(String guardianid)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        ArrayList<Object> ElderInfo = new ArrayList<Object>();

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.elderinfo"; 
            resultSet = statement.executeQuery(query);

            
            
            
            while (resultSet.next()) {
                    if(resultSet.getString(7).equals(guardianid))
                    {
                        String elderID = resultSet.getString(1);
                        String name = resultSet.getString(2);
                        int age = resultSet.getInt(3);
                        String gender = resultSet.getString(4);
                        String medicalRecord = resultSet.getString(5);
                        String address = resultSet.getString(6);
                        String guardianID = resultSet.getString(7);
                    
                    
                        
                        
                            ElderInfo.add(elderID);
                            ElderInfo.add(name);
                            ElderInfo.add(age);
                            ElderInfo.add(gender);
                            ElderInfo.add(medicalRecord);
                            ElderInfo.add(address);
                            ElderInfo.add(guardianID);
                        
                    }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return ElderInfo;
    }
}