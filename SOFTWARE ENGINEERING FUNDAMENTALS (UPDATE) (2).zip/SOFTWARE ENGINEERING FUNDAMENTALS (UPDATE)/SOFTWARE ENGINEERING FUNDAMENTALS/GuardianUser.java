import java.util.ArrayList;
import java.sql.*;

public class GuardianUser extends User
{
    ArrayList<Object> GuardianUserInfo = new ArrayList<Object>();
    ArrayList<Object> ElderInfo = new ArrayList<Object>();
    ArrayList<ArrayList> AppointmentList = new ArrayList<ArrayList>();
    public GuardianUser(String ID, String name, String username, String password, String role, String email, int phoneNumber, String address, String elderID, String elderName, int elderAge, String elderGender, String elderMedicalRecord, String elderAddress)
    {
        GuardianUserInfo.add(ID);
        GuardianUserInfo.add(name);
        GuardianUserInfo.add(username);
        GuardianUserInfo.add(password);
        GuardianUserInfo.add(role);
        GuardianUserInfo.add(email);
        GuardianUserInfo.add(phoneNumber);
        GuardianUserInfo.add(address);
        
        ElderInfo.add(elderID);
        ElderInfo.add(elderName);
        ElderInfo.add(elderAge);
        ElderInfo.add(elderGender);
        ElderInfo.add(elderMedicalRecord);
        ElderInfo.add(elderAddress);
        ElderInfo.add(ID);
        
        updateAppointment();
    }
    ArrayList<Object> getUserInfo(){return GuardianUserInfo;}
    ArrayList<Object> getElderInfo(){return ElderInfo;}
    ArrayList<ArrayList> getAppointmentList(){return AppointmentList;}
    void setUserInfo(String username, String password, String email, int phoneNumber, String address, String elderName, int elderAge, String elderGender, String elderMedicalRecord, String elderAddress)
    {
        String ID = (String)GuardianUserInfo.get(0);
        String name = (String)GuardianUserInfo.get(1);
        String role = (String)GuardianUserInfo.get(4);
        String elderID = (String)ElderInfo.get(0);
        GuardianUserInfo.clear();
        ElderInfo.clear();
        
        GuardianUserInfo.add(ID);
        GuardianUserInfo.add(name);
        GuardianUserInfo.add(username);
        GuardianUserInfo.add(password);
        GuardianUserInfo.add(role);
        GuardianUserInfo.add(email);
        GuardianUserInfo.add(phoneNumber);
        GuardianUserInfo.add(address);
        
        ElderInfo.add(elderID);
        ElderInfo.add(elderName);
        ElderInfo.add(elderAge);
        ElderInfo.add(elderGender);
        ElderInfo.add(elderMedicalRecord);
        ElderInfo.add(elderAddress);
        ElderInfo.add(ID);
    }
    void setDatabaseInfo(String ID, String name, String username, String password, String role, String email, int phoneNumber, Integer licenseNumber, String therapistService, String address)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "INSERT INTO userinfo VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            statement.setString(1, ID);
            statement.setString(2, name);
            statement.setString(3, username);
            statement.setString(4, password);
            statement.setString(5, role);
            statement.setString(6, email);
            statement.setInt(7, phoneNumber);
            statement.setNull(8, Types.INTEGER);
            statement.setNull(9, Types.VARCHAR);
            statement.setString(10, address);
            
            statement.executeUpdate();
            
            query = "INSERT INTO elderinfo VALUES(?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            statement.setString(1, (String)ElderInfo.get(0));
            statement.setString(2, (String)ElderInfo.get(1));
            statement.setInt(3, (Integer)ElderInfo.get(2));
            statement.setString(4, (String)ElderInfo.get(3));
            statement.setString(5, (String)ElderInfo.get(4));
            statement.setString(6, (String)ElderInfo.get(5));
            statement.setString(7, (String)ElderInfo.get(6));
            
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    void editDatabaseInfo(String ID, String name, String username, String password, String role, String email, int phoneNumber, Integer licenseNumber, String therapistService, String address)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "UPDATE userinfo SET name = ?, username = ?, password = ?, role = ?, email = ?, phone = ?, licensenumber = ?, therapistservice = ?, address = ? WHERE userid = ?;";
            statement = connection.prepareStatement(query);
            
            
            statement.setString(1, name);
            statement.setString(2, username);
            statement.setString(3, password);
            statement.setString(4, role);
            statement.setString(5, email);
            statement.setInt(6, phoneNumber);
            statement.setNull(7, Types.INTEGER);
            statement.setNull(8, Types.VARCHAR);
            statement.setString(9, address);
            statement.setString(10, ID);
            
            statement.executeUpdate();
            
            query = "UPDATE elderinfo SET name = ?, age = ?, gender = ?, medicalrecord = ?, address = ? WHERE guardianid = ?;";
            statement = connection.prepareStatement(query);
            
            statement.setString(1, (String)ElderInfo.get(1));
            statement.setInt(2, (Integer)ElderInfo.get(2));
            statement.setString(3, (String)ElderInfo.get(3));
            statement.setString(4, (String)ElderInfo.get(4));
            statement.setString(5, (String)ElderInfo.get(5));
            statement.setString(6, (String)ElderInfo.get(6));
            
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    void bookAppointmentDatabase(String appointmentID, String patientName, String appointmentDate, String appointmentTime, String address, String therapyService, String conpanionID, String therapistID)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "INSERT INTO appointment VALUES(?, ?, STR_TO_DATE(?, '%Y-%m-%d'), STR_TO_DATE(?, '%H:%i:%s'), ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            
            
            statement.setString(1, appointmentID);
            statement.setString(2, patientName);
            statement.setString(3, appointmentDate);
            statement.setString(4, appointmentTime);
            statement.setString(5, address);
            statement.setString(6, therapyService);
            statement.setString(7, conpanionID);
            statement.setString(8, therapistID);
            
            statement.executeUpdate();
            
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        updateAppointment();
        MedicalTherapistUser.updateAppointment();
        CompanionUser.updateAppointment();
    }
    void updateAppointment()
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.appointment"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(2).equals(ElderInfo.get(1)))
                {
                    String appointmentId = resultSet.getString(1);
                    String patientName = resultSet.getString(2);
                    String appointmentDate = resultSet.getDate(3).toString();
                    String appointmentTime = resultSet.getTime(4).toString();
                    String address = resultSet.getString(5);
                    String therapyService = resultSet.getString(6);
                    String companionID = resultSet.getString(7);
                    String therapistID = resultSet.getString(8);
                    
                    
                    //if(resultSet.next())
                    //{
                        ArrayList<Object> Appointment = new ArrayList<Object>();
                        Appointment.add(appointmentId);
                        Appointment.add(patientName);
                        Appointment.add(appointmentDate);
                        Appointment.add(appointmentTime);
                        Appointment.add(address);
                        Appointment.add(therapyService);
                        Appointment.add(companionID);
                        Appointment.add(therapistID);
                        AppointmentList.add(Appointment);
                    //}
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    ArrayList getEmergencyContactList()
    {
        ArrayList<ArrayList> emergencyContactList = new ArrayList<ArrayList>();
        
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.emergencycontact"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(6).equals(GuardianUserInfo.get(0)))
                {
                    String name = resultSet.getString(1);
                    int phone = resultSet.getInt(2);
                    String relation = resultSet.getString(3);
                    String email = resultSet.getString(4);
                    String address = resultSet.getString(5);
                    String guardianID = resultSet.getString(6);
                    
                    
                    //if(resultSet.next())
                    //{
                        ArrayList<Object> emergencyContact = new ArrayList<Object>();
                        emergencyContact.add(name);
                        emergencyContact.add(phone);
                        emergencyContact.add(relation);
                        emergencyContact.add(email);
                        emergencyContact.add(address);
                        emergencyContact.add(guardianID);
                        emergencyContactList.add(emergencyContact);
                    //}
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return emergencyContactList;
    }
    void saveEmergencyContactDatabase(String name, int phone, String relation, String email, String address, String guardianID)
    {
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String databaseUsername = "ElderCare_stiffmebee";
        String databasePassword = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, databaseUsername, databasePassword);

            String query = "INSERT INTO emergencycontact VALUES(?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            
            
            
            statement.setString(1, name);
            statement.setInt(2, phone);
            statement.setString(3, relation);
            statement.setString(4, email);
            statement.setString(5, address);
            statement.setString(6, guardianID);
            
            statement.executeUpdate();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    ArrayList getDailyReportList()
    {
        ArrayList<ArrayList> dailyReportList = new ArrayList<ArrayList>();
        
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.dailyreport"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(8).equals((String)ElderInfo.get(0)))
                {
                    String date = resultSet.getDate(1).toString();
                    int amountofmeal = resultSet.getInt(2);
                    String bloodpressure = resultSet.getString(3);
                    String exercise = resultSet.getString(4);
                    String medicine = resultSet.getString(5);
                    String note = resultSet.getString(6);
                    String companionID = resultSet.getString(7);
                    String elderID = resultSet.getString(8);
                    
                    
                    //if(resultSet.next())
                    //{
                        ArrayList<Object> dailyReport = new ArrayList<Object>();
                        dailyReport.add(date);
                        dailyReport.add(amountofmeal);
                        dailyReport.add(bloodpressure);
                        dailyReport.add(exercise);
                        dailyReport.add(medicine);
                        dailyReport.add(note);
                        dailyReport.add(companionID);
                        dailyReport.add(elderID);
                        dailyReportList.add(dailyReport);
                    //}
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return dailyReportList;
    }
    ArrayList getMedicalReportList()
    {
        ArrayList<ArrayList> medicalReportList = new ArrayList<ArrayList>();
        
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.medicalreport"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                if(resultSet.getString(7) != null && resultSet.getString(7).equals((String)ElderInfo.get(0)))
                {
                    String date = resultSet.getDate(1).toString();
                    String therapistService = resultSet.getString(2);
                    String medicalHistory = resultSet.getString(3);
                    String medication = resultSet.getString(4);
                    String dosage = resultSet.getString(5);
                    String note = resultSet.getString(6);
                    String elderID = resultSet.getString(7);
                    String therapistID = resultSet.getString(8);
                    
                    
                    //if(resultSet.next())
                    //{
                        ArrayList<Object> medicalReport = new ArrayList<Object>();
                        medicalReport.add(date);
                        medicalReport.add(therapistService);
                        medicalReport.add(medicalHistory);
                        medicalReport.add(medication);
                        medicalReport.add(dosage);
                        medicalReport.add(note);
                        medicalReport.add(elderID);
                        medicalReport.add(therapistID);
                        medicalReportList.add(medicalReport);
                    //}
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return medicalReportList;
    }
    ArrayList getCompanionInformationList()
    {
        ArrayList<Object> companionInformationList = new ArrayList<Object>();
        
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.userinfo"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                for(ArrayList appointments : AppointmentList)
                {
                    if(resultSet.getString(1).equals(appointments.get(6)))
                    {
                        String companionId = resultSet.getString(1);
                        String companionName = resultSet.getString(2);
                        String companionUsername = resultSet.getString(3);
                        String companionPassword = resultSet.getString(4);
                        String companionRole = resultSet.getString(5);
                        String companionEmail = resultSet.getString(6);
                        int companionPhoneNumber = resultSet.getInt(7);
                        String companionLicenseNumber = Integer.toString(resultSet.getInt(8));
                        String companionAddress = resultSet.getString(10);
                    
                    
                        //if(resultSet.next())
                        //{
                            companionInformationList.add(companionId);
                            companionInformationList.add(companionName);
                            companionInformationList.add(companionUsername);
                            companionInformationList.add(companionPassword);
                            companionInformationList.add(companionRole);
                            companionInformationList.add(companionEmail);
                            companionInformationList.add(companionPhoneNumber);
                            companionInformationList.add(companionLicenseNumber);
                            companionInformationList.add(companionAddress);
                        //}
                    }                    
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return companionInformationList;
    }
    ArrayList getTherapistInformationList()
    {
        ArrayList<Object> therapistInformationList = new ArrayList<Object>();
        
        String url = "jdbc:mysql://lj7-2.h.filess.io:3307/ElderCare_stiffmebee";
        String username = "ElderCare_stiffmebee"; 
        String password = "45a5f894371f4d1b09d561f6664a1d1a0f86b3e8"; 
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver (optional for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(url, username, password);

            // Create a statement to execute SQL queries
            statement = connection.createStatement();

            // Execute a simple query (Example: SELECT)
            String query = "SELECT * FROM ElderCare_stiffmebee.userinfo"; 
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                for(ArrayList appointments : AppointmentList)
                {
                    if(resultSet.getString(1).equals((String)appointments.get(7)))
                    {
                        String therapistId = resultSet.getString(1);
                        String therapistName = resultSet.getString(2);
                        String therapistUsername = resultSet.getString(3);
                        String therapistPassword = resultSet.getString(4);
                        String therapistRole = resultSet.getString(5);
                        String therapistEmail = resultSet.getString(6);
                        int therapistPhoneNumber = resultSet.getInt(7);
                        String therapistLicenseNumber = Integer.toString(resultSet.getInt(8));
                        String therapistService = resultSet.getString(9);
                        String therapistAddress = resultSet.getString(10);
                    
                    
                        
                        
                            therapistInformationList.add(therapistId);
                            therapistInformationList.add(therapistName);
                            therapistInformationList.add(therapistUsername);
                            therapistInformationList.add(therapistPassword);
                            therapistInformationList.add(therapistRole);
                            therapistInformationList.add(therapistEmail);
                            therapistInformationList.add(therapistPhoneNumber);
                            therapistInformationList.add(therapistLicenseNumber);
                            therapistInformationList.add(therapistService);
                            therapistInformationList.add(therapistAddress);
                        
                    }
                }
            }
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources to prevent memory leaks
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return therapistInformationList;
    }
}