import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;

public class GuardianAddEmergencyContactGUI extends JPanel implements DashboardContentParentGUI
{
    public GuardianAddEmergencyContactGUI(JFrame dashboard, String userID)
    {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(new EmptyBorder(40, 40, 40, 40));
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel);
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(Color.WHITE);
        add(bottomPanel, BorderLayout.SOUTH);
        
        
        JPanel namePanel = new JPanel();
        namePanel.setBackground(Color.WHITE);
        centerPanel.add(namePanel);
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setPreferredSize(new Dimension(140, 40));
        nameLabel.setFont(new Font("Arial", Font.BOLD, 40));
        namePanel.add(nameLabel);
        JTextField nameTextField = new JTextField();
        nameTextField.setColumns(10);
        nameTextField.setPreferredSize(new Dimension(40, 40));
        nameTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        nameTextField.setBorder(new LineBorder(Color.BLACK, 5));
        namePanel.add(nameTextField);
        
        JPanel contactPanel = new JPanel();
        contactPanel.setBackground(Color.WHITE);
        centerPanel.add(contactPanel);
        JLabel contactLabel = new JLabel("Contact:");
        contactLabel.setPreferredSize(new Dimension(180, 40));
        contactLabel.setFont(new Font("Arial", Font.BOLD, 40));
        contactPanel.add(contactLabel);
        JTextField contactTextField = new JTextField();
        contactTextField.setColumns(10);
        contactTextField.setPreferredSize(new Dimension(40, 40));
        contactTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        contactTextField.setBorder(new LineBorder(Color.BLACK, 5));
        contactPanel.add(contactTextField);
        
        JPanel relationshipPanel = new JPanel();
        relationshipPanel.setBackground(Color.WHITE);
        centerPanel.add(relationshipPanel);
        JLabel relationshipLabel = new JLabel("Relationship:");
        relationshipLabel.setPreferredSize(new Dimension(270, 40));
        relationshipLabel.setFont(new Font("Arial", Font.BOLD, 40));
        relationshipPanel.add(relationshipLabel);
        JTextField relationshipTextField = new JTextField();
        relationshipTextField.setColumns(10);
        relationshipTextField.setPreferredSize(new Dimension(40, 40));
        relationshipTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        relationshipTextField.setBorder(new LineBorder(Color.BLACK, 5));
        relationshipPanel.add(relationshipTextField);
        
        JPanel emailPanel = new JPanel();
        emailPanel.setBackground(Color.WHITE);
        centerPanel.add(emailPanel);
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setPreferredSize(new Dimension(140, 40));
        emailLabel.setFont(new Font("Arial", Font.BOLD, 40));
        emailPanel.add(emailLabel);
        JTextField emailTextField = new JTextField();
        emailTextField.setColumns(10);
        emailTextField.setPreferredSize(new Dimension(40, 40));
        emailTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        emailTextField.setBorder(new LineBorder(Color.BLACK, 5));
        emailPanel.add(emailTextField);
        
        JPanel addressPanel = new JPanel();
        addressPanel.setBackground(Color.WHITE);
        centerPanel.add(addressPanel);
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setPreferredSize(new Dimension(190, 40));
        addressLabel.setFont(new Font("Arial", Font.BOLD, 40));
        addressPanel.add(addressLabel);
        JTextField addressTextField = new JTextField();
        addressTextField.setColumns(30);
        addressTextField.setPreferredSize(new Dimension(40, 40));
        addressTextField.setFont(new Font("Arial", Font.PLAIN, 36));
        addressTextField.setBorder(new LineBorder(Color.BLACK, 5));
        addressPanel.add(addressTextField);
        
        
        
        
        
        
        JPanel backButtonPanel = new JPanel();
        backButtonPanel.setBorder(new EmptyBorder(0, 100, 30, 0));
        backButtonPanel.setBackground(Color.WHITE);
        bottomPanel.add(backButtonPanel, BorderLayout.WEST);
        JButton back = new JButton("Back");
        back.setMaximumSize(new Dimension(170, 55));
        back.setAlignmentX(Component.CENTER_ALIGNMENT);
        back.setFont(new Font("Arial", Font.BOLD, 40));
        back.setBackground(Color.WHITE);
        back.setForeground(Color.BLACK);
        back.setBorder(new LineBorder(Color.BLACK, 7));
        back.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                GuardianEmergencyContactGUI guardianEmergencyContactGUI = new GuardianEmergencyContactGUI(dashboard, userID);
                dashboard.remove(GuardianAddEmergencyContactGUI.this);
                dashboard.add(guardianEmergencyContactGUI.getPanel(), BorderLayout.CENTER);

                
                
                
                dashboard.revalidate();
                dashboard.repaint();
            }
        });
        backButtonPanel.add(back);
        
        JPanel saveButtonPanel = new JPanel();
        saveButtonPanel.setBorder(new EmptyBorder(0, 0, 30, 100));
        saveButtonPanel.setBackground(Color.WHITE);
        bottomPanel.add(saveButtonPanel, BorderLayout.EAST);
        JButton save = new JButton("Save");
        save.setMaximumSize(new Dimension(170, 55));
        save.setAlignmentX(Component.CENTER_ALIGNMENT);
        save.setFont(new Font("Arial", Font.BOLD, 40));
        save.setBackground(Color.WHITE);
        save.setForeground(Color.BLACK);
        save.setBorder(new LineBorder(Color.BLACK, 7));
        save.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                for(User userAcc : MainLogic.userAccount)
                {
                    if((userAcc.getUserInfo().get(0)).equals(userID))
                    {
                        GuardianUser guardian = (GuardianUser) userAcc;
                        guardian.saveEmergencyContactDatabase(nameTextField.getText(), Integer.parseInt(contactTextField.getText()), relationshipTextField.getText(), emailTextField.getText(), addressTextField.getText(), (String)userAcc.getUserInfo().get(0));
                        JOptionPane.showMessageDialog(null, "Saved");
                        break;
                    }
                }
            }
        });
        saveButtonPanel.add(save);
        
        
        
        
        
                
    }
    public JPanel getPanel() {return GuardianAddEmergencyContactGUI.this;}
}