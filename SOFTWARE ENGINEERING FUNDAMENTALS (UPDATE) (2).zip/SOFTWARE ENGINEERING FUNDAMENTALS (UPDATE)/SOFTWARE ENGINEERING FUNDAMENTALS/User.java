import java.util.ArrayList;

public abstract class User
{
    abstract ArrayList<Object> getUserInfo();
    abstract ArrayList<Object> getElderInfo();
    abstract ArrayList<ArrayList> getAppointmentList();
    abstract void setDatabaseInfo(String ID, String name, String username, String password, String role, String email, int phoneNumber, Integer licenseNumber, String therapistService, String address);
}