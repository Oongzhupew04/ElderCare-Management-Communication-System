import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class LoginGUI extends JFrame
{
    public LoginGUI()
    {
        super("LOGIN");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        JPanel loginPanel = new JPanel();
        loginPanel.setBackground(new Color(68,147,186,255));
        loginPanel.setBorder(new EmptyBorder(50, 0, 0, 0));
        add(loginPanel);
        
        JPanel loginBox = new JPanel();
        loginBox.setLayout(new BoxLayout(loginBox, BoxLayout.Y_AXIS));
        loginBox.setPreferredSize(new Dimension(550, 700));
        loginBox.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginBox.setBackground(new Color(68,147,186,255));
        loginBox.setBorder(new LineBorder(Color.WHITE, 2));
        loginPanel.add(loginBox);
        
        
        JPanel iconPanel = new JPanel();
        iconPanel.setBorder(new EmptyBorder(20, 0, 20, 0));
        iconPanel.setPreferredSize(new Dimension(540, 150));
        iconPanel.setLayout(new BoxLayout(iconPanel, BoxLayout.Y_AXIS));
        iconPanel.setBackground(new Color(68,147,186,255));
        loginBox.add(iconPanel);
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(192, 145, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        iconPanel.add(iconLabel);
        JPanel rolePanel = new JPanel();
        rolePanel.setBackground(new Color(68,147,186,255));
        rolePanel.setMaximumSize(new Dimension(540, 100));
        iconPanel.add(rolePanel);
        JLabel loginLabel = new JLabel("Login");
        loginLabel.setPreferredSize(new Dimension(120, 48));
        loginLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 36));
        loginLabel.setForeground(Color.WHITE);
        loginLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        rolePanel.add(loginLabel);
        ImageIcon regIcon = new ImageIcon("person2.png");
        JLabel regIconLabel = new JLabel(regIcon);
        regIconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        rolePanel.add(regIconLabel);
        
        
        JPanel usernamePanel = new JPanel();
        usernamePanel.setBorder(new EmptyBorder(10, 0, 0, 0));
        usernamePanel.setLayout(new BoxLayout(usernamePanel, BoxLayout.Y_AXIS));
        usernamePanel.setPreferredSize(new Dimension(540, 150));
        usernamePanel.setBackground(new Color(68,147,186,255));
        loginBox.add(usernamePanel);
        JLabel usernameLabel = new JLabel("Username                           ");
        usernameLabel.setPreferredSize(new Dimension(100, 40));
        usernameLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        usernamePanel.add(usernameLabel);
        JTextField usernameTextField = new JTextField();
        usernameTextField.setColumns(5);
        usernameTextField.setBackground(new Color(68,147,186,255));
        usernameTextField.setMaximumSize(new Dimension(300, 30));
        usernameTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        usernameTextField.setForeground(Color.WHITE);
        Border userNameBottomBorder = BorderFactory.createMatteBorder(0, 0, 3, 0, Color.WHITE);
        usernameTextField.setBorder(userNameBottomBorder);
        usernamePanel.add(usernameTextField);
        
        
        JPanel passwordPanel = new JPanel();
        passwordPanel.setBorder(new EmptyBorder(50, 0, 0, 0));
        passwordPanel.setLayout(new BoxLayout(passwordPanel, BoxLayout.Y_AXIS));
        passwordPanel.setPreferredSize(new Dimension(540, 150));
        passwordPanel.setBackground(new Color(68,147,186,255));
        loginBox.add(passwordPanel);
        JLabel passwordLabel = new JLabel("Password                            ");
        passwordLabel.setPreferredSize(new Dimension(100, 40));
        passwordLabel.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        passwordPanel.add(passwordLabel);
        JTextField passwordTextField = new JTextField();
        passwordTextField.setColumns(5);
        passwordTextField.setBackground(new Color(68,147,186,255));
        passwordTextField.setMaximumSize(new Dimension(300, 30));
        passwordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        passwordTextField.setForeground(Color.WHITE);
        Border passwordBottomBorder = BorderFactory.createMatteBorder(0, 0, 3, 0, Color.WHITE);
        passwordTextField.setBorder(passwordBottomBorder);
        passwordPanel.add(passwordTextField);
        
        
        
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(new EmptyBorder(80, 0, 0, 0));
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setPreferredSize(new Dimension(540, 150));
        buttonPanel.setBackground(new Color(68,147,186,255));
        loginBox.add(buttonPanel);
        JButton forgotPassword = new JButton("Forgot Password");
        forgotPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
        forgotPassword.setPreferredSize(new Dimension(80, 35));
        forgotPassword.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16));
        forgotPassword.setBackground(new Color(68,147,186,255));
        forgotPassword.setForeground(Color.WHITE);
        forgotPassword.setBorder(new LineBorder(new Color(68,147,186,255), 5));
        forgotPassword.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                String role = null;
                String userID = null;
                new ForgotPasswordGUI(role, userID);
                dispose();
            }
        });
        buttonPanel.add(forgotPassword);
        JButton login = new JButton("Log In");
        login.setMaximumSize(new Dimension(300, 60));
        login.setAlignmentX(Component.CENTER_ALIGNMENT);
        login.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 24));
        login.setBackground(Color.WHITE);
        login.setForeground(new Color(68,147,186,255));
        login.setBorder(new LineBorder(Color.WHITE, 5));
        login.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(usernameTextField.getText().equals("") || passwordTextField.getText().equals(""))
                {
                    JOptionPane.showMessageDialog(null, "Username or Password cannot be empty!");
                }
                else
                {
                    LoginLogic loginLogic = new LoginLogic(usernameTextField.getText(), passwordTextField.getText());
                    String role = loginLogic.getRole();
                    String userID = loginLogic.getUserID();
                    if(role == null)
                    {
                        JOptionPane.showMessageDialog(null, "Invalid Username or Password!");
                    }
                    else
                    {
                        if(role == "admin")
                        {
                            JOptionPane.showMessageDialog(null, "Login Successful!");
                            new AdminGUI();
                            dispose();
                        }
                        else
                        {
                            new OtpAuthentication(LoginGUI.this, role, userID);
                            dispose();
                        }
                    }
                }
            }
        });
        buttonPanel.add(login);
        JPanel doYouHaveAccPanel = new JPanel();
        doYouHaveAccPanel.setMaximumSize(new Dimension(540, 50));
        doYouHaveAccPanel.setBackground(new Color(68,147,186,255));
        buttonPanel.add(doYouHaveAccPanel);
        JLabel doYouHaveAccLabel = new JLabel("Don't have an account?");
        doYouHaveAccLabel.setPreferredSize(new Dimension(166, 30));
        doYouHaveAccLabel.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 14));
        doYouHaveAccLabel.setForeground(Color.WHITE);
        doYouHaveAccPanel.add(doYouHaveAccLabel);
        JButton register = new JButton("Register");
        register.setPreferredSize(new Dimension(80, 35));
        register.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16));
        register.setBackground(new Color(68,147,186,255));
        register.setForeground(Color.WHITE);
        register.setBorder(new LineBorder(new Color(68,147,186,255), 5));
        register.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new RegisterGUI();
                dispose();
            }
        });
        doYouHaveAccPanel.add(register);
        
        
        
        
        
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}