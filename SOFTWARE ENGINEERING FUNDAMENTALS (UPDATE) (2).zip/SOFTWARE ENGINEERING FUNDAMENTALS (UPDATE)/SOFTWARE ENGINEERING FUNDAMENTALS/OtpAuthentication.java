import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

import java.util.Properties;
import java.util.Random;
import javax.mail.*;
import javax.mail.internet.*;

public class OtpAuthentication extends JFrame
{
    private static final String FROM_EMAIL = "vincentoong12345@gmail.com"; // Replace with your email
    private static final String EMAIL_PASSWORD = "lmlp suwp mhdi mxlu";  // Replace with your app password
    String otp = null;
    public OtpAuthentication(Object object, String role, String userID)
    {
        super("OTP AUTHENTICATION");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        try {
            String recipientEmail = getUserEmail(userID); // Replace with recipient's email
            otp = generateOTP();
            
            sendOTP(recipientEmail, otp);
            System.out.println("OTP sent successfully to " + recipientEmail);
            System.out.println("Generated OTP: " + otp);
            
        } catch (MessagingException e) {
            System.out.println("Error sending email: " + e.getMessage());
            e.printStackTrace();
        }
        
        JPanel otpPanel = new JPanel();
        otpPanel.setLayout(new BoxLayout(otpPanel, BoxLayout.Y_AXIS));
        otpPanel.setBackground(Color.WHITE);
        add(otpPanel);
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(513, 387, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        otpPanel.add(iconLabel);
        
        
        
        JLabel otpAuthentication = new JLabel("OTP Authentication");
        otpAuthentication.setFont(new Font("Arial", Font.BOLD, 54));
        otpAuthentication.setBorder(new EmptyBorder(0, 0, 30, 0));
        otpAuthentication.setAlignmentX(Component.CENTER_ALIGNMENT);
        otpPanel.add(otpAuthentication);
        
        JPanel otpNoPanel = new JPanel();
        otpNoPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        otpNoPanel.setBackground(Color.WHITE);
        otpPanel.add(otpNoPanel);
        
        JTextField otpNo1 = new JTextField(1);
        otpNo1.setFont(new Font("Arial", Font.BOLD, 60));
        otpNo1.setBorder(new LineBorder(Color.BLACK, 5));
        otpNo1.setMaximumSize(new Dimension(25, 30));
        documentFilter(otpNo1);
        otpNoPanel.add(otpNo1);
        
        JTextField otpNo2 = new JTextField(1);
        otpNo2.setFont(new Font("Arial", Font.BOLD, 60));
        otpNo2.setBorder(new LineBorder(Color.BLACK, 5));
        otpNo2.setMaximumSize(new Dimension(25, 30));
        documentFilter(otpNo2);
        otpNoPanel.add(otpNo2);

        JTextField otpNo3 = new JTextField(1);
        otpNo3.setFont(new Font("Arial", Font.BOLD, 60));
        otpNo3.setBorder(new LineBorder(Color.BLACK, 5));
        otpNo3.setMaximumSize(new Dimension(25, 30));
        documentFilter(otpNo3);
        otpNoPanel.add(otpNo3);
        
        JTextField otpNo4 = new JTextField(1);
        otpNo4.setFont(new Font("Arial", Font.BOLD, 60));
        otpNo4.setBorder(new LineBorder(Color.BLACK, 5));
        otpNo4.setMaximumSize(new Dimension(25, 30));
        documentFilter(otpNo4);
        otpNoPanel.add(otpNo4);
        
        JTextField otpNo5 = new JTextField(1);
        otpNo5.setFont(new Font("Arial", Font.BOLD, 60));
        otpNo5.setBorder(new LineBorder(Color.BLACK, 5));
        otpNo5.setMaximumSize(new Dimension(25, 30));
        documentFilter(otpNo5);
        otpNoPanel.add(otpNo5);
        
        JTextField otpNo6 = new JTextField(1);
        otpNo6.setFont(new Font("Arial", Font.BOLD, 60));
        otpNo6.setBorder(new LineBorder(Color.BLACK, 5));
        otpNo6.setMaximumSize(new Dimension(25, 30));
        documentFilter(otpNo6);
        otpNoPanel.add(otpNo6);
        
        JButton verify = new JButton("Verify");
        verify.setMaximumSize(new Dimension(110, 45));
        verify.setAlignmentX(Component.CENTER_ALIGNMENT);
        verify.setFont(new Font("Arial", Font.BOLD, 24));
        verify.setBackground(Color.WHITE);
        verify.setForeground(Color.BLACK);
        verify.setBorder(new LineBorder(Color.BLACK, 5));
        verify.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                String keyInOTP = otpNo1.getText() + otpNo2.getText() + otpNo3.getText() + otpNo4.getText() + otpNo5.getText() + otpNo6.getText(); 
                if(otp.equals(keyInOTP))
                {
                    if(object instanceof LoginGUI)
                    {
                        JOptionPane.showMessageDialog(null, "Login Successful!");
                        if (role.equals("admin"))
                        {
                            new AdminGUI();
                            dispose();
                        }
                        else
                        {
                            new DashboardGUI(role, userID);
                            dispose();
                        }
                    }
                    else if(object instanceof ForgotPasswordGUI)
                    {
                        JOptionPane.showMessageDialog(null, "Verified!");
                        new ResetPassword();
                        dispose();
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Wrong OTP number.");
                }
                
                //else if(object instanceof CompanionGUI || object instanceof GuardianGUI || object instanceof MedicalTherapistGUI)
                //{
                    //JOptionPane.showMessageDialog(null, "Verified!");
                    //new LoginGUI();
                    //dispose();
                //}
            }
        });
        otpPanel.add(verify);
        
        JLabel hasSentToLabel = new JLabel("6-digit OTP code has send to");
        hasSentToLabel.setFont(new Font("Arial", Font.BOLD, 24));
        hasSentToLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        hasSentToLabel.setBorder(new EmptyBorder(30, 0, 0, 0));
        otpPanel.add(hasSentToLabel);
        
        JPanel hasSentToGmailPanel = new JPanel();
        hasSentToGmailPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        hasSentToGmailPanel.setBackground(Color.WHITE);
        otpPanel.add(hasSentToGmailPanel);
        JLabel hasSentToGmailLabel = new JLabel("XXX@gmail.com ");
        hasSentToGmailLabel.setFont(new Font("Arial", Font.BOLD, 24));
        hasSentToGmailPanel.add(hasSentToGmailLabel);
        JButton resend = new JButton("Resend");
        resend.setPreferredSize(new Dimension(140, 45));
        resend.setFont(new Font("Arial", Font.BOLD, 24));
        resend.setBackground(Color.WHITE);
        resend.setForeground(Color.BLACK);
        resend.setBorder(new LineBorder(Color.BLACK, 5));
        resend.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                JOptionPane.showMessageDialog(null, "Check your Gmail inbox for OTP code.");
            }
        });
        hasSentToGmailPanel.add(resend);
        
        
        
        
        
        
        
        
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    
    
    
    public void documentFilter(JTextField textField)
    {
        // For one digit TextField
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if (string.matches("[0-9]") && fb.getDocument().getLength() < 1) {  // Only accept 1 digit
                    super.insertString(fb, offset, string, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String string, AttributeSet attrs) throws BadLocationException {
                if (string.matches("[0-9]") && fb.getDocument().getLength() < 1) {  // Only allow one character
                    super.replace(fb, offset, length, string, attrs);
                }
            }

            @Override
            public void remove(FilterBypass fb, int offset, int length) throws BadLocationException {
                super.remove(fb, offset, length);
            }
        });
    }
    
    
    
    
    //Use this to get user email
    String getUserEmail(String userID)
    {
        String email = null;
        for(User userAcc : MainLogic.userAccount)
        {
            if((userAcc.getUserInfo().get(0)).equals(userID))
            {
                email = String.valueOf(userAcc.getUserInfo().get(5));
            }
        }
        return email;
    }
    
    // Generate 6-digit OTP
    public static String generateOTP() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }
    
    // Send OTP via email
    public static void sendOTP(String toEmail, String otp) throws MessagingException {
        // Configure email properties
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        
        // Create session with authentication
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, EMAIL_PASSWORD);
            }
        });
        
        // Create message
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(FROM_EMAIL));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
        message.setSubject("Your OTP Code");
        message.setText("Your OTP is: " + otp + "\nThis OTP is valid for 5 minutes.");
        
        // Send message
        Transport.send(message);
    }
}