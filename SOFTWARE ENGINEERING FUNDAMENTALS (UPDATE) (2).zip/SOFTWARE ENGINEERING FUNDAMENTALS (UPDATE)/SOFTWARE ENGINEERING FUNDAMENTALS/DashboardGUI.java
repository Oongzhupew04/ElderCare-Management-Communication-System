import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class DashboardGUI extends JFrame
{
    private String displayingPanel;
    private Boolean dashboardBool = true;
    private Boolean profileBool = true;
    public DashboardGUI(String role, String userID)
    {
        super("DASHBOARD");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());
        
        JPanel navigationBarPanel = new JPanel();
        navigationBarPanel.setPreferredSize(new Dimension(Integer.MAX_VALUE, 100));
        navigationBarPanel.setLayout(new GridLayout(1,2));
        add(navigationBarPanel, BorderLayout.NORTH);
        
        JPanel dashboardPanel = new JPanel();
        dashboardPanel.setLayout(new BorderLayout());
        dashboardPanel.setBackground(Color.WHITE);
        displayingPanel = "dashboard";
        add(dashboardPanel, BorderLayout.CENTER);
        
        
        
        
        
        
        
        JPanel leftNavigationBarPanel = new JPanel();
        leftNavigationBarPanel.setPreferredSize(new Dimension(800, 100));
        leftNavigationBarPanel.setBorder(new EmptyBorder(13, 30, 0, 0));
        leftNavigationBarPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        leftNavigationBarPanel.setBackground(new Color(68,147,186,255));
        navigationBarPanel.add(leftNavigationBarPanel);
        
        JButton home = new JButton("Home");
        home.setPreferredSize(new Dimension(110, 60));
        home.setFont(new Font("Arial", Font.BOLD, 24));
        home.setBackground(Color.WHITE);
        home.setForeground(new Color(68,147,186,255));
        home.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("dashboard"))
                {
                    DashboardGUI.this.getContentPane().removeAll();
                    DashboardGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    DashboardGUI.this.add(dashboardPanel, BorderLayout.CENTER);
                    displayingPanel = "dashboard";
                    
                    DashboardGUI.this.revalidate();
                    DashboardGUI.this.repaint();
                }
            }
        });
        leftNavigationBarPanel.add(home);
        
        JButton profile = new JButton("Profile");
        profile.setPreferredSize(new Dimension(200, 60));
        profile.setFont(new Font("Arial", Font.BOLD, 24));
        profile.setBackground(Color.WHITE);
        profile.setForeground(new Color(68,147,186,255));
        Border profileBottomBorder = BorderFactory.createMatteBorder(0, 70, 0, 0, new Color(68,147,186,255));
        profile.setBorder(profileBottomBorder);
        profile.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("profile"))
                {
                    DashboardLogic dashboardLogic = new DashboardLogic(DashboardGUI.this, role, userID);
                    DashboardGUI.this.getContentPane().removeAll();
                    DashboardGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    DashboardGUI.this.add(dashboardLogic.getProfileGUI().getPanel(), BorderLayout.CENTER);
                    displayingPanel = "profile";
                
                
                    DashboardGUI.this.revalidate();
                    DashboardGUI.this.repaint();
                }
            }
        });
        leftNavigationBarPanel.add(profile);
        
        JButton aboutUs = new JButton("About Us");
        aboutUs.setPreferredSize(new Dimension(230, 60));
        aboutUs.setFont(new Font("Arial", Font.BOLD, 24));
        aboutUs.setBackground(Color.WHITE);
        aboutUs.setForeground(new Color(68,147,186,255));
        Border aboutUsBottomBorder = BorderFactory.createMatteBorder(0, 80, 0, 0, new Color(68,147,186,255));
        aboutUs.setBorder(aboutUsBottomBorder);
        aboutUs.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("aboutus"))
                {
                    AboutUsGUI aboutUsGUI = new AboutUsGUI();
                    DashboardGUI.this.getContentPane().removeAll();
                    DashboardGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    DashboardGUI.this.add(aboutUsGUI.getAboutUsPanel(), BorderLayout.CENTER);
                    displayingPanel = "aboutus";
                    
                    
                    DashboardGUI.this.revalidate();
                    DashboardGUI.this.repaint();
                }
            }
        });
        leftNavigationBarPanel.add(aboutUs);
        
        JPanel rightNavigationBarPanel = new JPanel();
        rightNavigationBarPanel.setPreferredSize(new Dimension(800, 100));
        rightNavigationBarPanel.setBorder(new EmptyBorder(13, 0, 0, 30));
        rightNavigationBarPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        rightNavigationBarPanel.setBackground(new Color(68,147,186,255));
        navigationBarPanel.add(rightNavigationBarPanel);
        
        JButton logout = new JButton("Logout");
        logout.setPreferredSize(new Dimension(130, 60));
        logout.setFont(new Font("Arial", Font.BOLD, 24));
        logout.setBackground(Color.WHITE);
        logout.setForeground(new Color(68,147,186,255));
        logout.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                int response = JOptionPane.showConfirmDialog(
                null,
                "Do you want to logout?",
                "Confirmation",
                JOptionPane.YES_NO_CANCEL_OPTION
                );
                if (response == JOptionPane.YES_OPTION)
                {
                    new MainGUI();
                    dispose();
                }
            }
        });
        rightNavigationBarPanel.add(logout);
        
        
        
        
        
        
        
        
        
        
        JPanel iconPanel = new JPanel();
        iconPanel.setBackground(Color.WHITE);
        dashboardPanel.add(iconPanel, BorderLayout.EAST);
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        iconLabel.setBorder(new EmptyBorder(100, 0, 0, 0));
        iconPanel.add(iconLabel);
        
        JPanel buttonPanel = new JPanel(new GridLayout(3,2));
        buttonPanel.setBackground(Color.WHITE);
        dashboardPanel.add(buttonPanel);
        
        JButton appointment = new JButton("Appointment");
        appointment.setPreferredSize(new Dimension(85, 85));
        appointment.setFont(new Font("Arial", Font.BOLD, 30));
        appointment.setBackground(new Color(68,147,186,255));
        appointment.setForeground(Color.WHITE);
        appointment.setBorder(new LineBorder(Color.WHITE, 30));
        appointment.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("appointment"))
                {
                    DashboardLogic dashboardLogic = new DashboardLogic(DashboardGUI.this, role, userID);
                    DashboardGUI.this.getContentPane().removeAll();
                    DashboardGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    DashboardGUI.this.add(dashboardLogic.getAppointmentGUI().getPanel(), BorderLayout.CENTER);
                    displayingPanel = "appointment";
                
                
                    DashboardGUI.this.revalidate();
                    DashboardGUI.this.repaint();
                }
            }
        });
        buttonPanel.add(appointment);
        
        JButton emergencyContact = new JButton("Emergency Contact");
        emergencyContact.setPreferredSize(new Dimension(85, 85));
        emergencyContact.setFont(new Font("Arial", Font.BOLD, 30));
        emergencyContact.setBackground(new Color(68,147,186,255));
        emergencyContact.setForeground(Color.WHITE);
        emergencyContact.setBorder(new LineBorder(Color.WHITE, 30));
        emergencyContact.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("emergency"))
                {
                    DashboardLogic dashboardLogic = new DashboardLogic(DashboardGUI.this, role, userID);
                    DashboardGUI.this.getContentPane().removeAll();
                    DashboardGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    DashboardGUI.this.add(dashboardLogic.getEmergencyContactGUI().getPanel(), BorderLayout.CENTER);
                    displayingPanel = "emergency";
                
                
                    DashboardGUI.this.revalidate();
                    DashboardGUI.this.repaint();
                }
            }
        });
        buttonPanel.add(emergencyContact);
        
        JButton dailyReportMedicalReport = new JButton("<html>Daily Report and<br>Medical Report</html>");
        dailyReportMedicalReport.setPreferredSize(new Dimension(85, 85));
        dailyReportMedicalReport.setFont(new Font("Arial", Font.BOLD, 30));
        dailyReportMedicalReport.setBackground(new Color(68,147,186,255));
        dailyReportMedicalReport.setForeground(Color.WHITE);
        dailyReportMedicalReport.setBorder(new LineBorder(Color.WHITE, 30));
        dailyReportMedicalReport.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("report"))
                {
                    DashboardLogic dashboardLogic = new DashboardLogic(DashboardGUI.this, role, userID);
                    DashboardGUI.this.getContentPane().removeAll();
                    DashboardGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    DashboardGUI.this.add(dashboardLogic.getDailyReportGUI().getPanel(), BorderLayout.CENTER);
                    displayingPanel = "report";
                
                
                    DashboardGUI.this.revalidate();
                    DashboardGUI.this.repaint();
                }
            }
        });
        buttonPanel.add(dailyReportMedicalReport);
        
        JButton companionTherapistInformation = new JButton("<html>Companion and<br>Therapist Information</html>");
        companionTherapistInformation.setPreferredSize(new Dimension(85, 85));
        companionTherapistInformation.setFont(new Font("Arial", Font.BOLD, 30));
        companionTherapistInformation.setBackground(new Color(68,147,186,255));
        companionTherapistInformation.setForeground(Color.WHITE);
        companionTherapistInformation.setBorder(new LineBorder(Color.WHITE, 30));
        companionTherapistInformation.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("information"))
                {
                    DashboardLogic dashboardLogic = new DashboardLogic(DashboardGUI.this, role, userID);
                    DashboardGUI.this.getContentPane().removeAll();
                    DashboardGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    DashboardGUI.this.add(dashboardLogic.getInformationGUI().getPanel(), BorderLayout.CENTER);
                    displayingPanel = "information";
                
                
                    DashboardGUI.this.revalidate();
                    DashboardGUI.this.repaint();
                }
            }
        });
        if(role.equals("companion") || role.equals("therapist"))
        {
            companionTherapistInformation.setText("<html>Elder's<br>Information</html>");
        }
        buttonPanel.add(companionTherapistInformation);
        
        JButton emergencyAlert = new JButton("Emergency Alert");
        emergencyAlert.setPreferredSize(new Dimension(85, 85));
        emergencyAlert.setFont(new Font("Arial", Font.BOLD, 30));
        emergencyAlert.setBackground(new Color(68,147,186,255));
        emergencyAlert.setForeground(Color.WHITE);
        emergencyAlert.setBorder(new LineBorder(Color.WHITE, 30));
        emergencyAlert.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                 if(!displayingPanel.equals("alert"))
                {
                    DashboardLogic dashboardLogic = new DashboardLogic(DashboardGUI.this, role, userID);
                    DashboardGUI.this.getContentPane().removeAll();
                    DashboardGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    DashboardGUI.this.add(dashboardLogic.getEmergencyAlertGUI().getPanel(), BorderLayout.CENTER);
                    displayingPanel = "alert";
                
                
                    DashboardGUI.this.revalidate();
                    DashboardGUI.this.repaint();
                }
            }
        });
        buttonPanel.add(emergencyAlert);
        
        JButton realTimeChat = new JButton("Real-time Chat");
        realTimeChat.setPreferredSize(new Dimension(85, 85));
        realTimeChat.setFont(new Font("Arial", Font.BOLD, 30));
        realTimeChat.setBackground(new Color(68,147,186,255));
        realTimeChat.setForeground(Color.WHITE);
        realTimeChat.setBorder(new LineBorder(Color.WHITE, 30));
        realTimeChat.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                if(!displayingPanel.equals("chat"))
                {
                    DashboardLogic dashboardLogic = new DashboardLogic(DashboardGUI.this, role, userID);
                    DashboardGUI.this.getContentPane().removeAll();
                    DashboardGUI.this.add(navigationBarPanel, BorderLayout.NORTH);
                    DashboardGUI.this.add(dashboardLogic.getRealTimeChatGUI().getPanel(), BorderLayout.CENTER);
                    displayingPanel = "chat";
                
                
                    DashboardGUI.this.revalidate();
                    DashboardGUI.this.repaint();
                }
            }
        });
        buttonPanel.add(realTimeChat);
        
        
        
        
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}