import java.util.*;

public class DashboardLogic
{
    DashboardContentParentGUI profilePanel;
    DashboardContentParentGUI appointmentGUI;
    DashboardContentParentGUI emergencyContactGUI;
    DashboardContentParentGUI dailyReportGUI;
    DashboardContentParentGUI informationGUI;
    DashboardContentParentGUI realTimeChatGUI;
    DashboardContentParentGUI emergencyAlertGUI;
    public DashboardLogic(DashboardGUI dashboardGUI, String role, String userID)
    {
        if(role.equals("guardian"))
        {
            profilePanel = new GuardianProfileGUI(dashboardGUI, userID);
            appointmentGUI = new GuardianAppointmentGUI(dashboardGUI, userID);
            emergencyContactGUI = new GuardianEmergencyContactGUI(dashboardGUI, userID);
            dailyReportGUI = new GuardianDailyReportGUI(dashboardGUI, userID);
            informationGUI = new GuardianCompanionInformationGUI(dashboardGUI, userID);
            realTimeChatGUI = new GuardianCompanionRealTimeChatGUI(dashboardGUI, userID);
            emergencyAlertGUI = new GuardianEmergencyAlertGUI(dashboardGUI, userID);
        }
        else if(role.equals("companion"))
        {
            profilePanel = new CompanionProfileGUI(dashboardGUI, userID);
            appointmentGUI = new CompanionViewAppointmentGUI(dashboardGUI, userID);
            emergencyContactGUI = new CompanionEmergencyContactGUI(dashboardGUI, userID);
            dailyReportGUI = new CompanionDailyReportGU(dashboardGUI, userID);
            informationGUI = new CompanionElderInformationGUI(dashboardGUI, userID);
            realTimeChatGUI = new CompanionGuardianRealTimeChatGUI(dashboardGUI, userID);
            emergencyAlertGUI = new CompanionEmergencyAlertGUI(dashboardGUI, userID);
        }
        else if(role.equals("therapist"))
        {
            profilePanel = new TherapistProfileGUI(dashboardGUI, userID);
            appointmentGUI = new TherapistViewAppointmentGUI(dashboardGUI, userID);
            emergencyContactGUI = new TherapistEmergencyContactGUI(dashboardGUI, userID);
            dailyReportGUI = new TherapistDailyReportGUI(dashboardGUI, userID);
            informationGUI = new TherapistElderInformationGUI(dashboardGUI, userID);
            realTimeChatGUI = new TherapistGuardianRealTimeChatGUI(dashboardGUI, userID);
            emergencyAlertGUI = new TherapistEmergencyAlertGUI(dashboardGUI, userID);
        }
    }
    public DashboardContentParentGUI getProfileGUI(){return profilePanel;}
    public DashboardContentParentGUI getAppointmentGUI(){return appointmentGUI;}
    public DashboardContentParentGUI getEmergencyContactGUI(){return emergencyContactGUI;}
    public DashboardContentParentGUI getDailyReportGUI(){return dailyReportGUI;}
    public DashboardContentParentGUI getInformationGUI(){return informationGUI;}
    public DashboardContentParentGUI getRealTimeChatGUI(){return realTimeChatGUI;}
    public DashboardContentParentGUI getEmergencyAlertGUI(){return emergencyAlertGUI;}
}