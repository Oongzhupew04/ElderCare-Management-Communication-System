import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class ResetPassword extends JFrame
{
    public ResetPassword()
    {
        super("FORGOT PASSWORD");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        JPanel resetPassowrdPanel = new JPanel();
        resetPassowrdPanel.setLayout(new BoxLayout(resetPassowrdPanel, BoxLayout.Y_AXIS));
        resetPassowrdPanel.setBackground(Color.WHITE);
        add(resetPassowrdPanel);
        ImageIcon icon = new ImageIcon("LOGO.jpg");
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(513, 387, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        resetPassowrdPanel.add(iconLabel);
        
        JLabel resetPassword = new JLabel("Reset password");
        resetPassword.setFont(new Font("Arial", Font.BOLD, 54));
        resetPassword.setBorder(new EmptyBorder(0, 0, 50, 0));
        resetPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
        resetPassowrdPanel.add(resetPassword);
        
        JPanel newPasswordPanel = new JPanel();
        newPasswordPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        newPasswordPanel.setBackground(Color.WHITE);
        resetPassowrdPanel.add(newPasswordPanel);
        JLabel newPasswordLabel = new JLabel("New Password:");
        newPasswordLabel.setPreferredSize(new Dimension(200, 40));
        newPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        newPasswordPanel.add(newPasswordLabel);
        JTextField newPasswordTextField = new JTextField();
        newPasswordTextField.setColumns(20);
        newPasswordTextField.setPreferredSize(new Dimension(40, 40));
        newPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border newPasswordBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        newPasswordTextField.setBorder(newPasswordBottomBorder);
        newPasswordPanel.add(newPasswordTextField);
        
        JPanel confirmPasswordPanel = new JPanel();
        confirmPasswordPanel.setBorder(new EmptyBorder(0, 0, 0, 0));
        confirmPasswordPanel.setBackground(Color.WHITE);
        resetPassowrdPanel.add(confirmPasswordPanel);
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setPreferredSize(new Dimension(250, 40));
        confirmPasswordLabel.setFont(new Font("Arial", Font.BOLD, 26));
        confirmPasswordPanel.add(confirmPasswordLabel);
        JTextField confirmPasswordTextField = new JTextField();
        confirmPasswordTextField.setColumns(20);
        confirmPasswordTextField.setPreferredSize(new Dimension(40, 40));
        confirmPasswordTextField.setFont(new Font("Arial", Font.PLAIN, 20));
        Border confirmPasswordBottomBorder = BorderFactory.createMatteBorder(0, 0, 4, 0, Color.BLACK);
        confirmPasswordTextField.setBorder(confirmPasswordBottomBorder);
        confirmPasswordPanel.add(confirmPasswordTextField);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        resetPassowrdPanel.add(buttonPanel);
        JButton confirm = new JButton("Confirm");
        confirm.setMaximumSize(new Dimension(110, 45));
        confirm.setAlignmentX(Component.CENTER_ALIGNMENT);
        confirm.setFont(new Font("Arial", Font.BOLD, 24));
        confirm.setBackground(Color.WHITE);
        confirm.setForeground(Color.BLACK);
        confirm.setBorder(new LineBorder(Color.BLACK, 5));
        confirm.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                JOptionPane.showMessageDialog(null, "Password successfully changed!");
                new LoginGUI();
                dispose();
            }
        });
        buttonPanel.add(confirm);
        
        
        
        
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}